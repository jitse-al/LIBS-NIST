n1=10;
n2=20;
x=-200:0.01:200;
y=cell(n2-n1+1,1);
xlength=length(x);
range=0.05;
ytotal=zeros(size(x));
hold on
a=1;
for i=n1:n2
    x2=x/i;
    y2=2*x2.*exp(-x2.^2);
    xmax=sqrt(0.5).*i;
    xb1=(1-range)*xmax;
    xb2=(1+range)*xmax;
    [~,b]=findxpositions(x,xb1,xb2);
    y2(1:a-1)=zeros(a-1,1);
    y2(b+1:xlength)=zeros(xlength-b,1);
    ytotal=ytotal+y2;
    a=b+1;
    plot(x,y2)
    xlim([5 15])
end
plot(x,ytotal)
    