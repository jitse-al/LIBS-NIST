function output=removeisnanaverage(input)
checker=0;
beginvalues=[];
endvalues=[];
for i=1:length(input)
    if isnan(input(i))
        if checker==0;
            checker=1;
            beginvalues=[beginvalues,i];
        end
    else
        if checker==1;
            checker=0;
            endvalues=[endvalues, i-1];
        end
    end
end
output=input;
if not(isempty(endvalues))
    if length(beginvalues)>length(endvalues)
        av1=input(beginvalues(length(beginvalues))-1);
        for i=beginvalues(length(beginvalues)):length(output)
        output(i)=av1;
        end
        beginvalues=beginvalues(1:(length(beginvalues)-1));
    end
    if beginvalues(1)==1;
        av1=input(endvalues(1)+1);
        for i=1:endvalues(1)
            output(i)=av1;
        end
        beginvalues=beginvalues(2:length(beginvalues));
        endvalues=endvalues(2:length(endvalues));
    end
    if not(isempty(beginvalues))
        for i=1:length(beginvalues);
            av1=(input(beginvalues(i)-1)+input(endvalues(i)+1))/2;
            for j=beginvalues(i):endvalues(i)
                output(j)=av1;
            end
        end
    end
elseif not(isempty(beginvalues))
    if not(beginvalues(1)==1);
    av1=input(beginvalues(length(beginvalues))-1);
        for i=beginvalues(length(beginvalues)):length(output)
        output(i)=av1;
        end
    end
end
        
    