function peakbounds2=combine_peakbounds(peakbounds,peakbounds2,height)
[lengthp,~]=size(peakbounds);
[lengthp2,~]=size(peakbounds2);
js=zeros(lengthp,1);
for j=1:lengthp;
    for k=1:lengthp2;
        if peakbounds(j,1)<=peakbounds2(k,1);
            if peakbounds(j,2)>=peakbounds2(k,2);
                js(j)=1;
                if peakbounds2(k,4)==0;
                    if peakbounds2(k,3)>2*height;
                        peakbounds2(k,4)=peakbounds(j,2)-peakbounds(j,1);
                    end
                end
            end
        end
    end
end
peakbounds_1=peakbounds(:,1);
peakbounds_1=peakbounds_1(not(js));
peakbounds_2=peakbounds(:,2);
peakbounds_2=peakbounds_2(not(js));
peakbounds=[peakbounds_1 peakbounds_2 ones(size(peakbounds_1)).*height zeros(size(peakbounds_1))];
peakbounds2=[peakbounds2;peakbounds];
end