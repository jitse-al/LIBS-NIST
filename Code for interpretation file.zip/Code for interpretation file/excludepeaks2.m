function [xout,yout]=excludepeaks2(x,y,parameters,range)
endcheck=ones(size(x));
lengthp=size(parameters);
for i=1:lengthp;
    [x1,x2]=findxpositions(x,parameters(i,1)-parameters(i,3)*range,parameters(i,1)+parameters(i,3)*range);
    endcheck(x1:x2)=zeros(x2-x1+1,1);
end
xout=x(logical(endcheck));
yout=y(logical(endcheck));