function [j1,steps,m]=unweirddatabase(database)
k=log(database)/log(10);
l=floor(k);
m=database./10.^l;
n=floor(m);
k1=1;
change=0;
j1=ones(247162,1);
steps=[];
for i=1:247162
    if n(i)>0.5
        if n(i)-change>1
        elseif n(i)>change
            change=n(i);
        elseif n(i)<change
            k1=k1*10;
            steps=[steps;i];
            change=n(i);
        end
        j1(i)=k1;
    end
end
j1=m.*j1;         