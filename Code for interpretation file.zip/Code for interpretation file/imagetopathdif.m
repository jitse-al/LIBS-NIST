function [image1,pathout]=imagetopathdif(image_start,pathstart,starting_range,lower_limit,upper_limit)
increment_pathrange=50;
[~,~,~,rgb,pathrange_orders]=create_michel_levy_chart(2500,increment_pathrange);
orderlength=length(rgb);
pathout=cell(5,1);
for t=1:orderlength;
for i=1:length(rgb{t});
    rgb{t}(i,:)=rgb{t}(i,:)./sqrt(sum(rgb{t}(i,:).^2));
end
[a,b,~]=size(image_start);
image_start=im2double(image_start);
image_start=permute(image_start,[1,3,2]);
image1=image_start;
pathout{t}=zeros(a,b);

pathstart=pathstart/increment_pathrange;
starting_range=starting_range/increment_pathrange;
p_begin=pathstart-starting_range;
if p_begin<1;
    p_begin=1;
end
p_end=pathstart+starting_range;

for i=1;
    for j=1:b;
            checkrange=p_begin:p_end;
            endvalues=zeros(size(checkrange));
            for k=1:length(checkrange);
                endvalues(k)=sum((rgb{t}(checkrange(k),:)-image1(i,:,j)).^2);
            end
            [value,index]=min(endvalues);
            value=value/3;
            value=sqrt(value);
        if value>1,
            pathout{t}(i,j)=NaN;
        else
            pathout{t}(i,j)=pathrange_orders{t}(checkrange(index));
        end
    end
end
check=not(isnan(pathout{t}(1,:)));
tempx=1:b;
tempy=pathout{t}(1,:);
tempx=tempx(check);
tempy=tempy(check);
warning('off','all');
p=polyfit(tempx,tempy,4);
newstart=polyval(p,1:b);
newstart=round(newstart);

% try
for i=1:a;
    for j=1:b;
            ll=(newstart(i)-80)/increment_pathrange;
            if or(ll<(lower_limit/increment_pathrange),ll>(upper_limit/increment_pathrange));
                ll=lower_limit/increment_pathrange;
            end
            ul=(newstart(i)+80)/increment_pathrange;
            if ul>upper_limit/increment_pathrange;
                ul=upper_limit/increment_pathrange;
            end
            checkrange=round(ll):round(ul);
            endvalues=zeros(size(checkrange));
            for k=1:length(checkrange);
                differencevalue=rgb{t}(checkrange(k),:)-image1(i,:,j);
                differencevalue=differencevalue.^2;
                endvalues(k)=sum(differencevalue);
            end
            [value,index]=min(endvalues);
%             area([1 3],[1 1],'FaceColor',rgb{t}(checkrange(index),:))
%             hold on
%             area([2 3],[1 1],'FaceColor',image1(i,:,j))
%             hold off
%             pause(0.1)
            value=value/3;
            value=sqrt(value);
        if value>0.3,
            pathout{t}(i,j)=NaN;
        else
            pathout{t}(i,j)=pathrange_orders{t}(checkrange(index));
        end
    end
    check=not(isnan(pathout{t}(i,:)));
    tempx=1:b;
    tempy=pathout{t}(i,:);
    tempx=tempx(check);
    tempy=tempy(check);
    p=polyfit(tempx,tempy,4);
    newstart=polyval(p,1:b);
    newstart=round(newstart);
end
end
image1=permute(image1,[1,3,2]);
% catch
%     i
%     j
%     plot(newstart)
%     newstart
%     tempx
%     tempy
%     p
%     hold on
%     plot(pathout{t}(i,:),'r')
%     checkrange
%     index
%     ll
%     ul
% end