function [out,errors]=relate_lines5(info,temperature) %out: most likely out of selection of peaks. Errors: shows index in INFO at which a temperature 5000K/15000K will give a different maximum intensity for a line
if not(exist('temperature','var'));
    temperature=[5000 10000 15000];
end
[a,b]=size(info);
k=8.6173324e-5;
out=cell(size(info));
errors=zeros(0,2);
d=1;
for i=1:a
    for j=1:b
        if not(isempty(info{i,j}))
            [l1,~]=size(info{i,j});
            g=zeros(l1,1);
            A=g;
            Ek=g;
            for l=1:l1
                try
                    g(l)=info{i,j}{l,21};
                catch
                    'g is empty'; %put something here if you want to show it
                end
                try
                    A(l)=info{i,j}{l,8};
                catch
                    'A is empty';
                end
                try
                    Ek(l)=info{i,j}{l,13};
                catch
                    'Ek is empty';
                end
            end
            h=1;
            index=zeros(3,1);
            for T=temperature
                factor=log(g.*A)-Ek./(k.*T);
                [~,index2]=max(factor);
                index(h)=index2(1);
                h=h+1;
            end
            if index(1)~=index(3)
                errors(d,:)=[i j];
                d=d+1;
            end
            out{i,j}=info{i,j}(index(2),:);
        end
    end
end
