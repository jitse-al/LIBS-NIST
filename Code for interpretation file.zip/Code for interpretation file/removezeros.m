function [zmx,zmy]=removezeros(x,y)
b=not(not(y));
zmx=x(b);
zmy=y(b);
end