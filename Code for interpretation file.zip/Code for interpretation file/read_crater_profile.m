function [datax,datay, total]=read_crater_profile(ratio, max_width);
[filename,pathname,~]=uigetfile('*.*');
[~,~,imported_image]=imread([pathname filename]);
data=imagetodata(imported_image,ratio);
[total,factor]=integrate_crater(data,max_width);
datax=1:length(data);
datax=datax*factor;
datay=data*factor;
