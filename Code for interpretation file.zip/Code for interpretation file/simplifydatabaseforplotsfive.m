function out=simplifydatabaseforplotsfive(nist)
[lx,~]=size(nist);
out=nist;
threshold=0.99;
for i=1:lx
    [lx2,~]=size(nist{i,1});
    for j=1:lx2
        if not(isempty(nist{i,1}{j,1}))
            maxvalue=max(cell2mat(nist{i,1}{j,1}(:,3)));
            maxvalue2=maxvalue*(1-threshold);
            [lx3,ly3]=size(nist{i,1}{j,1});
            g=0;
            outcell=cell(lx3,ly3);
            for k=1:lx3;
                if nist{i,1}{j,1}{k,3}>maxvalue2
                    g=g+1;
                    outcell(g,:)=nist{i,1}{j,1}(k,:);
                end
            end
            outcell=outcell(1:g,:);
            out{i,1}{j,1}=outcell;
        end
    end
end