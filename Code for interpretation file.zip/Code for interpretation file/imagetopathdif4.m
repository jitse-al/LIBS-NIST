function [d,rgb]=imagetopathdif4(im,centerx,centery,averageof)
[a,b,~]=size(im);
d=zeros(a*b,1);
rgb=reshape(im,a*b,3);
for i=1:a
    for j=1:b
        k=(i-1)*b+j;
        d(k)=sqrt((i-centerx)^2+(j-centery)^2);
    end
end
[d,index]=sort(d);
rgb=rgb(index,:);
d2=zeros(length(d)/averageof,1);
rgb2=zeros(length(d)/averageof,3);
for i=1:(length(d)/averageof);
    start=(i-1)*averageof+1;
    endpoint=i*averageof;
    d2(i)=mean(d(start:endpoint));
    rgb2(i,:)=mean(rgb(start:endpoint,:));
end
rgb=rgb2;
d=d2;
for i=1:3;rgb(:,i)=simplify2(rgb(:,i),20);end