function simplifydatabaseforplotssix(nist,extension)
parentfolder='C:\Users\Jitse\Documents\MATLAB';
foldername=[parentfolder '\' extension];
mkdir(foldername);
[lx,~]=size(nist);
for i=1:lx
    element=nist(i,:);
    save([foldername '\' extension num2str(i) '.mat'],'element');
end