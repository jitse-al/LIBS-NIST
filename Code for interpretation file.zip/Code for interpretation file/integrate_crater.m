function [total,factor]=integrate_crater(data,max_width)
[~,a]=max(data);
data=fliplr(data(1:a));
factor=max_width/a;
total=0;
for i=1:length(data);
    integration_value=data(i)*factor*pi*((i*factor)^2-((i-1)*factor)^2);
    total=total+integration_value;
end