function [xout,yout]=excludepeaks(x,y,peaks,range)
dx=(max(x)-min(x))/length(x);
endcheck=ones(size(x));
for i=1:length(peaks);
    x1=findxposition(x,peaks(i));
    beginx=round(x1-dx*range);
    endx=round(x1+dx*range);
    endcheck(beginx:endx)=zeros(endx-beginx+1,1);
end
xout=x(logical(endcheck));
yout=y(logical(endcheck));