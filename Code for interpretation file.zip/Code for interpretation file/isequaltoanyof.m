function output=isequaltoanyof(set_for_comparison,characters)
if not(isempty(set_for_comparison))
    characters=unique(characters);
    characters2=cell(size(characters));
    output=zeros(1,length(set_for_comparison));
    for i=1:length(characters);
        characters2{i}=characters(i);
    end
    characters=characters2;
    for i=1:length(characters);
        check2=set_for_comparison==characters{i};
        output=output+check2;
    end
else
    output=set_for_comparison;
end
end
