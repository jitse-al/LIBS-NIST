function [definite,double,none]=relate_lines7(info)
[a,~]=size(info);
definite=[];
double=[];
none=[];
for i=1:a
    [b,~]=size(info{i,6});
    if b==1
        definite=[definite;i];
    elseif b>1
        double=[double;i];
    else
        none=[none;i];
    end
end
definite=info(definite,:);
double=info(double,:);
none=info(none,:);