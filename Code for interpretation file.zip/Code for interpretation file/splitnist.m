function c=splitnist(elementlist)
c=cell(length(elementlist),2);
for i=1:length(elementlist)
    a=elementlist{i};
    d=a==' ';
    d1=d;
    for j=2:length(d);
        if d1(j-1)==1;
            d1(j)=1;
        end
    end
    d2=not(d1);
    d1=logical(d1.*not(d));
    c{i,1}=a(d2);
    c{i,2}=roman2num(a(d1));
end