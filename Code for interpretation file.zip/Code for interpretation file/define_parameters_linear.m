global numberoffiles leftbound rightbound ub lb npeaks xvalues yvalues cancelvalue

plot(xvalues,yvalues);

a=0; 
% first loop asks the questions. Important: split is set at a standard, but
% it can be redefined
x=inputdlg({'left boundary' 'right boundary','number of peaks'},'choose window');
if isempty(x)
    cancelvalue=1;
    return
end
leftbound=str2num(x{1});
rightbound=str2num(x{2});
npeaks=str2num(x{3});
[subsetx,subsety]=baselinesubstraction(xvalues,yvalues,leftbound,rightbound);
plot(subsetx,subsety)
while a==0;
    lb=zeros(npeaks,1);
    ub=zeros(npeaks,1);
    for i=1:npeaks;  %redefining parameters
        x=inputdlg({'lower limit peak' 'upper limit peak'},'choose window');
        if isempty(x)
            cancelvalue=1;
            return
        end
        lb(i)=str2num(x{1});
        ub(i)=str2num(x{2});
    end
    [subsetx,subsety]=baselinesubstraction(xvalues,yvalues,leftbound,rightbound);
    [~,tempoutput]=fitmultilorentz(subsetx,subsety,npeaks,lb,ub);
    plot(subsetx,subsety, subsetx,multilorentz(tempoutput,subsetx))
    
    choice=questdlg('subset ok?','check','yes','no','yes');
    switch choice
        case 'yes'
            a=1;
        case 'no'
            choice=questdlg('Redefine','Question','new peak limits','new boundaries','other number of peaks','new peak limits');
            switch choice
                case 'split'
                    split1=inputdlg('number of peaks');
                    if isempty(split1)
                        cancelvalue=1;
                        return
                    end
                    npeaks=str2num(split1{1});
                case 'new boundaries'
                    split2=inputdlg({'left bound','right bound'},'New boundaries');
                    if isempty(split2)
                        cancelvalue=1;
                        return
                    end
                    leftbound=str2num(split2{1});
                    rightbound=str2num(split2{2});
            end
    end
end


npeaksstring=['npeaks=' mat2str(npeaks) ';'];
leftboundstring=['leftbound=' mat2str(leftbound) ';'];
rightboundstring=['rightbound=' mat2str(rightbound) ';'];
lbstring=['lb=' mat2str(lb) ';'];
ubstring=['ub=' mat2str(ub) ';'];
totalstring=char(npeaksstring, leftboundstring, rightboundstring, lbstring, ubstring);
mat2clip(totalstring);
message=msgbox(char('Data copied to clipboard:', totalstring, '', 'copy into parameter_input.m'));
uiwait(message);