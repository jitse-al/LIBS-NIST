a=importdata('CaSO4pressed_GF13_delay000_04.txt');
datax=a(:,1);
datay=a(:,2);
limit1=655;
limit2=657;


[subsetx,subsety]=subset(datax,datay, limit1, limit2);
substry=baselinesubstraction(subsetx,subsety);



plot(x,y,x,substry);
figure;
peakfit([substrx,simplify(substry)],(limit1+limit2)/2,(limit2-limit1),5,20,0,10);