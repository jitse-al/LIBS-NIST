function peakbounds=extractbasesmall(x,y,steps,simplifynr)
if not(exist('simplifynr','var'));
    simplifynr=0;
end
range=1:length(y);
while and(y(1)>y(2),length(y)>3)
    range=range(2:length(y));
    y=y(2:length(y));
end
while and(y(length(y))>y(length(y)-1),length(y)>3)
    range=range(1:length(y)-1);
    y=y(1:length(y)-1);
end
x=x(range);
y=y-min(y);
y(1)=0;
y(length(y))=0;
ysimp=simplify2(y,simplifynr);
ymax=max(y);
ymin=min(y);
peakbounds2=[];
xnumber=1:length(x);
% plot(x,ysimp,x,y)
for i=1:steps;
    steprev=(cos(pi./steps.*i)+1)/2;
    height=steprev*(ymax-ymin)+ymin;
%     hold on
%     plot(x,height.*ones(size(x)),'g')
    [checkp,checkn,error]=checkzerocross2(ysimp-height);
    if not(error)
        peakbounds=[x(xnumber(logical(checkp))-1) x(xnumber(logical(checkn)))];
        peakbounds=[peakbounds zeros(size(peakbounds))];
        if i==1;
            peakbounds(:,3)=height.*ones(size(peakbounds(:,3)));
            peakbounds2=peakbounds;
        else
            peakbounds2=combine_peakbounds(peakbounds,peakbounds2,height);
        end
    end
end
peakbounds=peakbounds2;
