function AnonymousCompile(filenames,targetdir,besafe)
% ANANYMOUSCOMPILE compiles <filenames> and their
% dependents so that the paths of the original
% files are not present in the compiled files.
%
% *** WARNING ***
% This function copies and deletets files.  Please
% back up your work before attemting to run this
% funciton
%
% INPUTS     TYPE        DESCRIPTION
% filenames  CellString  List of files to compile
% targetdir  String      Target (temporary) directory
% besafe     Logical     1 = ask annoying questions, 0 = don't
%
% TO DO:
% [ ] Files are not removed from temporary directory after compilation
%
% SEE ALSO: mcc, depfun, depsubfun
%
% KEYWORDS: compiler standalone mcc directory depfun dependent
%
% It's not fancy, but it works

% Michael Robbins
% robbins@bloomberg.net
% MichaelRobbins1@yahoo.com
% MichaelRobbinsUsenet@yahoo.com

if nargin<2 targetdir='C:\MLTemp'; end;
if nargin<3 besafe=1; end;
if ~iscellstr(filenames) filenames = {filenames}; end;

% TARGET DIRECTORY
[targetroot,targetpath] =strtok(targetdir,filesep);
targetroot = [targetroot filesep];
targetpath = targetpath(2:end);
targetrootdup = dupbakslash(targetroot);
cd(targetroot);
system(['md ' targetpath]);
cd(targetpath);

% BACK UP PATH
p=path;

tffctr = 0;
% LOOP THORUGH EACH FILENAME
for fctr=1:length(filenames)
    % GET DEPENDENT FILE NAMES
    depfilenames=depfun(filenames,'-quiet');
    nonMLdepfilenames=depfilenames(setdiff([1:length(depfilenames)], ...
        strmatch(matlabroot,depfilenames)));

    % LOOP THROUGH ALL DEPENDENT FILES
    if ~isempty(nonMLdepfilenames)
        for ctr=1:length(nonMLdepfilenames)
            [pathstr,name,ext,versn] = fileparts(nonMLdepfilenames{ctr});
            % DEPFUN DOESN'T INCLUDE FIG FILES
            for extctr = 1:2
                if extctr==2 
                    ext = '.fig';  
                end;
                if extctr==1 || exist([name ext],'file')==2

                    % ADD FILE NAME
                    tffctr=tffctr+1;
                    targetfullfile{tffctr} = ...
                        [targetroot targetpath filesep name ext];

                    % DO FILES EXIST IN THE ROOT; IF SO, BACK `EM UP
                    dstr = targetfullfile{tffctr};
                    if exist(dstr,'file')==2
                        safesystem(sprintf('ren "%s" "%s.SARMGP"', ...
                            dstr,dstr),besafe);
                    end;

                    % COPY FILES SO THE PATH WON'T BE IN THE COMPILED CODE
                    [pathstr,name,ext2,versn] = ...
                        fileparts(nonMLdepfilenames{ctr});
                    safesystem(sprintf('copy "%s" "%s"', ...
                        [pathstr filesep name ext],dstr),besafe);
                end;
            end;
        end;
    end;    

    % REMOVE PATH FROM MATLAB
    a=regexp(p,[dupbakslash(matlabroot) '[^\;]*\;'],'match');
    path(sprintf('%s',a{:}));

    % COMPILE (LIST ALL FILE NAMES)
    try
        eval(['mcc -m ' sprintf( ...
            [dupbakslash(targetdir) filesep filesep '%s '], ...
            filenames{:}) ]);
    catch    
        fprintf('ERROR *** mcc failed ***\n');
        % RESTORE PATH TO MATLAB
        path(p);
    end;
    % RESTORE PATH TO MATLAB
    path(p);

    for ctr = 1:length(tffctr)
        dstr = targetfullfile{ctr};
        % REMOVE NEW FILES FROM ROOT
        safedelete(dstr,besafe);
        % RESTORE BACKUPS, IF THEY EXIST
        if exist([dstr '.SARMGP'],'file')==2
            safesystem(sprintf('ren "%s.SARMGP" "%s"',dstr,dstr),besafe);
        end;
    end;
    % ERASE INTERMEDIATE FILES FROM COMPILATION
    safedelete([filenames{fctr} '*.c'],besafe);
    safedelete([targetroot 'mccExcludedFiles.log'],besafe);
    
end;

%_____________________________

function outstr = dupbakslash(instr)
% DUPBAKSLASH duplicates the backslash in the string
% so that the string can be used in SPRINTF and REGEXP

outstr = strrep(instr,'\','\\');

%______________________________

function safedelete(filename,besafe)
% SAFEDELETE prompts before deleting. If deletion
% is affected, the deleted files are sent to the
% recycle bin.

if nargin<2 besafe = 1; end;

if besafe
    status = recycle;
    recycle('on');
    R = input(dupbakslash(['Delete ' filename ' [Y/N]?']),'s');
    if ~isempty(R) && upper(R(1))=='Y'
        delete(filename);
    else
        fprintf(['**** file ' filename ' NOT deleted.\n']);
    end;
    recycle(status);
else
    delete(filename);
end;
%______________________________

function safesystem(command,besafe)
% SAFESYSTEM prompts before executing a safesystem command.

if nargin<2 besafe = 1; end;

if besafe
    R = input(dupbakslash(['Execute "' command '" [Y/N]?']),'s');
    if ~isempty(R) && upper(R(1))=='Y'
        system(command);
    else
        fprintf(['**** "' command '" NOT executed.\n']);
    end;
else
    system(command);
end;