function c=contrasting_colors(n)
a=1:n;
a=a/n*2*pi;
b_1=1/2*sin(a)+1/2;
b_2=1/2*sin(a+2/3*pi)+1/2;
b_3=1/2*sin(a+4/3*pi)+1/2;
c=transpose([b_1;b_2;b_3]);
end
