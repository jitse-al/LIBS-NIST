function varargout = Libsfigure(varargin)
% LIBSFIGURE MATLAB code for Libsfigure.fig
%      LIBSFIGURE, by itself, creates a new LIBSFIGURE or raises the existing
%      singleton*.
%
%      H = LIBSFIGURE returns the handle to a new LIBSFIGURE or the handle to
%      the existing singleton*.
%
%      LIBSFIGURE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LIBSFIGURE.M with the given input arguments.
%
%      LIBSFIGURE('Property','Value',...) creates a new LIBSFIGURE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Libsfigure_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Libsfigure_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Libsfigure

% Last Modified by GUIDE v2.5 11-May-2016 14:13:53

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @Libsfigure_OpeningFcn, ...
    'gui_OutputFcn',  @Libsfigure_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Libsfigure is made visible.
function Libsfigure_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Libsfigure (see VARARGIN)

% Choose default command line output for Libsfigure
handles.output = hObject;

% togglebutton2_Callback(handles.togglebutton2, eventdata, handles)
pause(0.1)
database=load('C:\Users\Jitse\Documents\MATLAB\vacuum_plot_99.mat');
handles.elementalplots=cell(118,2);
handles.spectrnr=1;
colors=contrasting_colors(118);
for i=1:118
    colors(i,:)=colors(i,:)/max(colors(i,:));
end
children=get(handles.uipanel3,'Children');
for i=1:size(children);
    tagstring=get(children(i),'Tag');
    tagnr=str2num(tagstring(13:length(tagstring)));
    set(children(i),'String',cell2mat(database.nist10(tagnr,2)));
end
handles.elementalcolors=colors;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Libsfigure wait for user response (see UIRESUME)
% uiwait(handles.Libsfigure);


% --- Outputs from this function are returned to the command line.
function varargout = Libsfigure_OutputFcn(hObject, eventdata, handles)

% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
global legend_spectrum_string legend_string filename pathname filterindex
hold on
[filename,pathname,filterindex]=uigetfile('*.*');
if not(filename)
    return
end
try
    delete(handles.axes1.mainfigureplot);
end
handles.path=pathname;
extension=findfilextension(filename);
directory=dir([pathname '**' extension]);
directory=struct2cell(directory);
directory=sortrows(directory',5);
filenamesall=directory(:,1);
check=ones(size(filenamesall));
handles.xvaluesall=cell(size(filenamesall));
handles.yvaluesall=handles.xvaluesall;
for i=1:length(filenamesall);
    try
        data=importdata([pathname filenamesall{i}]);
        handles.xvaluesall{i}=data(:,1);
        handles.yvaluesall{i}=data(:,2);
    catch
        check(i)=0;
    end
end
check=logical(check);
handles.xvaluesall=handles.xvaluesall(check);
handles.yvaluesall=handles.yvaluesall(check);
filenamesall=filenamesall(check);
set(handles.popupmenu2,'String',filenamesall);
for i=1:length(filenamesall);
    if strcmp(filenamesall{i},filename)
        handles.xvalues=handles.xvaluesall{i};
        handles.yvalues=handles.yvaluesall{i};
        set(handles.popupmenu2,'Value',i);
    end
end
handles.axes1.mainfigureplot=plot(handles.xvalues,handles.yvalues/max(handles.yvalues));
xlabel('Wavelength (nm)')
ylabel('Intensity (normalized)')
legend_spectrum_string='Spectrum';
legend_string=define_legend_string;
legend(legend_string);
zoom on
xlim([min(handles.xvalues),max(handles.xvalues)]);
guidata(Libsfigure,handles);


% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
switch get(handles.uipanel3,'Visible')
    case 'on'
        set(handles.uipanel3,'Visible','off')
        set(handles.uipanel6,'Visible','off')
    case 'off'
        set(handles.uipanel3,'Visible','on')
        set(handles.uipanel6,'Visible','on')
end
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
Averagespectra_figure;
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
Multispectral_analysis_figure;
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
Autofit_figure;
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
Define_parameters_figure
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
eval(['global nistdatabase ' get(hObject,'String')])
if (get(hObject,'Value')==get(hObject,'Max'))
    eval([get(hObject,'String') '=['', nistdatabase.'' get(hObject,''String'')];']);
else
    eval([get(hObject,'String') '='''';']);
end


% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2


% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
eval(['global nistdatabase ' get(hObject,'String')])
if (get(hObject,'Value')==get(hObject,'Max'))
    eval([get(hObject,'String') '=['', nistdatabase.'' get(hObject,''String'')];']);
else
    eval([get(hObject,'String') '='''';']);
end
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3


% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
eval(['global nistdatabase ' get(hObject,'String')])
if (get(hObject,'Value')==get(hObject,'Max'))
    eval([get(hObject,'String') '=['', nistdatabase.'' get(hObject,''String'')];']);
else
    eval([get(hObject,'String') '='''';']);
end
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox4


% --- Executes on button press in checkbox5.
function checkbox5_Callback(hObject, eventdata, handles)
eval(['global nistdatabase ' get(hObject,'String')])
if (get(hObject,'Value')==get(hObject,'Max'))
    eval([get(hObject,'String') '=['', nistdatabase.'' get(hObject,''String'')];']);
else
    eval([get(hObject,'String') '='''';']);
end
% hObject    handle to checkbox5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox5


% --- Executes on button press in checkbox6.
function checkbox6_Callback(hObject, eventdata, handles)
eval(['global nistdatabase ' get(hObject,'String')])
if (get(hObject,'Value')==get(hObject,'Max'))
    eval([get(hObject,'String') '=['', nistdatabase.'' get(hObject,''String'')];']);
else
    eval([get(hObject,'String') '='''';']);
end
% hObject    handle to checkbox6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox6


% --- Executes on button press in checkbox7.
function checkbox7_Callback(hObject, eventdata, handles)
eval(['global nistdatabase ' get(hObject,'String')])
if (get(hObject,'Value')==get(hObject,'Max'))
    eval([get(hObject,'String') '=['', nistdatabase.'' get(hObject,''String'')];']);
else
    eval([get(hObject,'String') '='''';']);
end
% hObject    handle to checkbox7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox7


% --- Executes on button press in checkbox8.
function checkbox8_Callback(hObject, eventdata, handles)
eval(['global nistdatabase ' get(hObject,'String')])
if (get(hObject,'Value')==get(hObject,'Max'))
    eval([get(hObject,'String') '=['', nistdatabase.'' get(hObject,''String'')];']);
else
    eval([get(hObject,'String') '='''';']);
end
% hObject    handle to checkbox8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox8


% --- Executes on button press in checkbox9.
function checkbox9_Callback(hObject, eventdata, handles)
eval(['global nistdatabase ' get(hObject,'String')])
if (get(hObject,'Value')==get(hObject,'Max'))
    eval([get(hObject,'String') '=['', nistdatabase.'' get(hObject,''String'')];']);
else
    eval([get(hObject,'String') '='''';']);
end
% hObject    handle to checkbox9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox9


% --- Executes on button press in checkbox10.
function checkbox10_Callback(hObject, eventdata, handles)
eval(['global nistdatabase ' get(hObject,'String')])
if (get(hObject,'Value')==get(hObject,'Max'))
    eval([get(hObject,'String') '=['', nistdatabase.'' get(hObject,''String'')];']);
else
    eval([get(hObject,'String') '='''';']);
end
% hObject    handle to checkbox10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox10


% --- Executes on button press in checkbox11.
function checkbox11_Callback(hObject, eventdata, handles) %#ok<*DEFNU>
eval(['global nistdatabase ' get(hObject,'String')])
if (get(hObject,'Value')==get(hObject,'Max'))
    eval([get(hObject,'String') '=['', nistdatabase.'' get(hObject,''String'')];']);
else
    eval([get(hObject,'String') '='''';']);
end
% hObject    handle to checkbox11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox11


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles) %#ok<*INUSD>
global C Ca Cl Fe H Mg N Na O S nistdatabase elementplot legend_string legend_database_string
if elementplot~=1;
    delete(elementplot)
    elementplot=1;
end
string1=[C Ca Cl Fe H Mg N Na O S];
if not(isempty(string1))
    string1=string1(3:length(string1));
    eval(['elementplot=databaseplot(' string1 ');']);
else
    legend_database_string='';
    legend_string=define_legend_string;
end
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object deletion, before destroying properties.
function axes1_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function uipanel2_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to uipanel2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object deletion, before destroying properties.
function checkbox2_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes when user attempts to close Libsfigure.
function Libsfigure_CloseRequestFcn(hObject, eventdata, handles)
global legend_spectrum_string
legend_spectrum_string='';
% hObject    handle to Libsfigure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
delete(hObject);


% --- Executes during object creation, after setting all properties.
function Libsfigure_CreateFcn(hObject, eventdata, handles)
parameter_input;
parameter_input_2;
% hObject    handle to Libsfigure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
k=get(hObject,'Value');
handles.xvalues=handles.xvaluesall{k};
handles.yvalues=handles.yvaluesall{k};
set(handles.axes1.mainfigureplot,'YData',handles.yvalues./max(handles.yvalues))
zoom on
guidata(Libsfigure,handles);
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2


% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on mouse motion over figure - except title and menu.
function Libsfigure_WindowButtonMotionFcn(hObject, eventdata, handles)
get(gcf,'CurrentPoint');
% hObject    handle to Libsfigure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function Libsfigure_WindowButtonDownFcn(hObject, eventdata, handles)
get(gcf,'CurrentPoint')
% hObject    handle to Libsfigure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

function togglebutton2_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton3_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton4_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton5_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton6_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton7_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton8_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton9_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton10_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton11_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton12_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton13_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton14_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton15_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton16_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton17_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton18_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton19_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton20_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton21_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton22_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton23_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton24_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton25_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton26_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton27_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton28_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton29_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton30_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton31_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton32_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton33_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton34_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton35_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton36_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton37_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton38_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton39_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton40_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton41_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton42_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton43_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton44_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton45_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton46_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton47_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton48_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton49_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton50_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton51_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton52_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton53_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton54_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton55_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton56_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton57_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton58_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton59_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton60_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton61_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton62_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton63_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton64_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton65_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton66_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton67_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton68_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton69_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton70_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton71_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton72_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton73_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton74_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton75_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton76_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton77_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton78_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton79_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton80_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton81_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton82_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton83_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton84_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton85_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton86_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton87_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton88_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton89_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton90_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton91_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton92_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton93_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton94_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton95_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton96_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton97_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton98_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton99_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton100_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton101_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton102_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton103_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton104_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton105_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton106_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton107_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton108_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton109_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton110_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton111_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton112_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton113_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton114_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton115_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton116_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton117_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);

function togglebutton118_Callback(hObject, eventdata, handles)
togglebutton1_Callback(hObject, eventdata, handles);


% --- Executes on button press in togglebutton1.
function togglebutton1_Callback(hObject, eventdata, handles)
ritzplot=get(handles.ritz,'Value');
obsplot=get(handles.observed,'Value');
a=get(hObject,'Value');
f=get(hObject,'Tag');
f=f(13:length(f));
try
    handles.databaseselection;
catch
    handles.databaseselection=1;
end
switch handles.databaseselection
    case 1
        database=load(['C:\Users\Jitse\Documents\MATLAB\air\air' f]);
    case 2
        database=load(['C:\Users\Jitse\Documents\MATLAB\vacuum\vacuum' f]);
    case 3
        database=load(['C:\Users\Jitse\Documents\MATLAB\findinglist\findinglist' f]);
        ritzplot=0;
        obsplot=1;
end
database=database.element;
f=str2num(f);
if a
    maxx=max(handles.xvalues);
    minx=min(handles.xvalues);
    values=cell(size(handles.spectrnr));
    k=1;
    for i=handles.spectrnr;
        try
            values{k}=cell2mat(database{1,1}{i,1}(:,1:3));
            k=k+1;
        catch
            currentstring=get(handles.text4,'String');
            [sizec,~]=size(currentstring);
            if sizec>4;
                newstring=[{['No lines found for state ' database{2} ' ' num2roman(i)]};currentstring(1:4,:)];
            else
                newstring=[{['No lines found for state ' database{2} ' ' num2roman(i)]};currentstring];
            end
            set(handles.text4,'String',newstring);
        end
    end
    values=values(1:k-1);
    handles.elementalplots{f,1}=cell(size(values'));
    handles.elementalplots{f,2}=cell(size(values'));
    hold on
    set(hObject,'BackGroundColor',handles.elementalcolors(f,:))
    for i=1:length(values);
        if ritzplot
            try
                values{i}=sortrows(values{i},2);
                k=ones(size(values{i}(:,2)));
                for j=1:length(values{i}(:,2))
                    if values{i}(j,1)>maxx
                        k(j)=0;
                    end
                    if values{i}(j,1)<minx
                        k(j)=0;
                    end
                end
                k=logical(k);
                values2=values{i}(k,:);
                [x,y]=vertlines2(values2(:,1),zeros(size(values2(:,2))),values2(:,3)./max(values2(:,3)));
                handles.elementalplots{f,2}{i}=line(x,y,'Color',handles.elementalcolors(f,:)/i,'LineStyle',':','LineWidth',1.5);
            end
        end
        if obsplot
            try
                values{i}=sortrows(values{i},1);
                k=ones(size(values{i}(:,3)));
                for j=1:length(values{i}(:,3))
                    if values{i}(j,2)>maxx
                        k(j)=0;
                    end
                    if values{i}(j,2)<minx
                        k(j)=0;
                    end
                end
                k=logical(k);
                values2=values{i}(k,:);
                [x,y]=vertlines2(values2(:,1),zeros(size(values2(:,1))),values2(:,3)./max(values2(:,3)));
                handles.elementalplots{f,1}{i}=line(x,y,'Color',handles.elementalcolors(f,:)/i,'LineWidth',1.5);
            end
        end
    end
else
    for i=1:length(handles.elementalplots{f,1})
        for j=1:2
            delete(handles.elementalplots{f,j}{i});
        end
    end
    set(hObject,'BackGroundColor',[240 240 240]/255)
end
zoom on
uistack(handles.axes1.mainfigureplot,'top')

guidata(gcf,handles)
% hObject    handle to togglebutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton1


% --- Executes on button press in ritz.
function ritz_Callback(hObject, eventdata, handles)
% hObject    handle to ritz (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ritz


% --- Executes on button press in observed.
function observed_Callback(hObject, eventdata, handles)
% hObject    handle to observed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of observed



function edit1_Callback(hObject, eventdata, handles)
value=get(hObject,'String');
[numbers2,~]=roman2nummultiple(value);
handles.spectrnr=numbers2;
guidata(gcf,handles);
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when selected object is changed in uipanel5.
function uipanel5_SelectionChangeFcn(hObject, eventdata, handles)
a=get(handles.radiobutton1,'Value');
a(2)=get(handles.radiobutton2,'Value');
a(3)=get(handles.radiobutton3,'Value');
[~,handles.databaseselection]=max(a);
guidata(gcf,handles)
% hObject    handle to the selected object in uipanel5
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
ritzplot=get(handles.ritz,'Value');
obsplot=get(handles.observed,'Value');
filenames=get(handles.popupmenu2, 'String');
filename=filenames{get(handles.popupmenu2,'Value')};
ax=gca;
set(ax,'Units','pixels');
position=get(ax,'Position');
handles.axes1
leftspace=80;
upspace=50;
position=position+ [-leftspace -upspace leftspace, upspace];
if get(handles.radiobutton1,'Value')
    dattypestring='Air';
elseif get(handles.radiobutton2,'Value')
    dattypestring='Vacuum';
else
    dattypestring='Observed lines DLR';
end
dattypestring=['Datatype_' dattypestring];
pathname=handles.path;
xlimits=axis;
xstring=['from ' num2str(round(xlimits(1))) ' to ' num2str(round(xlimits(2)))];
legendstring={'Spectrum'};
legendcolor={[0 0 1]};
for i=1:118;
    eval(['a1=get(handles.togglebutton' num2str(i) ',''Value'');']);
    if a1
        eval(['a2=get(handles.togglebutton' num2str(i) ',''String'');']);
        if exist('elstring','var')
            elstring=[elstring ', ' a2];
            
            
        else
            elstring=['Elements ' a2];
        end
        color1=handles.elementalcolors(i,:);
        for j=handles.spectrnr
            if ritzplot
                try
                not(isempty(handles.elementalplots{i,2}{j}));
                    legendstring=[legendstring {[a2 ' ' num2roman(j)]}];
                    legendcolor=[legendcolor {color1/j}];
                end
            elseif obsplot
                try not(isempty(handles.elementalplots{i,1}{j}));
                    legendstring=[legendstring {[a2 ' ' num2roman(j)]}];
                    legendcolor=[legendcolor {color1/j}];
                end
            end
        end
    end
end
if not(exist('elstring','var'))
    totalstring=[filename ' ' xstring '_ No elements'];
else
    totalstring=[filename ' ' xstring '_' elstring];
end
totalstring=[totalstring ' ' dattypestring];
l=legend(legendstring);
children=get(l,'Children');
lc=length(children);
for i=1:(lc/3);
    set(children(lc+2-i*3),'Color',legendcolor{i});
    set(children(lc+2-i*3),'LineWidth',1.5)
end
set(handles.uipanel1,'Visible','off')
set(handles.uipanel3,'Visible','off')
set(handles.Libsfigure,'Color',[1 1 1]);
f=getframe(gcf,position);
set(handles.Libsfigure,'Color',[1 1 1]*0.941);
set(handles.uipanel1,'Visible','on')
set(handles.uipanel3,'Visible','on')
legendstring={'Spectrum'};
l=legend(legendstring);
children=get(l,'Children');
set(children(2),'Color',[0 0 1]);





[test,map]=frame2im(f);
imwrite(test,[pathname totalstring '.jpg'],'jpg')

%saveas(gca,[pathname totalstring '.jpg'])


% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
