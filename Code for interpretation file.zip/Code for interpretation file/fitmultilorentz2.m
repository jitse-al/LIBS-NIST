function inputvalues=fitmultilorentz2(x,y,numberofpeaks,lb,ub,highs)
if not(exist('highs','var'))
    highs=max(y).*ones(size(lb)).*2;
end
paramub=inf(numberofpeaks,3); 
paramlb=zeros(numberofpeaks,3);
% paramub=inf(numberofpeaks+1,3); %initial paramaters, all upper bounds set to infinite
% paramlb=zeros(numberofpeaks+1,3); %initial paramaters, all lower bounds set to zero
paramlb(1:numberofpeaks,1)=lb;
paramub(1:numberofpeaks,1)=ub;
paramub(1:numberofpeaks,2)=highs;
paramub(1:numberofpeaks,3)=max(x)-min(x);
options=optimoptions('lsqcurvefit','Display','off','MaxFunEvals',40,'MaxIter',100);
parameters=lsqcurvefit(@multilorentz2,ones(size(paramub)),x,y,paramlb,paramub,options);
% plot(x,y,x,multilorentz2(parameters,x));
% pause(0.1);
parameters=parameters(1:numberofpeaks,:);
inputvalues=parameters;
end