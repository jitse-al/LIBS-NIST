function plotlinescans
pathname=uigetdir;
if not(pathname);
    return
end
samplename='pyrrhotite';
switch samplename
    case 'pyrite'
        filternames={'75�5cm^{-1}';
            '147�7.5 cm^{-1}';
            '215�5 cm^{-1}';
            '245�5 cm^{-1}';
            '260�10 cm^{-1}';
            '341�10 cm^{-1}';
            '378�10 cm^{-1}';
            '427�5 cm^{-1}';
            '455�5 cm^{-1}';
            '465�5 cm^{-1}';
            '660�30 cm^{-1}';
            '850�100 cm^{-1}';
            '1320�20 cm^{-1}';
            '1430�100 cm^{-1}';
            '1480�20 cm^{-1}'};
        filtersizes=[7.0841624;
            0;
            0;
            0;
            0;
            37.5803175;
            56.59336;
            1.8799973;
            0;
            0;
            0;
            1.767961;
            0;
            0;
            0];
    case 'pyrrhotite'
        filternames={'82�20 cm^{-1}';
            '240�20 cm^{-1}';
            '335�30 cm^{-1}';
            '360�10 cm^{-1}';
            '470�20 cm^{-1}';
            '660�50 cm^{-1}';
            '880�125 cm^{-1}';
            '1320�20 cm^{-1}';
            '1350�250 cm^{-1}';
            '1480�20 cm^{-1}'};
        filtersizes=[3.5664804;
            0.3328434;
            0.140114375;
            -0.083250045;
            0.044356156;
            -0.145513155;
            1.1575096;
            0.176597595;
            0.01632309;
            -0.21296484];
    case 'pyrite+ZnO'
        filternames={'75�5cm^{-1}';
            '147�7.5 cm^{-1}';
            '215�5 cm^{-1}';
            '245�5 cm^{-1}';
            '260�10 cm^{-1}';
            '341�10 cm^{-1}';
            '378�10 cm^{-1}';
            '427�5 cm^{-1}';
            '455�5 cm^{-1}';
            '465�5 cm^{-1}';
            '660�30 cm^{-1}';
            '850�100 cm^{-1}';
            '1320�20 cm^{-1}';
            '1430�100 cm^{-1}';
            '1480�20 cm^{-1}';
            '435�5 cm^{-1}';
            '95�5 cm^{-1}'};
end

NrMeasurements=3;
Repetitions=2;

NrFilters=length(filternames);

pathnames=cell(3,1);
pathnames{1}=[pathname '\1st\'];
pathnames{2}=[pathname '\2nd\'];
pathnames{3}=[pathname '\3rd\'];
nameend=' Export File (Y-Axis).txt';
quantilemin=zeros(NrFilters,1)+1;
quantilemax=zeros(NrFilters,1)-1;
yvalues=cell(NrMeasurements,Repetitions);
xvalues=cell(NrMeasurements,Repetitions);
xmodel=cell(NrMeasurements,1);
ymodel=cell(NrMeasurements,1);
for i=1:NrMeasurements
    switch i
        case 1
            cr=[1 0 0];
        case 2
            cr=[0 0 1];
        case 3
            cr=[0 1 0];
        case 4
            cr=[0 0 0];
    end
    xmax=100000;
    for j=1:Repetitions;
        string1=[pathnames{i} num2str(j) '\01 Export File (X-Axis).txt'];
        xvalues{i,j}=importdata(string1);
        yvalues{i,j}=zeros(length(xvalues{i,j}),NrFilters);
        for k=1:NrFilters
            if k<10;
                string=['0' num2str(k)];
            else
                string=num2str(k);
            end
            string2=[pathnames{i} num2str(j) '\' string nameend];
            yvalues{i,j}(:,k)=importdata(string2);
        end
        yvalues{i,j}=flipud(yvalues{i,j});
        for k=1:NrFilters
            figure(k);
            hold all
            quantiletempmin=quantile(yvalues{i,j}(:,k),0.05);
            quantiletempmax=quantile(yvalues{i,j}(:,k),0.97);
            if quantiletempmin<quantilemin(k);
                quantilemin(k)=quantiletempmin;
            end
            if quantiletempmax>quantilemax(k);
                quantilemax(k)=quantiletempmax;
            end
            switch j
                case 1
                    plot(xvalues{i,j},yvalues{i,j}(:,k),'o','Color',cr);
                case 2
                    plot(xvalues{i,j},yvalues{i,j}(:,k),'x','Color',cr);
            end
        end
    end
    for j=1:Repetitions;
        xmaxtemp=max(xvalues{i,j});
        if xmaxtemp<xmax;
            xmax=xmaxtemp;
        end
    end
    xmax=floor(xmax);
    xmodel{i}=(1:xmax)';
    ymodel{i}=zeros(xmax,NrFilters);
    for k=1:NrFilters;
        for j=1:Repetitions
            ytemp=yvalues{i,j}(:,k);
            check=ytemp<quantile(ytemp,0.98);            
            xtemp=xvalues{i,j};
            ytemp=ytemp(check);
            xtemp=xtemp(check);
            check=ytemp>quantile(ytemp,0.07);
            ytemp=ytemp(check);
            xtemp=xtemp(check);
            ymodel{i}(:,k)=ymodel{i}(:,k)+interp1(xtemp,ytemp,xmodel{i});
        end
        ymodel{i}(:,k)=ymodel{i}(:,k)/Repetitions;
        ymodel{i}(:,k)=simplify2(simplify2(ymodel{i}(:,k),30),30);
        figure(k)
        hold on
        plot(xmodel{i}(1:(xmax-1)),ymodel{i}(1:(xmax-1),k),'Color',cr,'LineWidth',2);
    end
    
    
end
mkdir([pathname '\figures'])
quantilemax=quantilemax.*1.5;
quantilemin=quantilemin.*1.5;
for i=1:NrFilters;
    figure(i);
    ylim([quantilemin(i) quantilemax(i)]);
    tempmaxvalues=[];
    for j=1:NrMeasurements
        tempmaxvalues=[tempmaxvalues max(xmodel{j})];
    end
    xlim([0 max(tempmaxvalues)])
    title(['Average for filter: ' filternames{i}],'FontName','Helvetica','FontSize',17);
    xlabel('Distance from crater center (\mum)','FontName','Helvetica','FontSize',16);
    ylabel('Relative intensity (a.u.)','FontName','Helvetica','FontSize',16)
    saveas(figure(i),[pathname '\figures\filter' num2str(i) '.jpg']);
end
close all
pause(0.1);
intensitymodel=cell(NrFilters,1);
for i=1:NrFilters;
    intensitymodel{i}=zeros(600);
    tl=length(ymodel{1}(:,i));
    p=polyfit([(tl-200):tl]',ymodel{1}((tl-200):tl,i),1);
    tempymodel=1:(8800);
    endvalue=filtersizes(i);
    beginvalue=polyval(p,tl);
    nonnegativecheck=sign(endvalue-beginvalue);
    if not(nonnegativecheck==sign(p(1)));
        p(1)=-p(1);
    end
    D=(beginvalue-endvalue)/p(1);
    b=(-D*tl-tl^2)/(2*D+tl);
    a=(beginvalue-endvalue)*tl^2/(tl+b);
    tempymodel=a.*(tempymodel+b)./tempymodel.^2+endvalue;
    %b=tl-((beginvalue-endvalue)/p(1))/(-0.5);
    %a=(beginvalue-endvalue)*(tl-b)^2;
    %tempymodel=a./(tempymodel-b).^2+endvalue;
    for j=1:length(tempymodel)
        if j>-b
            tempymodel(j)=endvalue;
        end
    end
    tempymodel(1:(tl-1))=ymodel{1}(1:(tl-1),i);
    tempymodel2=tempymodel;
    for j=-100:100;
        avsize=20;
        tempymodel(j+tl)=mean(tempymodel2(j+tl-avsize:j+tl+avsize));
    end
    tempymodel=removeisnanaverage(tempymodel);
        
        
    for j=1:600;
        for k=1:600;
            d=sqrt((j-300)^2+(k-300)^2)*10;
            d=round(d);
            if not(d);
                d=1;
            end
                intensitymodel{i}(j,k)=tempymodel(d);
        end
    end
end
save([pathname '\Modeled_intensity.mat'],'intensitymodel','xvalues','yvalues','xmodel','ymodel')
            

