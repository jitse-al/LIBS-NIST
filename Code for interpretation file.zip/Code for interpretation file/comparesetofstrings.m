function [commonstring,uniquestringsbegin,uniquestringsend]=comparesetofstrings(beginstring,string_cell_array,mode)
if not(exist('mode','var'));
    mode='nothing';
end
commonstring=beginstring;
for i=1:length(string_cell_array);
    string2=string_cell_array{i};
    pattern=strfind(string2,commonstring);
    while isempty(pattern);
        newlength=length(commonstring)-1;
        start=1;
        commonstring2=commonstring(start:(newlength+start-1));
        pattern=strfind(string2,commonstring2);
        while and(isempty(pattern),(start+newlength-1)<length(commonstring));
            commonstring2=commonstring(start:(newlength+start-1));
            start=start+1;
            pattern=strfind(string2,commonstring2);
        end
        commonstring=commonstring2;
    end
end
switch mode
    case 'exclude_numbers_end'
        ls=length(commonstring);
        k=ones(1,ls);
        for i=1:ls;
            point=ls-i+1;
            if not(isempty(str2num(commonstring(point))))
                k(point)=0;
            end
            if i>1;
                if k(point+1)==1;
                    k(point)=1;
                end
            end
        end
        commonstring=commonstring(logical(k));
    case 'nothing'
end
            
uniquestringsbegin=cell(size(string_cell_array));
uniquestringsend=cell(size(string_cell_array));
ls=length(commonstring);
for i=1:length(string_cell_array);
    string2=string_cell_array{i};
    pattern=strfind(string2,commonstring);
    uniquestringsbegin{i}=string2(1:(pattern(1)-1));
    uniquestringsend{i}=string2((pattern(1)+ls):length(string2));
end