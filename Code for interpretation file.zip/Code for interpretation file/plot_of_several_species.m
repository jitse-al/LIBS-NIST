function plot_of_several_species(wavelength,intensity,species)
speciessorts=char(['Fe'; 'S '; 'O ']);
a=length(wavelength);
b=length(speciessorts);
outputwavelength=zeros(a,b);
for i=1:length(speciessorts);
    outputwavelength(:,i)=wavelength;
end
outputintensity=zeros(a,b);
for i=1:b;
    speciesb=speciessorts(i);
    for j=1:a
        if strcmp(speciesb,species(j));
            outputintensity(i,j)=intensity(j);
        end
    end
end
for i=1:b;
    plot(outputwavelength(:,i),outputintensity(:,1));
end
end
            