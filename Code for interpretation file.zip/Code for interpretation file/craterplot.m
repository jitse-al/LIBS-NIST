function craterplot(crater,standard,center)
close all
model=scatteredInterpolant(standard(:,1),standard(:,2),standard(:,3),'natural');
x=crater(:,1);
y=crater(:,2);
z=model(x,y);
z=z-crater(:,3);
centerx=center(1);
centery=center(2);
centerz=center(3)-model(centerx,centery);
z=z-max(z)-centerz;
model2=scatteredInterpolant(x,y,z,'natural');
x2=x;
y2=y';
for i=1:length(x)-1
    x2=[x2 x];
    y2=[y2;y'];
end
z2=model2(x2,y2);
surf(sortrows(x2),sortrows(y2')',z2)
d=sqrt((x-centerx).^2+(y-centery).^2);
figure
[d2,index]=sortrows(d);
z3=z(index);
plot(d2,z3,'o')
modelvalue=100;
x3=zeros(modelvalue,length(d));
y3=x3;
z4=x3;
for i=1:modelvalue;
    k=2.*pi/modelvalue*i;
    for j=1:length(x);
        x3(i,j)=(cos(k))*d2(j)+max(d2);
        y3(i,j)=(sin(k))*d2(j)+max(d2);
        z4(i,j)=z3(j);
    end
end
xlength=length(x)*modelvalue
size(x3)
size(y3)
size(z4)
model3=scatteredInterpolant(reshape(x3,xlength,1),reshape(y3,xlength,1),reshape(z4,xlength,1),'natural','none');
x4=(1:modelvalue)/modelvalue*2*max(d);
y4=(1:modelvalue)/modelvalue*2*max(d);
y4=y4';
x4=repmat(x4,modelvalue,1);
y4=repmat(y4,1,modelvalue);
z5=model3(x4,y4);
figure
surf(x4,y4,z5);
end

