function [positions,possible_species,info,findinglist]=relate_lines(parameters,database,type,boundary,includes,findinglist)
if not(exist('includes','var'));
    includes={'none'};
end
if not(exist('boundary','var'));
    boundary=0.015;
end
if not(exist('type','var'))
    type='Ritz';
end
switch type
    case 'Ritz'
        wtype=4;
    case 'Observed'
        wtype=5;
end
if not(exist('findinglist','var'))
    switch database
        case 'findinglist'
            findinglist=load('C:\Users\Jitse\Documents\MATLAB\findinglist.mat');
            wtype=4;
            findinglist=findinglist.findinglist8;
        case 'Nist vacuum'
            findinglist=load('C:\Users\Jitse\Documents\MATLAB\Vacuum.mat');
            findinglist=findinglist.nist5;
        case 'Nist vacuum 1'
            findinglist=load('C:\Users\Jitse\Documents\MATLAB\nistvac1.mat');
            findinglist=findinglist.nistvac1;
        case 'Nist vacuum 2'
            findinglist=load('C:\Users\Jitse\Documents\MATLAB\nistvac2.mat');
            findinglist=findinglist.nistvac2;
        case 'Nist vacuum 3'
            findinglist=load('C:\Users\Jitse\Documents\MATLAB\nistvac3.mat');
            findinglist=findinglist.nistvac3;
        case 'Nist air 1'
            findinglist=load('C:\Users\Jitse\Documents\MATLAB\nistair1.mat');
            findinglist=findinglist.nistair1;
        case 'Nist air 2'
            findinglist=load('C:\Users\Jitse\Documents\MATLAB\nistair2.mat');
            findinglist=findinglist.nistair2;
        case 'Nist air 3'
            findinglist=load('C:\Users\Jitse\Documents\MATLAB\nistair3.mat');
            findinglist=findinglist.nistair3;
    end
end
tic
if not(strcmp(includes{1},'none'))
    k=[];
    lengthlist=length(includes);
    for i=1:length(findinglist);
        for j=1:lengthlist;
            if(strcmp(includes(j),findinglist(i)));
                k=[k;i];
            end
        end
    end
    k=unique(k);
    findinglist=findinglist(k,:);
end
toc

wavelengths=findinglist(:,wtype);
% k=[];
% % for i=1:length(wavelengths);
% %     if not(or(isempty(wavelengths{i}),isnan(wavelengths{i})))
% %         k=[k;i];
% %     end
% % end
% findinglist=findinglist(k,:);
% wavelengths=wavelengths(k,:);
% wavelengths=cell2mat(wavelengths);
[a,~]=size(parameters);


switch database
    case {'findinglist', 'Nist vacuum'}
        positions=zeros(a,1);
        wavelengths=findinglist(:,wtype);
        k=[];
        for i=1:length(wavelengths);
            if not(or(isempty(wavelengths{i}),isnan(wavelengths{i})))
                k=[k;i];
            end
        end
        findinglist=findinglist(k,:);
        wavelengths=wavelengths(k,:);
        wavelengths=cell2mat(wavelengths);
        for i=1:a
            wavelengthp=parameters(i,1);
            x1=findxposition(wavelengths,wavelengthp);
            x2=x1+1;
            test1=abs(wavelengthp-wavelengths(x1));
            test2=abs(wavelengthp-wavelengths(x2));
            if test2>test1
                positions(i)=x1;
            else
                positions(i)=x2;
            end
        end
        possible_species=findinglist(:,1);
        possible_species=possible_species(positions);
        info=findinglist(positions,:);
        positions=wavelengths(positions);
        positions=[positions,abs(positions-parameters(:,1))];
        [positions,index]=sortrows(positions,2);
        possible_species=possible_species(index);
        info=info(index,:);
    case {'Nist vacuum 1', 'Nist vacuum 2', 'Nist vacuum 3','Nist air 1', 'Nist air 2','Nist air 3'}
        info=cell(a,1);
        positions=[];
        possible_species=[];
        if not(strcmp(includes{1},'none'))
            info=cell(a,length(includes));
            for j=1:length(includes)
                includetemp=includes(j);
                k=[];
                for i=1:length(findinglist);
                    if(strcmp(includetemp,findinglist(i)));
                        k=[k;i];
                    end
                end
                k=unique(k);
                findinglisttemp=findinglist(k,:);
                wavelengths=cell2mat(findinglisttemp(:,wtype));
                for i=1:a
                    wavelengthp=parameters(i,1);
                    [x1,x2]=findxpositions(wavelengths,wavelengthp-boundary, wavelengthp+boundary);
                    info{i,j}=findinglisttemp(x1:x2,:);
                    k=zeros(x2-x1+1,1);
                    for l=1:(x2-x1+1)
                        if abs(info{i,j}{l,wtype}-wavelengthp)<0.03
                            k(l)=1;
                        end
                    end
                    k=logical(k);
                    info{i,j}=info{i,j}(k,:);
                end
            end
        end
end


