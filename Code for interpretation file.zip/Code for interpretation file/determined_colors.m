function c=determined_colors(n)
e=[0 0 1;1 0 0;0 1 0;1 0 1;1 1 0;0 1 1;0 0 0];
c=zeros(7.*n,3);
for i=1:n;
    c(7*i-6:7*i,:)=(e+i/5-1/5)./((i/5-1/5).*3+1);
end
end