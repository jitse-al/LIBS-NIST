function data=imagetodata(imported_image,ratio)
[~,b]=size(imported_image);
data=zeros(1,b);
for i=1:b
    [~,data(i)]=max(imported_image(:,i));
end
data=data/ratio;
data=data-data(2);