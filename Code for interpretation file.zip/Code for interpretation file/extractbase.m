function [basemodel,paramsall,stoppingreasons,peakbounds,peakbounds2]=extractbase(x,y)
slope_to_error_ratio=0;
checkrange=0.5;
range=5;

steps=100;
quantilenumber=0.30;

rangefactor=2;
simplifynr=3;
[basex,basey]=extractbase1(x,y,checkrange,range,slope_to_error_ratio);
peakbounds=extractbase2(x,y,basex,basey,steps,quantilenumber,simplifynr);
[basex2,basey2]=extractbase3(x,y,peakbounds, rangefactor);
%plot(basex2,basey2,basex,basey)
[basemodel,paramsall,stoppingreasons]=fitmultibase(x,basex2,basey2,basex,basey);
value=quantile(sort(abs(y-basemodel)),0.25);
checkvalue=0;
k=5;
basemodel2=basemodel;
rangefactor=1.5;
steps=100;
quantilenumber=0.30;
    
while and(checkvalue<value,k>0)
    if k<5;
        value=checkvalue;
    end
    k=k-1;
    peakbounds2=extractbase2(x,y,x,basemodel2,steps,quantilenumber,simplifynr);
    [lengthp,~]=size(peakbounds2);
%     while peakbounds2(lengthp,4)==0;
%         lengthp=lengthp-1;
%         peakbounds2=peakbounds2(1:lengthp,:);
%     end
    meanpeakbounds2=peakbounds2(:,4);
    meanpeakbounds2=mean(meanpeakbounds2(meanpeakbounds2>0));
    for i=1:lengthp
        if peakbounds2(i,4)==0;
            peakbounds2(i,4)=meanpeakbounds2;
        end
    end
    meanpeakbounds=peakbounds(:,4);
    meanpeakbounds=mean(meanpeakbounds(meanpeakbounds>0));
    peakbounds2(:,4)=peakbounds2(:,4)./mean(peakbounds2(:,4))*meanpeakbounds;
    [basex3,basey3]=extractbase3(x,y,peakbounds2, rangefactor);
    [basemodel2,paramsall,stoppingreasons]=fitmultibase(x,basex3,basey3,basex,basey);
    checkvalue=quantile(sort(abs(y-basemodel2)),0.25);
end
if checkvalue<value;
    basemodel=basemodel2;
    'Basemodel replaced'
end
% hold on
% plot(x(peakbounds2(:,1)),y(peakbounds2(:,1)),'o')
% plot(x(peakbounds2(:,2)),y(peakbounds2(:,2)),'o')
% plot(x(peakbounds(:,1)),y(peakbounds(:,1)),'or')
% plot(x(peakbounds(:,2)),y(peakbounds(:,2)),'or')





% % checkfactor=max(peakbounds(:,4)).*2;
% % for i=1:length(peakbounds2);
% %     if peakbounds2(i,4)>checkfactor;
% %         peakbounds2(i,3)=0;
% %     end
% % end
% 
% % height=max(y);
% % peakbounds=combine_peakbounds(peakbounds2,peakbounds,height);
% % 
% % rangefactor=2;
% % 
% [basex3,basey3]=extractbase3(x,y,peakbounds, rangefactor);
% plot(x,y,basex3,basey3)
% basey3=interp1(basex3,basey3,x);
% basey2=interp1(basex2,basey2,x);
% basey=interp1(basex,basey,x);
% ybase=zeros(size(x));
% for i=1:length(x);
%     ybase(i)=min([basey3(i) basey2(i) basey(i)]);
% end
% 
% [basemodel,paramsall,stoppingreasons]=fitmultibase(x,x,ybase,x,ybase);