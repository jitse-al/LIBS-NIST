function [rangestart, rangelength]=findrangesofone(x)
rangestart=[];
rangelength=[];
k=0;
j=0;
for i=1:size(x)
    if x(i)
        if k==0;
            rangestart=[rangestart;i];
            j=1;
            k=1;
        else
            j=j+1;
            if i==length(x);
                rangelength=[rangelength;j];
            end
        end
    elseif j>0;
        rangelength=[rangelength;j];
        j=0;
        k=0;
    end
end