function m_area=multiarea(data,scalemin,scalemax)
if not(exist('scalemin'));
    scalemin=0;
end
if not(exist('scalemax'))
    scalemax=1;
end
hold on
[a,~]=size(data);
for i=1:a
    x=[data(i,:)];
    y=[scalemax scalemax];
    m_area(i)=area(x,y,'BaseValue',scalemin);
    alpha(0.3);
end
set(m_area,'FaceColor',[1 1 0]);
set(m_area,'EdgeColor','none');
end