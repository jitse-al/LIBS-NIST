function varargout = Periodic_Table_selector_2(varargin)
% PERIODIC_TABLE_SELECTOR_2 MATLAB code for Periodic_Table_selector_2.fig
%      PERIODIC_TABLE_SELECTOR_2, by itself, creates a new PERIODIC_TABLE_SELECTOR_2 or raises the existing
%      singleton*.
%
%      H = PERIODIC_TABLE_SELECTOR_2 returns the handle to a new PERIODIC_TABLE_SELECTOR_2 or the handle to
%      the existing singleton*.
%
%      PERIODIC_TABLE_SELECTOR_2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PERIODIC_TABLE_SELECTOR_2.M with the given input arguments.
%
%      PERIODIC_TABLE_SELECTOR_2('Property','Value',...) creates a new PERIODIC_TABLE_SELECTOR_2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Periodic_Table_selector_2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Periodic_Table_selector_2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Periodic_Table_selector_2

% Last Modified by GUIDE v2.5 01-Feb-2016 16:09:59

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Periodic_Table_selector_2_OpeningFcn, ...
                   'gui_OutputFcn',  @Periodic_Table_selector_2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Periodic_Table_selector_2 is made visible.
function Periodic_Table_selector_2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Periodic_Table_selector_2 (see VARARGIN)

% Choose default command line output for Periodic_Table_selector_2
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Periodic_Table_selector_2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Periodic_Table_selector_2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
a=imread('C:\Users\Jitse\Documents\MATLAB\Periodic table off.jpg');
axes(handles.axes1);
imshow(a,'border','tight')
position=get(handles.axes1,'Position');
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonDownFcn(hObject, eventdata, handles)
position1=get(gcf,'CurrentPoint');
position2=get(handles.axes1,'Position');
a=imread('C:\Users\Jitse\Documents\MATLAB\Periodic table off.jpg');
b=imread('C:\Users\Jitse\Documents\MATLAB\Periodic table on.jpg');
[width,length,~]=size(a);
position3=position1;
position3(1)=round((position1(1)-position2(1))/position2(3).*length);
position3(2)=width-round((position1(2)-position2(2))/position2(4).*width);
pushbuttons=load('C:\Users\Jitse\Documents\MATLAB\pushbuttonpositions');
pushbuttons=pushbuttons.pushbuttonpositions;
for i=1:118;
    if and(position3(1)>pushbuttons{i}{1}(1),position3(1)<pushbuttons{i}{1}(2))
        if and(position3(2)>pushbuttons{i}{2}(1),position3(2)<pushbuttons{i}{2}(2))
            x1=pushbuttons{i}{1}(1)
            x2=pushbuttons{i}{1}(2)
            y1=pushbuttons{i}{2}(1)
            y2=pushbuttons{i}{2}(2)
            a(y1:y2,x1:x2,:)=b(y1:y2,x1:x2,:);
        end
    end
end
axes(handles.axes1);
imshow(a)
position=get(handles.axes1,'Position');
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
