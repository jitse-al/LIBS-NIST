function profilepoints=extractprofilefrompic(picture)
[a,b,c]=size(picture);
path1=zeros(a,b);
for i=1:c;
    path1=path1+double(picture(:,:,i));
end
maxa=max(max(path1));
path2=path1<maxa;
steps=10;
stepsall=1:steps;
power=3;
stepsall=stepsall.^power;
stepsall2=fliplr(stepsall);
stepsall=[stepsall 2.*max(stepsall)-stepsall2(2:length(stepsall2))];
stepsall=stepsall-1;
stepsall=round(stepsall./max(stepsall).*b);
stepsall(1)=1;
upper=zeros(2,length(stepsall));
upper(1,:)=stepsall;
lower=upper;
n=0;
for i=stepsall;
    n=n+1;
    temp=[];
    for j=1:a;
        if path2(j,i)
            temp=[temp j];
        end
    end
    upper(2,n)=min(temp);
    lower(2,n)=max(temp);
end
lower(2,1)=(lower(2,1)+upper(2,1))/2;
lower(2,length(lower))=(lower(2,length(lower))+upper(2,length(lower)))/2;
upper(2,length(lower))=lower(2,length(lower));
lower=fliplr(lower);
upper=upper(:,2:length(upper));
profilepoints=[lower upper];
profilepoints=profilepoints./max(max(profilepoints));
profilepoints(2,:)=-(profilepoints(2,:)-profilepoints(2,1));
profilepoints(1,2*steps-1)=0;
profilepoints(2,2*steps-1)=0;
profilepoints=flipud(rot90(profilepoints));

