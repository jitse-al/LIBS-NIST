function varargout = Periodic_Table_selector(varargin)
% PERIODIC_TABLE_SELECTOR MATLAB code for Periodic_Table_selector.fig
%      PERIODIC_TABLE_SELECTOR, by itself, creates a new PERIODIC_TABLE_SELECTOR or raises the existing
%      singleton*.
%
%      H = PERIODIC_TABLE_SELECTOR returns the handle to a new PERIODIC_TABLE_SELECTOR or the handle to
%      the existing singleton*.
%
%      PERIODIC_TABLE_SELECTOR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PERIODIC_TABLE_SELECTOR.M with the given input arguments.
%
%      PERIODIC_TABLE_SELECTOR('Property','Value',...) creates a new PERIODIC_TABLE_SELECTOR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Periodic_Table_selector_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Periodic_Table_selector_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Periodic_Table_selector

% Last Modified by GUIDE v2.5 27-Jan-2016 12:44:28

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Periodic_Table_selector_OpeningFcn, ...
                   'gui_OutputFcn',  @Periodic_Table_selector_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Periodic_Table_selector is made visible.
function Periodic_Table_selector_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Periodic_Table_selector (see VARARGIN)

% Choose default command line output for Periodic_Table_selector
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Periodic_Table_selector wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Periodic_Table_selector_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
togglebutton2_Callback(handles.togglebutton2, eventdata, handles)
pause(0.1)
a=load('vacuum_plot_99.mat');

handles.elementalplots=cell(118,2);
handles.elements=a.nist10;
colors=contrasting_colors(118);
for i=1:118
    colors(i,:)=colors(i,:)/max(colors(i,:));
end
handles.elementalcolors=colors;
guidata(gcf,handles);

% --- Executes on button press in togglebutton14.
function togglebutton14_Callback(hObject, eventdata, handles)
ritzplot=get(handles.ritz,'Value');
obsplot=get(handles.observed,'Value');
a=get(hObject,'Value');
f=get(hObject,'Tag');
f=f(13:length(f));
f=str2num(f);
if a
    values=cell(size(handles.spectrnr));
    k=1;
    for i=handles.spectrnr;
        try
            values{k}=cell2mat(handles.elements{f,1}{i,1}(:,1:3));
            k=k+1;
        catch
            ['No lines found for state ' num2roman(i)]
        end
    end
    values=values(1:k-1);
    handles.elementalplots{f,1}=cell(size(values'));
    handles.elementalplots{f,2}=cell(size(values'));
    hold on
    set(hObject,'BackGroundColor',handles.elementalcolors(f,:))
    for i=1:length(values);
        if ritzplot
            values{i}=sortrows(values{i},2);
            [x,y]=vertlines2(values{i}(:,2),zeros(size(values{i}(:,2))),values{i}(:,3));
            handles.elementalplots{f,2}{i}=line(x,y,'Color',handles.elementalcolors(f,:)/i,'LineStyle',':');
        end
        if obsplot
            values{i}=sortrows(values{i},1);
            [x,y]=vertlines2(values{i}(:,1),zeros(size(values{i}(:,1))),values{i}(:,3));
            handles.elementalplots{f,1}{i}=line(x,y,'Color',handles.elementalcolors(f,:)/i);
        end
    end
else
    for i=1:length(handles.elementalplots{f,1})
        for j=1:2
            delete(handles.elementalplots{f,j}{i});
        end
    end
    set(hObject,'BackGroundColor',[240 240 240]/255)
end
zoom on
guidata(gcf,handles)
% hObject    handle to togglebutton14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton14



function edit1_Callback(hObject, eventdata, handles)
value=get(hObject,'String');
[numbers2,~]=roman2nummultiple(value);
handles.spectrnr=numbers2;
guidata(gcf,handles);
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ritz.
function ritz_Callback(hObject, eventdata, handles)
% hObject    handle to ritz (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ritz


% --- Executes on button press in observed.
function observed_Callback(hObject, eventdata, handles)
% hObject    handle to observed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of observed


% --- Executes on button press in togglebutton2.
function togglebutton2_Callback(hObject, eventdata, handles)
getappdata(gcf,'test')

offset=1;
if get(hObject,'Value')
    a=1;
else
    a=-1;
end
%set(handles.figure1,'Visible','off')
position=get(handles.figure1, 'Position');
position(2)=position(2)-a*offset;
position(4)=position(4)+a*offset;
set(handles.figure1,'Position',position)

position=get(handles.uipanel4,'Position');
position(2)=position(2)+a;
set(handles.uipanel4,'Position',position)

position=get(handles.uipanel2,'Position');
position(2)=position(2)+a;
set(handles.uipanel2,'Position',position)
% check=findall(gcf);
% forbiddenlist=gcf;
% for i=1:length(check);
%     if not(check(i)==gcf)
%         children=get(check(i),'children');
%         forbiddenlist=[forbiddenlist;children]
%     end
% end
% for i=1:length(check);
%     d=[];
%     for j=1:length(forbiddenlist);
%         d=[d;check(i)==forbiddenlist(j)];
%     end
%     if sum(d)==0
%         position=get(check(i),'Position');
%         get(check(i),'children')
%         position(2)=position(2)+a;
%         set(check(i),'Position',position)
%     end
% end
%set(handles.figure1,'Visible','on')
% hObject    handle to togglebutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton2


% --- Executes when figure1 is resized.
function figure1_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in togglebutton3.
function togglebutton3_Callback(hObject, eventdata, handles)
togglebutton14_Callback(hObject,eventdata,handles)
setappdata(gcf,'test',24);
% hObject    handle to togglebutton14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton14


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
