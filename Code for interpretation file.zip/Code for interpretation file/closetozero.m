function crossedzero=closetozero(x,dependence)
factor=quantile(x,0.25)*dependence/100;
crossedzero=zeros(size(x));
for i=1:length(x)
    if and(x(i)-factor<0,x(i)+factor>0)
        crossedzero(i)=1;
    end
end