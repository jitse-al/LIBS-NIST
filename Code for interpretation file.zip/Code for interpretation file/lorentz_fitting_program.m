%run averagespectra first!
%remember to define the x_data; do this in parameter_input

global numberoffiles leftbound rightbound ub lb npeaks cancelvalue peakless_points outputend

close all
cancelvalue=0;
[filename,pathname,filterindex]=uigetfile('*.*');
xvalues=importdata([pathname 'xdata']);
yvalues=importdata([pathname filename]);
parameter_input
% [subsetx,subsety]=baselinesubstraction(xvalues,yvalues,leftbound,rightbound);
% [~,tempoutput]=fitmultilorentz(subsetx,subsety,npeaks,lb,ub);
% plot(subsetx,subsety, subsetx,multilorentz(tempoutput,subsetx))
peakless_points=leftbound;
[subsetx,subsety,~,baseline,subsety_real]=baseline_echelle(xvalues,yvalues,leftbound,rightbound,peakless_points);
[~,tempoutput]=fitmultilorentz(subsetx,subsety,npeaks,lb,ub);
plot(subsetx,subsety_real, subsetx,(multilorentz(tempoutput,subsetx)+baseline),subsetx,baseline)
legend('data','fit','baseline');
choice=questdlg('subset ok?','check','yes','no','yes');
if isempty(choice)
    return
end
switch choice
    case 'yes'
        a=1;
    case 'no'
        define_parameters
        if cancelvalue;
            return %#ok<UNRCH>
        end
end

proposedfilename=filename(1:length(filename)-1);
numberoffilesans=inputdlg({'number of files','start of filename'},'define input',1,{num2str(length(x_data)),proposedfilename});
if isempty(numberoffilesans)
    return
end
numberoffiles=str2num(numberoffilesans{1});
filenamestart=numberoffilesans{2};
output=zeros(npeaks.*numberoffiles,6);
parameters=zeros(npeaks.*numberoffiles,3);

close all
yvaluesall=zeros(size(xvalues),numberoffiles);
baselineall=zeros(size(subsetx),numberoffiles);
for j=1:numberoffiles;
    filename=[filenamestart num2str(j)];
    yvalues=importdata([pathname filename]);
    yvaluesall(:,j)=yvalues;
    [subsetx,subsety, slopevalue,baseline,subsety_real,n_orders]=baseline_echelle(xvalues,yvalues,leftbound,rightbound,peakless_points);
%   [subsetx,subsety,slopevalue,intersectvalue]=baselinesubstraction(xvalues,yvalues,leftbound,rightbound);
    [tempparameters,tempoutput]=fitmultilorentz(subsetx,subsety,npeaks,lb,ub);
    tempparameters(:,6)=slopevalue;
%   tempparameters(:,7)=intersectvalue;
    baselineall(:,j)=baseline;
    tempparameters=sortrows(tempparameters,2);
    parameternumber=j*npeaks;
    parameters(parameternumber-2:parameternumber,:)=tempoutput;
    for i=1:npeaks;
        outputnumber=numberoffiles.*(i-1)+j; %create sorting mechanism
        output(outputnumber,:)=tempparameters(i,:);
    end
end

firstrow=[];
for i=1:npeaks;
    firstrow=[firstrow; ones(numberoffiles,1).*i]; %#ok<AGROW>
end
output(:,1)=firstrow;
dlmwrite([pathname 'fittedpeakdata_lorentz' outputend], output,'newline', 'pc')


close all%plots of fits
hold on
for i=1:numberoffiles;
    [subsetx,subsety]=subset(xvalues,yvaluesall(:,i),leftbound,rightbound);
    fittedresults=multilorentz(parameters(i*npeaks-2:i*npeaks,:),subsetx);
    baseline=baselineall(:,i);
    baselineadded=fittedresults+baseline;
    plot(subsetx, baselineadded,'b')
    %plot(subsetx,voigty,'b'); %plot of fit
    plot(subsetx,subsety,'r'); %plot of data (turn on/off by %)
end
xlabel('wavelength')
ylabel('Peak height (relative)')
legend('Lorentzian fits by lsqcurvefit','data')
print('-r400', [pathname filenamestart '_data_vs_fittedpeaks' outputend],'-dpng')
saveas(1,[pathname filenamestart '_data_vs_fittedpeaks' outputend])

figure
colour=[0 0 1; 1 0 0; 0 1 0; 1 1 0; 1 0 1; 0 1 1];


%plots of center, height and width
subplot(3,1,1);
hold on
for j=1:npeaks;
    readbegin=1+numberoffiles.*(j-1);
    readend=numberoffiles+numberoffiles.*(j-1);
    plot(x_data, output(readbegin:readend,2),'Color',colour(j,:))
end
xlabel(x_data_title)
ylabel('Wavelength (nm) of peak center')
legend('peak 1', 'peak 2', 'peak 3','peak 4', 'peak 5', 'peak 6', 'peak 7', 'peak 8', 'peak 9', 'peak 10')
subplot(3,1,2);
hold on
for j=1:npeaks;
    readbegin=1+numberoffiles.*(j-1);
    readend=numberoffiles+numberoffiles.*(j-1);
    plot(x_data, output(readbegin:readend,3),'Color',colour(j,:))
end
xlabel(x_data_title)
ylabel('Peak height (relative)')
subplot(3,1,3);
hold on
for j=1:npeaks;
    readbegin=1+numberoffiles.*(j-1);
    readend=numberoffiles+numberoffiles.*(j-1);
    plot(x_data, output(readbegin:readend,4),'Color',colour(j,:))
end
xlabel(x_data_title)
ylabel('Peak width (FWHM, nm)')
print('-r400', [pathname filenamestart '_peak_parameters' outputend],'-dpng')
saveas(2,[pathname filenamestart '_peak_parameters' outputend])


