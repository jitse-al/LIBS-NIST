function [highestpeaksx,highestpeaksy]=highpeaks(x,y,n)
a=simplify2(simplify2(y));
maxn=zeros(n,1);
highestpeaksx=zeros(n,1);
highestpeaksy=zeros(n,1);
for i=1:n;
    maxn(i)=max(a);
    b=a-maxn(i);
    for j=1:size(b);
        if b(j)==0;
            a(j)=-400;
        end
    end
end
g=0;
for h=1:size(a);
    if a(h)==-400;
        g=g+1;
        highestpeaksx(g)=x(h);
        highestpeaksy(g)=y(h);
    end
end
end