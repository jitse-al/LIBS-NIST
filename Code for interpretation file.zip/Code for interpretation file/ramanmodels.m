function [output,fweights]=ramanmodels
%radii and distances from crater center in micrometer
radii=[650 1000 1500 2300];
distanceall=[0 200 400 600 800 1000 1200 1400 1600 1800 2000 2400 2800 3200 3600 4000];
samplename='pyrite';
pathname=uigetdir;
filterpath=[pathname '\filters'];
modeldata=load([pathname '\Modeled_intensity.mat']);
intensitymodel=modeldata.intensitymodel;
if not(pathname);
    return
end
radii=radii/10;

for l=1:length(distanceall);
distances=distanceall(l)/10*ones(size(radii));


switch samplename
    case 'pyrite'
        filtertotal=4;
        filternrs=[2 3 6 7 9 10];
        endstring=' Pyrite';
        xdata=importdata([filterpath '\01 Pyrite (X-Axis).txt']);
        beginstring='\0';
    case 'pyrrhotite'
        filtertotal=3;
        filternrs=[5,6];
        endstring=' Pyrrhotite';
        xdata=importdata([filterpath '\1 Pyrrhotite (X-Axis).txt']);
        beginstring='\';
end
endstring=[endstring ' (Y-Axis).txt'];
filterdata=zeros(487,filtertotal);
for i=1:filtertotal;
    filterdata(:,i)=importdata([filterpath beginstring num2str(i) endstring]);
end
fweights=zeros(filtertotal,length(radii));
centry=300;
output=zeros(length(filternrs),length(radii));

for i=1:length(radii);
    radius=radii(i);
    distance=round(distances(i));
    centrx=300+distance;
    check=zeros(600);
    for j=1:600;
        for k=1:600;
            d=sqrt((k-centrx)^2+(j-centry)^2);
            if d<radius
                check(j,k)=1;
            end
        end
    end
    
    for j=1:length(filternrs);
        f=filternrs(j);
        tempmodel=intensitymodel{f};
        tempmodel=tempmodel(logical(check));
        output(j,i)=mean(tempmodel);
    end
end
modelspectra=zeros(487,length(radii));
for i=1:length(radii);
    switch samplename
        case 'pyrite'
            fweights(2,i)=1;
            fweights(3,i)=(output(3,i)+output(4,i))/94.17368;
            if fweights(3,i)<0;
                fweights(3,i)=0;
            end
            fweights(4,i)=(output(1,i)+output(2,i))/22.95217;
            if fweights(4,i)<0;
                fweights(4,i)=0;
            end
            fweights(1,i)=(output(5,i)+output(6,i)-fweights(4,i)*31.55756)/9.11658;
            if fweights(1,i)<0;
                fweights(1,i)=0;
            end
        case 'pyrrhotite'
            fweights(1,i)=1;
            a1=2.5125;
            a2=0.3279;
            b1=0.3944;
            b2=1.0094;
            c=a2/a1;
            d=b2-c*b1;
            if output(2,i)<0
                output(2,i)=0;
            end
            fweights(3,i)=(output(2,i)-c*output(1,i))/d;
            if fweights(3,i)<0;
                fweights(3,i)=0;
            end
            fweights(2,i)=(output(1,i)-b1*fweights(3,i))/a1;
%             fweights(2,i)=(output(2,i)-output(1,i)*b2/b1)/(a2-a1*b2/b1);
%             fweights(3,i)=(output(1,i)-a1*fweights(2))/b1;            
    end
    for j=1:filtertotal;
        modelspectra(:,i)=modelspectra(:,i)+filterdata(:,j).*fweights(j,i);
    end
end
figure;
hold on;
colours=[1 0 0; 0 0 1; 0 1 0; 0 0 0];
lstring=cell(1,length(radii));
for i=1:length(radii)
    plot(xdata,modelspectra(:,i),'Color',colours(i,:));
    lstring{i}=['\oslash=' num2str(radii(i)*20) '\mum, d=' num2str(distances(i)*10) '\mum'];
end
xlim([0 550]);
ylim([430, 730]);
set(gcf,'Position',[0 0 2000 2000])
xlabel('Wavenumber (rel. cm^{-1})')
ylabel('Relative intensity (a.u.)')
legend(lstring);
print([pathname '\model ' samplename ' at d=' num2str(distances(1)*10)],'-djpeg','-r400')
close all
end