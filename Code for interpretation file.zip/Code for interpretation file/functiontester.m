function varargout = functiontester(varargin)
% FUNCTIONTESTER MATLAB code for functiontester.fig
%      FUNCTIONTESTER, by itself, creates a new FUNCTIONTESTER or raises the existing
%      singleton*.
%
%      H = FUNCTIONTESTER returns the handle to a new FUNCTIONTESTER or the handle to
%      the existing singleton*.
%
%      FUNCTIONTESTER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FUNCTIONTESTER.M with the given input arguments.
%
%      FUNCTIONTESTER('Property','Value',...) creates a new FUNCTIONTESTER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before functiontester_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to functiontester_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help functiontester

% Last Modified by GUIDE v2.5 09-Feb-2016 15:04:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @functiontester_OpeningFcn, ...
                   'gui_OutputFcn',  @functiontester_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before functiontester is made visible.
function functiontester_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to functiontester (see VARARGIN)

% Choose default command line output for functiontester
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes functiontester wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = functiontester_OutputFcn(hObject, eventdata, handles)
values=load('C:\Users\Jitse\Documents\MATLAB\Subsettester.mat');
handles.xvalues=values.subx;
handles.yvalues=values.suby;
plot(handles.xvalues,handles.yvalues)
handles.variable1=get(handles.slider1,'Value');
handles.variable2=get(handles.slider2,'Value');
handles.variable3=get(handles.slider3,'Value');
guidata(gcf,handles);
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
handles.variable1=round(get(hObject,'Value'));
extractbase1(handles.xvalues,handles.yvalues,handles.variable1,handles.variable2,handles.variable3);
guidata(gcf,handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
handles.variable2=get(hObject,'Value');
extractbase1(handles.xvalues,handles.yvalues,handles.variable1,handles.variable2,handles.variable3);
guidata(gcf,handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider3_Callback(hObject, eventdata, handles)
handles.variable3=round(get(hObject,'Value'));
extractbase1(handles.xvalues,handles.yvalues,handles.variable1,handles.variable2,handles.variable3);
guidata(gcf,handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
