function [lb,ub,heights,fwhms,lows]=redefine_peakbounds(x,ymodel,peakbounds)
rangenr=5;
peakbounds(:,1)=peakbounds(:,1)-rangenr;
peakbounds(:,2)=peakbounds(:,2)+rangenr;
peakbounds=sortrows(peakbounds,1);
lp=length(peakbounds(:,1));
for i=1:lp;
    if peakbounds(i,1)<1;
        peakbounds(i,1)=1;
    end
    if peakbounds(i,2)>length(x)
        peakbounds(i,2)=length(x);
    end
end
% Until here only preparation, making sure it doesn't override the x-limits

% FOLLOWING CREATES FIGURE to CHECK PEAKBOUNDS: UNCOMMENT IF NECESSARY
% figure
% multiarea(peakbounds(:,1:2),0,max(ymodel));
% hold on
% plot(ymodel)




% IF NEEDED: CHECK IF PEAKBOUNDS ARE HIGHER THAN ERRORS:
% % quantilenr=0.25;
% % dx=zeros(size(x));
% % for i=2:length(x);
% %     dx(i)=ymodel(i)-ymodel(i-1);
% % end
% % dx=sort(abs(dx));
% % dx=quantile(dx,quantilenr)
% % k=[];
% % for i=1:lp;
% %     yrange=ymodel(peakbounds(i,1):peakbounds(i,2));
% %     maxy=max(yrange);
% %     if maxy>(2*dx);
% %         k=[k;i];
% %     end
% % end
% % size(peakbounds)
% % peakbounds=peakbounds(k,:);
% % size(peakbounds)

k=1;
for i=1:(lp-1);
    if peakbounds(i,2)>peakbounds(i+1,1);
        peakbounds(i+1,1)=peakbounds(i,1);
    else
        k=[k;i];
    end
end
peakbounds=peakbounds(k,:);
% Fusing peakbounds that give double peaks;

lp=length(peakbounds(:,1));
peakbounds2=[];
for i=1:lp
    range=peakbounds(i,1):peakbounds(i,2);
    subx=x(range);
    suby=ymodel(range);
    fwhm=peakbounds(i,4);
    height=max(suby);
    low=min(suby);
    tempbounds=extractbasesmall(subx,suby,20,0);
    tempbounds(:,3)=ones(size(tempbounds(:,3))).*height;
    tempbounds(:,5)=ones(size(tempbounds(:,3))).*low;
    tempbounds(:,4)=ones(size(tempbounds(:,3))).*fwhm;
    peakbounds2=[peakbounds2; tempbounds];
end
%dx=(x(length(x))-x(1))/length(x);

peakbounds2=sortrows(peakbounds2,1);
%centers=(peakbounds2(:,1)+peakbounds2(:,2))./2;
% k=1;
% 
% for i=2:length(centers);
%     if centers(i)>(centers(i-1)+dx*4)
%         k=[k;i];
% %         peakbounds2(i-1,2)=peakbounds2(i,2);
%     else
%         peakbounds2(i-1,3)=max([peakbounds2(i,3) peakbounds2(i-1,3)]);
%     end
% end
% peakbounds2=peakbounds2(k,:);
lb=peakbounds2(:,1);
ub=peakbounds2(:,2);
heights=peakbounds2(:,3);
lows=peakbounds2(:,5);
fwhms=peakbounds2(:,4);





