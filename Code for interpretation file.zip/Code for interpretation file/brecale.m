function [csum]=brecale(a,b)
c=zeros(6,1);
ab=[a b];
ctotal=zeros(6,2880000);
counter=0;
for i=1:6;
    for j=1:2;
        c(i)=ab(i,j);
        for k=2:6
            for l=1:2
                c(k)=ab(k,l);
                for m=2:5
                    n=1;
                    if and(l==1,j==1)
                        n=2;
                    end
                    c(m)=ab(m,n);
                    for p=1:3000;
                        for o=1:6
                            if and(o~=i,and(o~=k,o~=m))
                                c(o)=round(rand*32-0.5);
                            end
                            counter=counter+1;
                            ctotal(1:6,counter)=c;
                        end
                    end
                end
            end
        end
    end
end
dtotal=ctotal;
dtotal(4,:)=zeros(1,length(dtotal));
csum=sum(dtotal);
end