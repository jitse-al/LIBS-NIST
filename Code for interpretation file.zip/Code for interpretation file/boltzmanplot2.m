function [factor1,factor2,T,A,g,Ek,a]=boltzmanplot2(info)
[a,~]=size(info);
intensity=zeros(a,1);
lambda=zeros(a,1);
g=zeros(a,1);
A=zeros(a,1);
Ek=zeros(a,1);
check=ones(a,1);
for i=1:a;
    intensity(i)=info{i,2}.*info{i,3}.*pi./2;
    lambda(i)=info{i,1};
    if not(isempty(info{i,6}{1,21}))
        g(i)=info{i,6}{1,21};
    else
        check(i)=0;
    end
    if not(isempty(info{i,6}{1,8}))
        A(i)=info{i,6}{1,8};
    else
        check(i)=0;
    end
    if not(isempty(info{i,6}{1,13}))
        Ek(i)=info{i,6}{1,13};
    else
        check(i)=0;
    end
end
check=logical(check);
A=A(check);
g=g(check);
Ek=Ek(check);

intensity=intensity(check);
lambda=lambda(check);

index=Ek<50;
Ek=Ek(index);
A=A(index);
g=g(index);
lambda=lambda(index);
intensity=intensity(index);

k=8.6173324e-5;
factor1=log(intensity.*lambda./(g.*A));
factor2=Ek;
a=polyfit(factor2,factor1,1);
T=1/(a(1)*(-k));
%plot(factor2,polyval(a,factor2),factor2,factor1,'o')