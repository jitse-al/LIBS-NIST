function [parameters,fittedresults,subx,suby,lowbpeaks,upbpeaks,nrpeaks]=fitallpeaks(x,y,baseline,peakbounds)
% leftbound=min(x);
% rightbound=max(x);
ymodel=y-baseline;
% lb=peakbounds(:,1);
% ub=peakbounds(:,2);
% npeaks=length(lb);
% for i=1:npeaks;
%     try
%         lb(i)=x(lb(i)-5);
%     catch
%         lb(i)=min(x);
%     end
%     try
%         ub(i)=x(ub(i)+5);
%     catch
%         ub(i)=max(x);
%     end
% end
[lb,ub,heights]=redefine_peakbounds(x,ymodel,peakbounds); %[lb,ub,heights,fwhms] --> from direct measurement, not precise
heights=heights./0.8;
npeaks=length(lb);
excludes=ones(size(x));
center=zeros(size(lb));
for i=1:npeaks;
    [b1,b2]=findxpositions(x,lb(i),ub(i));
    exclusionwidth=max(x(b1:b2))/80;
    center(i)=(b1+b2)./2;
    b3=round(center(i)-exclusionwidth);
    b4=round(center(i)+exclusionwidth);
    if b4>length(x);
        b4=length(x);
    end
    excludes(b3:b4)=zeros(b4-b3+1,1);
    center(i)=round(center(i));
end
[rangesstart,rangelength]=findrangesofone(not(excludes));
ranges=[rangesstart rangesstart+rangelength-1];
centerx=x(center);
subx=cell(length(ranges),1);
suby=cell(length(ranges),1);
lowbpeaks=cell(length(ranges),1);
upbpeaks=cell(length(ranges),1);
highs=cell(length(ranges),1);
nrpeaks=zeros(length(ranges),1);
for i=1:length(ranges);
    subx{i}=x(ranges(i,1):ranges(i,2));
    suby{i}=ymodel(ranges(i,1):ranges(i,2));
    check=and(centerx>=min(subx{i}),centerx<=max(subx{i}));
    lowbpeaks{i}=lb(check);
    upbpeaks{i}=ub(check);
    highs{i}=heights(check);
    nrpeaks(i)=length(lowbpeaks{i});
end
check=logical(nrpeaks);
subx=subx(check);
suby=suby(check);
lowbpeaks=lowbpeaks(check);
upbpeaks=upbpeaks(check);
nrpeaks=nrpeaks(check);
highs=highs(check);
%plot(x(not(excludes)),y(not(excludes)));

%[lowbpeaks,upbpeaks,nrpeaks,subx,suby]=split_parameters(x(logical(excludes)),ymodel(logical(excludes)),npeaks,leftbound,rightbound,lb,ub);

parameters=splitlorentzfit2(lowbpeaks,upbpeaks,nrpeaks,subx,suby,highs);

% test1=parameters(:,2)>1;
% parameters=parameters(test1,:);
fittedresults=multilorentz(parameters,x);
%plot(x,y-baseline,x,fittedresults);
end