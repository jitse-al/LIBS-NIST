function [factor1,factor2,T,a,name1plot,name2plot]=relate_lines9(definite,double2,double3,double4,double5,double6,double7)
totalinput=cell(5,1);
totalinput{1}=definite;
totalinput{2}=double2;
totalinput{3}=double3;
totalinput{4}=double6;
totalinput{5}=double7;
maxerror=0.3;
[names,numbers]=strcount(totalinput{1}(:,5));
[~,index]=max(numbers);
numbers(index)=0;
[~,index2]=max(numbers);
name1=names(index);
name2=names(index2);
name1plot=cell(5,1);
name2plot=cell(5,1);
totaloutput=cell(0,7);
n=1;

cellinput=cell(0,6);
for i=1:5
    name1plot{i}=cellinput;
    name2plot{i}=cellinput;
end

for i=1:5;
    [a1,~]=size(totalinput{i});
    for j=1:a1; 
        if totalinput{i}{j,4}<maxerror;
            if strcmp(totalinput{i}{j,5},name1)
                
                name1plot{i}=[name1plot{i};totalinput{i}(j,:)];

            end
            if strcmp(totalinput{i}{j,5},name2)
                name2plot{i}=[name2plot{i};totalinput{i}(j,:)];
            end
        end
        totaloutput(n,1:6)=totalinput{i}(j,:);
        totaloutput{n,7}=i;
    end
end

factor1=cell(5,1);
factor2=cell(5,1);
T=cell(5,1);
a=cell(5,1);

hold on
colors=contrasting_colors(5);
xlimits=zeros(0,2);
ylimits=zeros(0,2);
for i=1:5;
    [factor1{i},factor2{i},T{i},~,~,~,a{i}]=boltzmanplot2(name1plot{i});
    plot(factor2{i},factor1{i},'Color',colors(i,:),'LineStyle','o')
    plot(factor2{i},polyval(a{i},factor2{i}),'Color',colors(i,:))
    xlimits=[xlimits; min(factor2{i}) max(factor2{i})];
    ylimits=[ylimits; min(factor1{i}) max(factor1{i})];    
end
xlim([min(xlimits(:,1)) max(xlimits(:,2))]);
ylim([min(ylimits(:,1)) max(ylimits(:,2))]);
string1=['Single lines of ' cell2mat(name1)];
legend(string1,'','Overlapping lines of same species','', 'Overlapping lines using NIST intensity','','Overlapping lines using A, G and Ek values 1','','Overlapping lines using A, G and Ek values 2','')

figure
hold on
xlimits=zeros(0,2);
ylimits=zeros(0,2);
for i=1:5;
    [factor1{i},factor2{i},T{i},~,~,~,a{i}]=boltzmanplot2(name2plot{i});
    plot(factor2{i},factor1{i},'Color',colors(i,:),'LineStyle','o')
    plot(factor2{i},polyval(a{i},factor2{i}),'Color',colors(i,:))
    xlimits=[xlimits; min(factor2{i}) max(factor2{i})];
    ylimits=[ylimits; min(factor1{i}) max(factor1{i})];    
end
xlim([min(xlimits(:,1)) max(xlimits(:,2))]);
ylim([min(ylimits(:,1)) max(ylimits(:,2))]);
string1=['Single lines of ' cell2mat(name2)];
legend(string1,'','Overlapping lines of same species','', 'Overlapping lines using NIST intensity','','Overlapping lines using A, G and Ek values 1','','Overlapping lines using A, G and Ek values 2','')