[filename,pathname,filterindex]=uigetfile('*.*');
importeddata=importdata([pathname filename]);
xvalues=importeddata(:,1);
yvalues=importeddata(:,2);

peakshape=20;
extra=0;
NumTrials=5;

a=0;
split=2; 
% first loop asks the questions. Important: split is set at a standard, but
% it can be redefined
while a==0;
    rightbound=zeros(split,1);
    leftbound=zeros(split,1);
    numberofpeaks=zeros(split,1);
    for i=1:split;  %redefining parameters
        x=inputdlg({'left boundary' 'right boundary','number of peaks'},'choose window');
        leftbound(i)=str2num(x{1});
        rightbound(i)=str2num(x{2});
        numberofpeaks(i)=str2num(x{3});
        [subsetx,subsety]=baselinesubstraction(xvalues,yvalues,leftbound(i),rightbound(i));
        peakfit([subsetx subsety],(rightbound(i) + leftbound(i))/2,(rightbound(i)-leftbound(i)),numberofpeaks(i),peakshape,extra,NumTrials);
    end
    
    choice=questdlg('subset ok?','check','yes','no','yes');
    switch choice
        case 'yes'
            a=1;
        case 'no'
            choice=questdlg('Redefine','Question','new boundaries','split','new boundaries');
            switch choice
                case 'split'
                    split1=inputdlg('number of splits');
                    split=str2num(split1{1});
            end
    end
end

NumTrials=10;
result=[];
for i=1:split;  %redefining parameters
    residualmin=100;
    for extra=0:0.2:20;
        [subsetx,subsety]=baselinesubstraction(xvalues,yvalues,leftbound(i),rightbound(i));
        [FitResults,GOF]=peakfit([subsetx subsety],(rightbound(i) + leftbound(i))/2,(rightbound(i)-leftbound(i)),numberofpeaks(i),peakshape,extra,NumTrials);
        if GOF(1)<residualmin;
            residualmin=GOF(1);
            GOFs=GOF(1).*ones(numberofpeaks(i),1);
            endresults=[FitResults GOFs];
            bestextra=extra;
        end
    end
    result=[result;endresults];
    extra=bestextra;
    peakfit([subsetx subsety],(rightbound(i) + leftbound(i))/2,(rightbound(i)-leftbound(i)),numberofpeaks(i),peakshape,extra,NumTrials)
    print('-r400', [pathname filename '_data_vs_fittedpeaks' num2str(i)],'-dpng')
    saveas(1,[pathname filename '_data_vs_fittedpeaks' num2str(i)])
end
