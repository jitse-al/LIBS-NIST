function [vertplotvaluesx,vertplotvaluesy]=vertlines2(x,ymin,ymax)
xsize=size(x);
vertplotvaluesx=sort([x;x;x]);
vertplotvaluesy=zeros(size(vertplotvaluesx));
for i=1:xsize;
    vertplotvaluesy(i*3-2)=ymin(i);
    vertplotvaluesy(i*3-1)=ymax(i);
    vertplotvaluesy(i*3)=NaN;
end
end