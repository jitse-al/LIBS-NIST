function stringend=plot_lines(varargin)
load('Nist_Database_Fe.mat')
a=nargin;
string1='_Wavelength';
string2='_Intensity';
string3='_Species';
totalstring='';
for i=1:a;
    namestring=inputname(i);
    wavelength=[namestring string1 ','];
    intensity=[namestring string2 ','];
    species=[namestring string3 ','];
    addstring=[wavelength intensity species];
    totalstring=[totalstring addstring];
end
stringend=['load(''Nist_Database_Fe.mat'');' 'databaseplot(' num2str(a) ',' totalstring(1:length(totalstring)-1) ')'];
eval(stringend)
end