function c=contrasting_colors2(n)
a=zeros(1,n);
stepsize=2*pi/3;
position=0;
x=2;
for i=0:n-1;
    a(i+1)=position;
    position=position+stepsize;
    q=floor(position/pi);
    if  q>=x;
        stepsize=2*pi/n;
        position=position-1/2*stepsize;
        x=x+2;
    end
end
b_1=1/2*sin(a)+1/2;
b_2=1/2*sin(a+2/3*pi)+1/2;
b_3=1/2*sin(a+4/3*pi)+1/2;
c=transpose([b_1;b_2;b_3]);
end