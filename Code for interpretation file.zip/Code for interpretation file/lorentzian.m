function g=lorentzian(parameters,x) %parameters=[x0, height, width (FWHM)]
g=parameters(2).*parameters(3).^2./(4.*(x-parameters(1)).^2+(parameters(3)).^2);
end

% area=FWHM/2*a=height*pi
% height=2/(Pi*FWHM)

