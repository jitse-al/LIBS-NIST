function [T,R]=kubelka_munk2(K,S,h,Ri,R1)
%F2 --> F-
%F1 --> F+
% not defined: Ri, R1 
F0=1;
z0=h;
R2=R1;
alpha=(K.*(K+2.*S)).^0.5;
A=S./(S+K+alpha);
Delta=(1-R1./A).*(A-R2).*exp(-alpha.*z0)-(1-R1.*A).*(1./A-R2).*exp(alpha.*z0);
C1=(1-Ri).*(A-R2).*exp(-alpha.*z0)./Delta;
C2=-(1-Ri).*(1./A-R2).*exp(alpha.*z0)./Delta;

z=0;
F2=F0.*(C1.*exp(alpha.*z)./A+C2.*exp(-alpha.*z).*A);
z=h;
F1=F0.*(C1.*exp(alpha.*z)+C2.*exp(-alpha.*z));



R=Ri+(1-R1).*F2/F0;
T=(1-R2).*F1/F0;