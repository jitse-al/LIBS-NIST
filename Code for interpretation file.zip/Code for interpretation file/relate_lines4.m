function [likelyinfo,totalfactor,mostlikelyspecies,definitelines]=relate_lines4(parameters)
maxdeviation=0.02;
power_of_fit=1.5;
maxdeviation2=0.015;
weight_third_state=0.5;
mode='Observed';
includes={'Fe','S','Na','O'};

parameters2=sortrows(parameters,4);
[names,~,~]=relate_lines2(parameters2,maxdeviation,power_of_fit)


[~,~,info,~]=relate_lines(parameters,'Nist vacuum 1',mode,maxdeviation2,includes);
[likelyinfo_1,totalfactor1,ms1]=relate_lines3(info,parameters,mode,names);

[~,~,info,~]=relate_lines(parameters,'Nist vacuum 2',mode,maxdeviation2,includes);
[likelyinfo_2,totalfactor2,ms2]=relate_lines3(info,parameters,mode,names);

[~,~,info,~]=relate_lines(parameters,'Nist vacuum 3',mode,maxdeviation2,includes);
[likelyinfo_3,totalfactor3,ms3]=relate_lines3(info,parameters,mode,names);
totalfactor3=totalfactor3.*weight_third_state;

totalfactor=[totalfactor1 totalfactor2 totalfactor3]';
[totalfactor,check]=max(totalfactor);
totalfactor=totalfactor';
likelyinfo=cell(size(likelyinfo_1));
for i=1:length(check);
    switch check(i)
        case 1
            likelyinfo(i,:)=likelyinfo_1(i,:);
        case 2
            likelyinfo(i,:)=likelyinfo_2(i,:);
        case 3
            likelyinfo(i,:)=likelyinfo_3(i,:);
    end
end

mostlikelyspecies=[ms1;ms2];
[a,b]=size(mostlikelyspecies);
positionslist=0;
doublepositions=0;
for i=1:a
    templistpositions=mostlikelyspecies{i,4};
    for j=1:length(templistpositions)
        check=templistpositions(j)==positionslist;
        if sum(check)>0;
            doublepositions=[doublepositions;templistpositions(j)];
        end
    end
    positionslist=[positionslist;templistpositions];
end
doublepositions=unique(doublepositions);
for i=1:length(doublepositions);
    positionslist=positionslist(not(positionslist==doublepositions(i)));
end
doublepositions
positionslist
definitelines=cell(0);
for i=1:a
    templistpositions=mostlikelyspecies{i,4};
    for j=1:length(templistpositions)
        check=templistpositions(j)==positionslist;
        if sum(check)>0;
        definitelines=[definitelines;mostlikelyspecies{i,1}(templistpositions(j),:)];
        end
    end
end