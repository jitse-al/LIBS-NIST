function foundpeaks=findallpeaks(x)
foundpeaks=zeros(size(x));
for i=2:(size(x)-1);
    if and(x(i)>x(i-1),x(i)>x(i+1))
        foundpeaks(i)=x(i);
    end
end
end
    