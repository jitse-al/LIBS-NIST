%run averagespectra first!

peakshape=20;
extra=0;
NumTrials=5;

[filename,pathname,filterindex]=uigetfile('*.*');
xvalues=importdata([pathname 'xdata']);
yvalues=importdata([pathname filename]);
plot(xvalues,yvalues);

a=0;
split=2; 
% first loop asks the questions. Important: split is set at a standard, but
% it can be redefined
while a==0;
    rightbound=zeros(split,1);
    leftbound=zeros(split,1);
    numberofpeaks=zeros(split,1);
    for i=1:split;  %redefining parameters
        x=inputdlg({'left boundary' 'right boundary','number of peaks'},'choose window');
        leftbound(i)=str2num(x{1});
        rightbound(i)=str2num(x{2});
        numberofpeaks(i)=str2num(x{3});
        [subsetx,subsety]=baselinesubstraction(xvalues,yvalues,leftbound(i),rightbound(i));
        peakfit([subsetx subsety],(rightbound(i) + leftbound(i))/2,(rightbound(i)-leftbound(i)),numberofpeaks(i),peakshape,extra,NumTrials);
    end
    
    choice=questdlg('subset ok?','check','yes','no','yes');
    switch choice
        case 'yes'
            a=1;
        case 'no'
            choice=questdlg('Redefine','Question','new boundaries','split','new boundaries');
            switch choice
                case 'split'
                    split1=inputdlg('number of splits');
                    split=str2num(split1{1});
            end
    end
end

numberoffilesans=inputdlg({'number of files','start of filename'});
numberoffiles=str2num(numberoffilesans{1});
filenamestart=numberoffilesans{2};
peakperseries=sum(numberofpeaks);
output=zeros(peakperseries.*numberoffiles,7);


close all
yvaluesall=zeros(size(xvalues),numberoffiles);
for j=1:numberoffiles;
    filename=[filenamestart num2str(j)];
    yvalues=importdata([pathname filename]);
    yvaluesall(:,j)=yvalues;
    for i=1:split;
            %figure(i); %remove first % to show figure
            [subsetx,subsety,slopevalue,intersectvalue]=baselinesubstraction(xvalues,yvalues,leftbound(i),rightbound(i));
            tempfitoutput=peakfit([subsetx subsety],(rightbound(i) + leftbound(i))/2,(rightbound(i)-leftbound(i)),numberofpeaks(i),peakshape,extra,NumTrials);
            tempfitoutput(:,6)=slopevalue;
            tempfitoutput(:,7)=intersectvalue;
            tempfitoutput=sortrows(tempfitoutput,2);
            for n=1:numberofpeaks(i);
                outputnumber=numberoffiles.*sum(numberofpeaks(1:(i-1))+n-1)+j; %create sorting mechanism
                output(outputnumber,:)=tempfitoutput(n,:);
            end
        end
end
firstrow=[];
for i=1:peakperseries;
    firstrow=[firstrow; ones(numberoffiles,1).*i];
end
output(:,1)=firstrow;
dlmwrite([pathname 'fittedpeakdata'], output,'newline', 'pc')

close all%plots of fits
hold on

[subsetx,subsety]=subset(xvalues,yvaluesall(:,i),min(leftbound),max(rightbound));
for i=1:numberoffiles;
    fittedresults=zeros(size(subsetx));
    baseline=zeros(size(subsetx));
    for j=1:peakperseries;
        cp=(j-1).*numberoffiles+i;
        [subsetx,subsety]=subset(xvalues,yvaluesall(:,i),min(leftbound),max(rightbound));
        voigty=voigt3(subsetx,output(cp,2),output(cp,4),extra).*output(cp,3);
        fittedresults=fittedresults+voigty;
    end
    g=1;
    f=1;
    for h=1:size(subsetx)
        if and(subsetx(h)>rightbound(g),h<size(subsetx))
            g=g+numberofpeaks(f);
            f=f+1;
        end
        cp=(g-1).*numberoffiles+i;
        baseline(h)=subsetx(h).*output(cp,6)+output(cp,7);
    end
    baselineadded=fittedresults+baseline;
    plot(subsetx, baselineadded,'b')
    %plot(subsetx,voigty,'b'); %plot of fit
    plot(subsetx,subsety,'r'); %plot of data (turn on/off by %)
end
xlabel('wavelength')
ylabel('Peak height (relative)')
legend('fits by peakfit','data')
print('-r400', [pathname filenamestart '_data_vs_fittedpeaks'],'-dpng')
saveas(1,[pathname filenamestart '_data_vs_fittedpeaks'])

x_data=[1:30];
x_data_title='Shot number';
figure
colour=[0 0 1; 1 0 0; 0 1 0; 1 1 0; 1 0 1; 0 1 1];


%plots of center, height and width
subplot(3,1,1);
hold on
for j=1:peakperseries;
    readbegin=1+numberoffiles.*(j-1);
    readend=numberoffiles+numberoffiles.*(j-1);
    plot(x_data, output(readbegin:readend,2),'Color',colour(j,:))
end
xlabel(x_data_title)
ylabel('Wavelength (nm) of peak center')
legend('peak 1', 'peak 2', 'peak 3','peak 4', 'peak 5', 'peak 6', 'peak 7', 'peak 8', 'peak 9', 'peak 10')
subplot(3,1,2);
hold on
for j=1:peakperseries;
    readbegin=1+numberoffiles.*(j-1);
    readend=numberoffiles+numberoffiles.*(j-1);
    plot(x_data, output(readbegin:readend,3),'Color',colour(j,:))
end
xlabel(x_data_title)
ylabel('Peak height (relative)')
subplot(3,1,3);
hold on
for j=1:peakperseries;
    readbegin=1+numberoffiles.*(j-1);
    readend=numberoffiles+numberoffiles.*(j-1);
    plot(x_data, output(readbegin:readend,4),'Color',colour(j,:))
end
xlabel(x_data_title)
ylabel('Peak width (FWHM, nm)')
print('-r400', [pathname filenamestart '_peak_parameters'],'-dpng')
saveas(2,[pathname filenamestart '_peak_parameters'])


