function f=multilorentz(parameters,x)
f=zeros(size(x));
a=size(parameters);
numberofpeaks=a(1);
for i=1:numberofpeaks
    f=f+lorentzian(parameters(i,:),x);
end
end
    