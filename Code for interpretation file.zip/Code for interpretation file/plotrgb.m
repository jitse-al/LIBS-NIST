function plotrgb(x,rgb)
hold on
plot(x,rgb(:,1),'r')
plot(x,rgb(:,2),'g')
plot(x,rgb(:,3),'b')
hold off
end