global numberoffiles leftbound rightbound ub lb npeaks peakless_points outputend corrections filename xvalues yvalues x_data subsetx pathname x_data_title
corrections;
proposedfilename=filename(1:length(filename)-1);
numberoffilesans=inputdlg({'number of files','start of filename'},'define input',1,{num2str(length(x_data)),proposedfilename});
if isempty(numberoffilesans)
    return
end
numberoffiles=str2num(numberoffilesans{1});
filenamestart=numberoffilesans{2};
output=zeros(npeaks.*numberoffiles,5);
parameters=zeros(npeaks.*numberoffiles,3);

yvaluesall=zeros(size(xvalues),numberoffiles);
baselineall=zeros(size(subsetx),numberoffiles);
for j=1:numberoffiles;
    filename=[filenamestart num2str(j)];
    yvalues=importdata([pathname filename]);
    yvaluesall(:,j)=yvalues;
    [subsetx,subsety, slopevalue,baseline,subsety_real,n_orders]=baseline_echelle(xvalues,yvalues,leftbound,rightbound,peakless_points, corrections);
%   [subsetx,subsety,slopevalue,intersectvalue]=baselinesubstraction(xvalues,yvalues,leftbound,rightbound);
    [tempparameters,tempoutput]=fitmultilorentz(subsetx,subsety,npeaks,lb,ub);
%   tempparameters(:,6)=slopevalue;
%   tempparameters(:,7)=intersectvalue;
    baselineall(:,j)=baseline;
    tempparameters=sortrows(tempparameters,2);
    parameternumber=j*npeaks;
    parameters(parameternumber-2:parameternumber,:)=tempoutput;
    for i=1:npeaks;
        outputnumber=numberoffiles.*(i-1)+j; %create sorting mechanism
        output(outputnumber,:)=tempparameters(i,:);
    end
end

firstrow=[];
for i=1:npeaks;
    firstrow=[firstrow; ones(numberoffiles,1).*i]; %#ok<AGROW>
end
output(:,1)=firstrow;
dlmwrite([pathname 'fittedpeakdata_lorentz' outputend], output,'newline', 'pc')


close all%plots of fits
hold on
for i=1:numberoffiles;
    [subsetx,subsety]=subset(xvalues,yvaluesall(:,i),leftbound,rightbound);
    fittedresults=multilorentz(parameters(i*npeaks-2:i*npeaks,:),subsetx);
    baseline=baselineall(:,i);
    baselineadded=fittedresults+baseline;
    plot(subsetx, baselineadded,'b')
    %plot(subsetx,voigty,'b'); %plot of fit
    plot(subsetx,subsety,'r'); %plot of data (turn on/off by %)
end
xlabel('wavelength')
ylabel('Peak height (relative)')
legend('Lorentzian fits by lsqcurvefit','data')
print('-r400', [pathname filenamestart '_data_vs_fittedpeaks' outputend],'-dpng')
saveas(1,[pathname filenamestart '_data_vs_fittedpeaks' outputend])

figure
colour=[0 0 1; 1 0 0; 0 1 0; 1 1 0; 1 0 1; 0 1 1];


%plots of center, height and width
subplot(3,1,1);
hold on
for j=1:npeaks;
    readbegin=1+numberoffiles.*(j-1);
    readend=numberoffiles+numberoffiles.*(j-1);
    plot(x_data, output(readbegin:readend,2),'Color',colour(j,:))
end
xlabel(x_data_title)
ylabel('Wavelength (nm) of peak center')
legend('peak 1', 'peak 2', 'peak 3','peak 4', 'peak 5', 'peak 6', 'peak 7', 'peak 8', 'peak 9', 'peak 10')
subplot(3,1,2);
hold on
for j=1:npeaks;
    readbegin=1+numberoffiles.*(j-1);
    readend=numberoffiles+numberoffiles.*(j-1);
    plot(x_data, output(readbegin:readend,3),'Color',colour(j,:))
end
xlabel(x_data_title)
ylabel('Peak height (relative)')
subplot(3,1,3);
hold on
for j=1:npeaks;
    readbegin=1+numberoffiles.*(j-1);
    readend=numberoffiles+numberoffiles.*(j-1);
    plot(x_data, output(readbegin:readend,4),'Color',colour(j,:))
end
xlabel(x_data_title)
ylabel('Peak width (FWHM, nm)')
print('-r400', [pathname filenamestart '_peak_parameters' outputend],'-dpng')
saveas(2,[pathname filenamestart '_peak_parameters' outputend])


