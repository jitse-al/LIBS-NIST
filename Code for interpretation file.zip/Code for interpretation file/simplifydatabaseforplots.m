function out=simplifydatabaseforplots(nist)
out=cell(size(nist));
j=0;
for i=1:length(nist)
    if not(isnan(nist{i,6}));
        j=j+1;
        out(j,:)=nist(i,:);
    end
end
out=out(1:j,1:7);
out=putintocells2(out,[3,2]);
end