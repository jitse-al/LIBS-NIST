function inputvalues=splitlorentzfit2(lb,ub,npeaks,subx,suby,highs)
if not(exist('highs','var'))
    highs=cell(size(lb));
end
inputvalues=[];
for i=1:length(npeaks);
    subytemp=suby{i}-multilorentz(inputvalues,subx{i});
    try
        inputvaluestemp=fitmultilorentz2(subx{i},subytemp,npeaks(i),lb{i},ub{i},highs{i});
        inputvalues=[inputvalues;inputvaluestemp];
    catch
        ['error between ' num2str(min(subx{i})) ' and ' num2str(max(subx{i}))]
        for j=1:npeaks(i);
        inputvaluestemp=[lb{i}(j) 0 2];
        inputvalues=[inputvalues;inputvaluestemp];
        end
    end
    %     plot(subx{i},suby{i},subx{i},subytemp,subx{i},multilorentz2(inputvaluestemp,subx{i}))
    %     pause(0.1)
    
end
% for j=1:3;
%     k=1;
%     for i=1:length(npeaks);
%         try
%         inputvaluestemp=inputvalues(k:(k+npeaks(i)-1),:);
%         end
%         inputvalues(k:(k+npeaks(i)-1),:)=zeros(npeaks(i),3);
%         try
%             subytemp=suby{i}-multilorentz(inputvalues,subx{i});
%             inputvaluestemp=fitmultilorentz2(subx{i},subytemp,npeaks(i),lb{i},ub{i},highs{i});
%         catch
%             ['error between ' num2str(min(subx{i})) ' and ' num2str(max(subx{i}))]
%         end
%         %     plot(subx{i},suby{i},subx{i},subytemp,subx{i},multilorentz2(inputvaluestemp,subx{i}))
%         %     pause(0.1)
%         inputvalues(k:(k+npeaks(i)-1),:)=inputvaluestemp;
%         k=k+npeaks(i);
%     end
% end

end