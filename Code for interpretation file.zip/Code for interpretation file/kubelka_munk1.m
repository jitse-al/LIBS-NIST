function [T,R]=kubelka_munk1(K,S,h)
a=(K+S)./K;
b=sqrt(a.^2-1);
R=sinh(b.*S.*h)./(a.*sinh(b.*S.*h)+b.*cosh(b.*S.*h));
T=b./(a.*sinh(b.*S.*h)+b.*cosh(b.*S.*h));