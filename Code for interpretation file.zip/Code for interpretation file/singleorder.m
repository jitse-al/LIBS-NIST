function y=singleorder(params,xdata)
a=params(1);
b=params(2);
amplitude=params(3);
echelleorders2=find_echelle_orders(xdata(1),xdata(length(xdata)));
intervalsize=2*pi/(1/echelleorders2(1)-1/(echelleorders2(2)));
substractionfactor=mod(intervalsize/echelleorders2(1),2*pi);
y=amplitude.*sqrt(abs(sin(intervalsize./xdata-substractionfactor-0.5*pi)+1)/2);
y=y+a.*xdata+b;
end

