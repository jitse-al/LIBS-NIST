function out=relate_lines6(info,parameters)
[a,b]=size(info);
out=cell(a,6);
for i=1:a
    out{i,1}=parameters(i,1);
    out{i,2}=parameters(i,2);
    out{i,3}=parameters(i,3);
    out{i,4}=parameters(i,4);
    for j=1:b
        if not(isempty(info{i,j}))
            out{i,6}=[out{i,6};info{i,j}];
            out{i,5}=[out{i,5} ',' info{i,j}{1,1} ' ' num2roman(info{i,j}{1,2})];
        end
        
    end
    out{i,5}=out{i,5}(2:length(out{i,5}));
end

