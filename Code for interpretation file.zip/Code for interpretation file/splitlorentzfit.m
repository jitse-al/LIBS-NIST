function [parameters,inputvalues]=splitlorentzfit(lb,ub,npeaks,subx,suby)
parameters=[];
inputvalues=[];
for i=1:length(npeaks);
    [parameterstemp,inputvaluestemp]=fitmultilorentz(subx{i},suby{i},npeaks(i),lb{i},ub{i});
    parameters=[parameters;parameterstemp];
    inputvalues=[inputvalues;inputvaluestemp];
end
end