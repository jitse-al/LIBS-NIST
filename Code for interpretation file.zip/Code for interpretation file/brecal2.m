function [ctotal,csum]=brecal2(a,b)
ab=[a;b];
c=zeros(6,1);
counter=0;
ctotal=zeros(6,7864320);
for i=1:6;
    c(i)=a(i);
    for j=1:6;
        if j~=i
            c(j)=b(j);
            for k=0:11;
                cpos3=(mod(k,6)+1);
                if and(cpos3~=j,cpos3~=i)
                    c(cpos3)=ab(k+1);
                    remainingnr=setdiff(1:6,[i j cpos3]);
                    for l=0:31
                        c(remainingnr(1))=l;
                        for m=0:31
                            c(remainingnr(2))=m;
                            for n=0:31
                                c(remainingnr(3))=n;
                                counter=counter+1;
                                ctotal(:,counter)=c;
                            end
                        end
                    end
                end
            end
        end
    end
end
dtotal=ctotal;
dtotal(4,:)=zeros(1,7864320);
csum=sum(dtotal);
end
                                

                    