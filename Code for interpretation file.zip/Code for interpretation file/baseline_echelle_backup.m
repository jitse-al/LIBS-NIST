function [subsetx,subsety, slopevalue,modeloutput,subsety_real,n_orders]=baseline_echelle_backup(datax,datay, limit1, limit2,peakless_points,varargin)
[x1,x2]=findxpositions(datax,limit1,limit2);
[echelleorders2,n_orders]=find_echelle_orders(limit1,limit2);
try
    baselineshift=varargin{1}
catch
    baselineshift=cell(n_orders+1,1)
end
try
    baselineshift=varargin{2}
catch
    baselineshift=cell(n_orders+1,1)
end
try
    baselineshift=varargin{3}
catch
    baselineshift=cell(n_orders+1,1)
end
subsetx=datax(x1:x2); %setting all values
subsety_real=datay(x1:x2);
modeloutput=zeros(size(subsetx));
peakless_points=[peakless_points ones(1,n_orders).*peakless_points(1)];
%makes sure that enough peakless_points are there for a calculation



for i=1:size(echelleorders2)-1;
    slopevalue=2*pi/(1/echelleorders2(i)-1/(echelleorders2(i+1)));
    substractionfactor=mod(slopevalue/echelleorders2(i),2*pi); 
    peaklesspoint=findxposition(datax,peakless_points(i));
    if subsetx(1)>echelleorders2(i)
        y1=1;
    else
        y1=findxposition(subsetx,echelleorders2(i));
        %datay1=findxposition(datax,echelleorders2(i));
        %down=mean(datay((datay1-5):(datay1+5)));
    end
    if max(subsetx)<echelleorders2(i+1)
        y2=length(subsetx);
        endpoint=1;
    else
        y2=findxposition(subsetx,echelleorders2(i+1))+1;
        %datay1=findxposition(datax,echelleorders2(i+1));
        %down=mean(datay((datay1-5):(datay1+5)));
        endpoint=0;
    end
%       Slope determination of the basis(zero line); this is a line through
%       the minima caused by the echelle orders, and is put to zero
    downrange=1; %range of the mean around the minima; too high--> too high minimum value
    
    datay1=findxposition(datax,echelleorders2(i));
    if  isempty(baselineshift{i})
        down1=mean(datay((datay1-downrange):(datay1+downrange)));
    else
        down1=mean(datay((datay1-downrange):(datay1+downrange))).*(1+baselineshift{i});
    end
    datay2=findxposition(datax,echelleorders2(i+1));
    if isempty(baselineshift{i+1})
        down2=mean(datay((datay2-downrange):(datay2+downrange)));
    else
        down2=mean(datay((datay2-downrange):(datay2+downrange))).*(1+baselineshift{i+1});
    end
    slopedown=(down2-down1)/(echelleorders2(i+1)-echelleorders2(i));
    intersectdown=down1-datax(datay1).*slopedown;

    %       Calculates amplitude of Echelle orders; based on 1 value (mean
    %       of 11 consecutive values)
    theoreticaly1=(sqrt(abs(sin(slopevalue/datax(peaklesspoint)-substractionfactor-0.5*pi)+1)/2));
    down=subsetx.*slopedown+intersectdown;
    downdata=datax.*slopedown+intersectdown;
    mean1=mean(datay((peaklesspoint-5):(peaklesspoint+5)));
    multipfactor=(mean1-mean(downdata((peaklesspoint-5):(peaklesspoint+5))))/theoreticaly1;        
    for j=y1:(y2-1+endpoint);
        modeloutput(j)=down(j)+multipfactor.*(sqrt(abs(sin(slopevalue/subsetx(j)-substractionfactor-0.5*pi)+1)/2));
    end
end
subsety=subsety_real-modeloutput;    
% if plot is needed, uncomment the following:

%plot(subsetx,[subsety_real, modeloutput, subsety, zeros(size(subsetx))]);
% ylim([-500 max(subsety_real)+300]);
end




