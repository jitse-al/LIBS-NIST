function pathout=imagetopathdif3(pathout,l_bound,u_bound)
for i=1:length(pathout);
    [a,b]=size(pathout{i});
    for j=1:a;
        for k=1:b;
            if pathout{i}(j,k)<l_bound;
                pathout{i}(j,k)=NaN;
            end
            if pathout{i}(j,k)>u_bound;
                pathout{i}(j,k)=NaN;
            end
        end
    end
end