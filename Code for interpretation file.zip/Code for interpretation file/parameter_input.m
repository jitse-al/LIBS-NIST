global leftbound rightbound ub lb npeaks x_data x_data_title peakless_points outputend

%x_data=[9.2 8.2 7.2 6.2 5.2 4.2 3.2 2.2 1.2 0.2 -0.8 -1.8 -2.8 -3.8 -4.8];
%x_data_title='Focus depth (mm)';

%x_data=[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15];
%x_data=[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30];
%x_data_title='Depth (relative)';


x_data=[100 200 300 400 500 600 700 800 900 1000 1100 1200 1300 1400 1500 1600 1700 1800 2000 2200 2400 2600 2800 3000];
%x_data=[0 100 200 300 400 500 600 700 800 900 1000 1250 1500 1750 2000 2250 2500];
x_data_title='Delay time (ns)';

outputend='Fe_lines';

% npeaks=3;
% leftbound=652;
% rightbound=662;
% lb=[656.3;657;658];
% ub=[657;658;659];
% peakless_points=[653 641.379 659.361;662 659.361 678.675];
