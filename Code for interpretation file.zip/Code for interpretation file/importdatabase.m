function [database,string]=importdatabase(element,species,wavelength,intensity)
a=unique(element);
database=cell(size(a));
string1='';
string2='';
for i=1:length(a);
    string=a{i};
    string1_1=[string ', '];
    string2_1=['database.' string ', '];
    string1=[string1 string1_1];
    string2=[string2 string2_1];
    acomp=strcmp(element,a(i));
    elements1=element(acomp)
    species1=species(acomp);
    string3=cellstr(num2str(zeros(size(species1))));
    for j=1:size(string3)
        string3{j}=' ';
    end
    test1=size(string3)
    test2=size(elements1)
    test3=size(species1)
    species1=cellstr([char(elements1) char(string3) char(species1)]);
    wavelength1=wavelength(acomp);
    intensity1=intensity(acomp);
    cell1={wavelength1 intensity1 species1};
    database{i}=cell1;
end
string=['[' string1(1:(length(string1)-2)) ']=deal(' string2(1:(length(string2)-2)) ');'];
database=cell2struct(database,a);
end
    