function legend_string=define_legend_string
global legend_database_string legend_spectrum_string
legend_string=[legend_spectrum_string; legend_database_string];
end
