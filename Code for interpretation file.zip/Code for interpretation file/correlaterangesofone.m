function endcheck=correlaterangesofone(rangea,x)
[sizea,~]=size(rangea);
endcheck=zeros(size(x));
for i=1:sizea
    if rangea(i,3)>0
        endcheck(rangea(i,4):rangea(i,3))=ones(rangea(i,3)-rangea(i,4)+1,1);
    end
end
