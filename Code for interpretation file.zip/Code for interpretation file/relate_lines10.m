function relate_lines10(parameters)
includes={'Fe','S','O','Na'};
boundary=0.015;
type='Ritz';
database='findinglist';
maxdeviation=0.015;
power_of_fit=1.5;

parameters2=sortrows(parameters,4);
[names,~,info]=relate_lines2(parameters2,maxdeviation,power_of_fit);
vacuumcount=0;
aircount=0;
co2count=0;
emptycount=0;
messagestring={'vacuum';'air';'CO2'};
for i=1:50;
    string=[info{i,13} info{i,14} info{i,17}];
    string=lower(string);
    vacuumtemp=strfind(string,'vacuum');
    airtemp=strfind(string,'air');
    co2temp=strfind(string,'co2');
    if not(isempty(vacuumtemp))
        vacuumcount=vacuumcount+1;
    elseif not(isempty(airtemp))
        aircount=aircount+1;
    elseif not(isempty(co2temp));
        co2count=co2count+1;
    else
        emptycount=emptycount+1;
    end
end
totalcounts=[vacuumcount;aircount;co2count]./0.5;
emptycount=emptycount./0.5;
[totalcounts,index]=sort(totalcounts,'descend');
messagestring=messagestring(index);
a=3;
message={['Total measured in ' messagestring{1} '; ' num2str(totalcounts(1)) '%'];['Total measured in ' messagestring{2} '; ' num2str(totalcounts(2)) '%'];['Total measured in ' messagestring{3} '; ' num2str(totalcounts(3)) '%']}
while a>0;
    if totalcounts(length(totalcounts))==0;
        message=message(1:(length(totalcounts)-1),:);
        totalcounts=totalcounts(1:(length(totalcounts)-1));
        
        a=a-1;
    else
        a=0;
    end
end
message=[message;{['Unknown; ' num2str(emptycount) '%']}]
for i=2:length(names);
    names{i}=[', ' names{i}];
end
names=['Elements found from often occurring lines: ' cell2mat(names')]
        