function varargout = Define_parameters_figure(varargin)
% DEFINE_PARAMETERS_FIGURE MATLAB code for Define_parameters_figure.fig
%      DEFINE_PARAMETERS_FIGURE, by itself, creates a new DEFINE_PARAMETERS_FIGURE or raises the existing
%      singleton*.
%
%      H = DEFINE_PARAMETERS_FIGURE returns the handle to a new DEFINE_PARAMETERS_FIGURE or the handle to
%      the existing singleton*.
%
%      DEFINE_PARAMETERS_FIGURE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DEFINE_PARAMETERS_FIGURE.M with the given input arguments.
%
%      DEFINE_PARAMETERS_FIGURE('Property','Value',...) creates a new DEFINE_PARAMETERS_FIGURE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Define_parameters_figure_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Define_parameters_figure_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Define_parameters_figure

% Last Modified by GUIDE v2.5 06-Dec-2015 19:46:46

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @Define_parameters_figure_OpeningFcn, ...
    'gui_OutputFcn',  @Define_parameters_figure_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Define_parameters_figure is made visible.
function Define_parameters_figure_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Define_parameters_figure (see VARARGIN)

% Choose default command line output for Define_parameters_figure
handles.output = hObject;

guidata(hObject,handles);
% Update handles structure


% UIWAIT makes Define_parameters_figure wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Define_parameters_figure_OutputFcn(hObject, eventdata, handles)
h=findobj('Tag','Libsfigure');
handles_main=guidata(h);
handles.xvalues=handles_main.xvalues;
handles.yvalues=handles_main.yvalues;
handles.xvaluesall=handles_main.xvaluesall;
handles.yvaluesall=handles_main.yvaluesall;
handles_saved=open('Libs_saved_variables.mat');
handles_saved=handles_saved.handles2;
names=[fieldnames(handles);fieldnames(handles_saved)];
handles=cell2struct([struct2cell(handles);struct2cell(handles_saved)],names,1);

set(handles.edit1,'String',num2str(handles.leftbound));
set(handles.edit2,'String',num2str(handles.rightbound));
set(handles.slider1,'Min',handles.leftbound);
set(handles.slider1,'Max',handles.rightbound);
set(handles.slider1,'Value',handles.leftbound);
set(handles.edit3,'String',num2str(handles.npeaks));
data=[handles.lb handles.ub];
set(handles.uitable1,'Data',data);
set(handles.uitable2,'Data',handles.peakless_points);
axes(handles.axes_def);
cla(handles.axes_def,'reset')
parameter_input;
parameter_input_2;
handles.selectedcells=[1 1];
try
    delete(handles.subsetplot);
end
try
    delete(handles.e_baselineplot);
end
hold on
zoom on
[handles.subsetx,handles.subsety]=subset(handles.xvalues,handles.yvalues,handles.leftbound,handles.rightbound);
xlim([handles.leftbound handles.rightbound]);
[~,~, ~,handles.e_baseline]=baseline_echelle(handles.xvalues,handles.yvalues, handles.leftbound, handles.rightbound,handles.peakless_points);
[vertlinesx,vertlinesy]=vertlines(handles.peakless_points',max(handles.subsety),min(handles.subsety));
hold on
handles.subsetplot=plot(handles.subsetx,handles.subsety);
handles.e_baselineplot=plot(handles.subsetx,handles.e_baseline,'r');
handles.vertplot=plot(vertlinesx,vertlinesy,'Color',[0.5 0.5 0.5]);
[vertlinesx,vertlinesy]=vertlines(handles.peakless_points(1),max(handles.subsety),min(handles.subsety));
handles.vertplotcurrent=plot(vertlinesx,vertlinesy,'k');
set(handles.uitable3,'Data',zeros(size(handles.peakless_points)));

guidata(gcf,handles);
% % % parameter_input;
% % % parameter_input_2;
% % % handles.selectedcells=[1 1];
% % % try
% % %     delete(handles.subsetplot);
% % % end
% % % try
% % %     delete(handles.e_baselineplot);
% % % end
% % % hold on
% % % handles.subsetplot=plot(handles.subsetx,handles.subsety);
% % % xlim([handles.leftbound handles.rightbound]);
% % % handles.e_baselineplot=plot(handles.subsetx,handles.e_baseline,'r');
% % % zoom on
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit1_Callback(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot
handles.leftbound=str2num(get(hObject,'String'));
[handles.subsetx,handles.subsety]=subset(handles.xvalues,handles.yvalues,handles.leftbound,handles.rightbound);
try
    delete(handles.subsetplot);
end
hold on
handles.subsetplot=plot(handles.subsetx,handles.subsety);
xlim([handles.leftbound handles.rightbound]);
set(handles.slider1,'Min',min(handles.subsetx));
set(handles.slider1,'Value',min(handles.subsetx));
[handles.echelle_orders,n_orders]=find_echelle_orders(handles.leftbound,handles.rightbound);
olddata=get(handles.uitable2,'Data');
[a,b]=size(olddata);
newdata=zeros(n_orders,3);
if n_orders<a;
    newdata=olddata((a-n_orders+1):a,:);
else
    position=n_orders-a+1;
    newdata(position:n_orders,:)=olddata;
end
for i=1:n_orders;
    if newdata(i,1)==0;
        newdata(i,1)=(handles.echelle_orders(i)+handles.echelle_orders(i+1))/2;
        if newdata(i,1)<min(handles.subsetx)
            newdata(i,1)=min(handles.subsetx);
        end
    end
    if newdata(i,2)==0;
        newdata(i,2)=handles.echelle_orders(i);
    end
    if newdata(i,3)==0;
        newdata(i,3)=handles.echelle_orders(i+1);
    end    
end
set(handles.uitable2,'Data',newdata);
handles.corrections=zeros(size(newdata));
set(handles.uitable3,'Data',handles.corrections);
handles.peakless_points=newdata;
[~,~, ~,handles.e_baseline]=baseline_echelle(handles.xvalues,handles.yvalues, handles.leftbound, handles.rightbound,handles.peakless_points);
try
    delete(handles.e_baselineplot);
end
hold on
handles.e_baselineplot=plot(handles.subsetx,handles.e_baseline,'r');
guidata(gcf,handles);
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
%global handles.leftbound


% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot
handles.rightbound=str2num(get(hObject,'String'));
[handles.subsetx,handles.subsety]=subset(handles.xvalues,handles.yvalues,handles.leftbound,handles.rightbound);
try
    delete(handles.subsetplot);
end
hold on
handles.subsetplot=plot(handles.subsetx,handles.subsety);
xlim([handles.leftbound handles.rightbound]);
set(handles.slider1,'Max',max(handles.subsetx));
set(handles.slider1,'Value',min(handles.subsetx));
[handles.echelle_orders,n_orders]=find_echelle_orders(handles.leftbound,handles.rightbound);
olddata=get(handles.uitable2,'Data');
[a,b]=size(olddata);
newdata=zeros(n_orders,3);
if n_orders<a;
    newdata=olddata(1:n_orders,:);
else
    newdata(1:a,:)=olddata;
end
for i=1:n_orders;
    if newdata(i,1)==0;
        newdata(i,1)=(handles.echelle_orders(i)+handles.echelle_orders(i+1))/2;
        if newdata(i,1)>max(handles.subsetx)
            newdata(i,1)=max(handles.subsetx);
        end
    end
    if newdata(i,2)==0;
        newdata(i,2)=handles.echelle_orders(i);
    end
    if newdata(i,3)==0;
        newdata(i,3)=handles.echelle_orders(i+1);
    end
    
end
set(handles.uitable2,'Data',newdata);
handles.corrections=zeros(size(newdata));
set(handles.uitable3,'Data',handles.corrections);
handles.peakless_points=newdata;
[~,~, ~,handles.e_baseline]=baseline_echelle(handles.xvalues,handles.yvalues, handles.leftbound, handles.rightbound,handles.peakless_points);
try
delete(handles.e_baselineplot);
end
hold on
handles.e_baselineplot=plot(handles.subsetx,handles.e_baseline,'r');
guidata(gcf,handles);
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
%global handles.rightbound

% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot
currentvalue=get(hObject,'Value');
handles.editabledata(handles.selectedcells(1),handles.selectedcells(2))=currentvalue;
data=handles.editabledata;
if  get(handles.radiobutton1,'Value')
    set(handles.uitable2,'Data',handles.editabledata)
    handles.peakless_points=data;
    [~,~, ~,handles.e_baseline]=baseline_echelle(handles.xvalues,handles.yvalues, handles.leftbound, handles.rightbound,handles.peakless_points);
    delete(handles.e_baselineplot);
    hold on
    handles.e_baselineplot=plot(handles.subsetx,handles.e_baseline,'r');
    [vertlinesx,vertlinesy]=vertlines(data,max(handles.subsety),min(handles.subsety));
    try
        delete(handles.vertplot);
    end
    try
        delete(handles.vertplotcurrent);
    end
    hold on
    handles.vertplot=plot(vertlinesx,vertlinesy,'Color',[0.5 0.5 0.5]);
    [vertlinesx,vertlinesy]=vertlines(currentvalue,max(handles.subsety),min(handles.subsety));
    handles.vertplotcurrent=plot(vertlinesx,vertlinesy,'k');
else
    set(handles.uitable1,'Data',handles.editabledata)
    try
        delete(handles.vertplot);
        
    end
    try
        delete(handles.vertplotcurrent);
    end
    hold on
    handles.vertplot=multiarea(handles.editabledata,min(handles.subsety),max(handles.subsety));
    [vertlinesx,vertlinesy]=vertlines(currentvalue,max(handles.subsety),min(handles.subsety));
    handles.vertplotcurrent=plot(vertlinesx,vertlinesy,'k');
    handles.lb=handles.editabledata(:,1);
    handles.ub=handles.editabledata(:,2);
end
guidata(gcf,handles);


% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
%global handles.leftbound handles.rightbound

% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot
handles.currentdata=get(hObject,'Value');
handles.corrections(handles.selectedcells(1),handles.selectedcells(2))=handles.currentdata;
handles.corrections2=handles.corrections/100;
set(handles.uitable3,'Data',handles.corrections);
try
    delete(handles.e_baselineplot)
catch
    'could not delete'
end
[~,~, ~,handles.e_baseline]=baseline_echelle(handles.xvalues,handles.yvalues, handles.leftbound, handles.rightbound,handles.peakless_points, handles.corrections2);
handles.e_baselineplot=plot(handles.subsetx,handles.e_baseline,'r');
guidata(gcf,handles);
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit3_Callback(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot
handles.npeaks=str2num(get(hObject,'String'));
olddata=get(handles.uitable1,'Data');
[a,~]=size(olddata);
newdata=zeros(handles.npeaks,2);
if length(newdata)<length(olddata);
    newdata=olddata(1:handles.npeaks,:);
else
    newdata(1:a,:)=olddata;
end
set(handles.uitable1,'Data',newdata);
guidata(gcf,handles);
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot

% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider3_Callback(hObject, eventdata, handles);
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot
set(handles.edit4,'String',num2str(get(hObject,'Value')));
a=(100-get(hObject,'Value'))/100;
difference=(max(handles.subsety)-min(handles.subsety)).*a;
peakline=handles.e_baseline+difference;
peakline=handles.subsety-peakline;
peakline=checkzerocross(simplify2(peakline));
peaklimits=handles.subsetx(logical(peakline));
handles.lb=zeros((length(peaklimits)/2),1);
handles.ub=lb;
for i=1:(length(peaklimits)/2)
    lb(i)=peaklimits(i*2-1);
    ub(i)=peaklimits(i*2);
end
handles.editabledata=[handles.lb handles.ub];
try
handles.currentdata=handles.editabledata{handles.selectedcells(1),handles.selectedcells(2)};
end
set(handles.uitable1,'Data',handles.editabledata);
[handles.npeaks,~]=size(handles.editabledata);
set(handles.edit3,'String',num2str(handles.npeaks));
try
    delete(handles.vertplot);
end
try
    delete(handles.vertplotcurrent);
end
hold on
try
handles.vertplot=multiarea(handles.editabledata,min(handles.subsety),max(handles.subsety));
[vertlinesx,vertlinesy]=vertlines(handles.currentdata,max(handles.subsety),min(handles.subsety));
handles.vertplotcurrent=plot(vertlinesx,vertlinesy,'k');
end
guidata(gcf,handles);
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit4_Callback(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot
a=str2num(get(hObject,'String'));
if a>100
    set(handles.slider3,'Value',100);
    set(hObject,'String','100');
    a=100;
elseif a<0
    set(handles.slider3,'Value',0);
    set(hObject,'String','0');
    a=0;
else
    set(handles.slider3,'Value',a);
end
a=(100-a)/100;   
difference=(max(handles.subsety)-min(handles.subsety)).*a;
peakline=handles.e_baseline+difference;
peakline=handles.subsety-peakline;
peakline=checkzerocross(simplify2(peakline));
peaklimits=handles.subsetx(logical(peakline));
handles.lb=cell((length(peaklimits)/2),1);
rb=lb;
for i=1:(length(peaklimits)/2)
    lb{i}=peaklimits(i*2-1);
    rb{i}=peaklimits(i*2);
end
handles.editabledata=[handles.lb rb];
try
    handles.currentdata=handles.editabledata{handles.selectedcells(1),handles.selectedcells(2)};
end
set(handles.uitable1,'Data',handles.editabledata);
try
    delete(handles.vertplot);
end
try
    delete(handles.vertplotcurrent);
end
hold on
try
handles.vertplot=multiarea(handles.editabledata,min(handles.subsety),max(handles.subsety));
[vertlinesx,vertlinesy]=vertlines(handles.currentdata,max(handles.subsety),min(handles.subsety));
handles.vertplotcurrent=plot(vertlinesx,vertlinesy,'k');
end
guidata(gcf,handles);
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function uitable1_CreateFcn(hObject, eventdata, handles)
%global handles.lb ub

% hObject    handle to uitable1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function uitable2_CreateFcn(hObject, eventdata, handles)
%global handles.peakless_points handles.echelle_orders

% hObject    handle to uitable2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes when entered data in editable cell(s) in uitable1.
function uitable1_CellEditCallback(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot
handles.selectedcells_now=eventdata.Indices;
if not(isempty(handles.selectedcells_now))
    handles.selectedcells=handles.selectedcells_now;
    handles.editabledata=get(hObject,'Data');
    handles.currentdata=handles.editabledata(handles.selectedcells(1),handles.selectedcells(2));
    set(handles.slider1,'Value',handles.currentdata);
    try
        delete(handles.vertplot);
    end
    try
        delete(handles.vertplotcurrent);
    end
    hold on
    handles.vertplot=multiarea(handles.editabledata,min(handles.subsety),max(handles.subsety));
    [vertlinesx,vertlinesy]=vertlines(handles.currentdata,max(handles.subsety),min(handles.subsety));
    handles.vertplotcurrent=plot(vertlinesx,vertlinesy,'k');
end
handles.lb=handles.editabledata(:,1);
handles.ub=handles.editabledata(:,2);
guidata(gcf,handles);
% hObject    handle to uitable1 (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function axes_def_CreateFcn(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot

% hObject    handle to axes_def (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes_def


% --- Executes when selected object is changed in uipanel4.
function uipanel4_SelectionChangeFcn(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot
try
    delete(handles.vertplotcurrent);
catch
    'deleted object'
end
try
    delete(handles.vertplot);
end
if get(handles.radiobutton1,'Value');
    set(handles.uipanel3,'Visible','off');
    set(handles.uipanel6,'Visible','off');
    set(handles.uipanel5,'Visible','on');
    handles.editabledata=get(handles.uitable2,'Data');
    [vertlinesx,vertlinesy]=vertlines(unique(handles.editabledata),max(handles.subsety),min(handles.subsety));
    handles.vertplot=plot(vertlinesx,vertlinesy,'Color', [0.5 0.5 0.5]);
else
    set(handles.uipanel3,'Visible','on');
    set(handles.uipanel6,'Visible','on');
    set(handles.uipanel5,'Visible','off');
    handles.editabledata=get(handles.uitable1,'Data');
    handles.vertplot=multiarea(handles.editabledata,min(handles.subsety),max(handles.subsety));
end
handles.selectedcells=[1 1];
set(handles.slider1,'Value',handles.editabledata(1,1));
hold on
[vertlinesx,vertlinesy]=vertlines(handles.editabledata(1,1),max(handles.subsety),min(handles.subsety));
handles.vertplotcurrent=plot(vertlinesx,vertlinesy,'k');
guidata(gcf,handles);
% hObject    handle to the selected object in uipanel4
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)


% --- Executes when entered data in editable cell(s) in uitable2.
function uitable2_CellEditCallback(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot
data=cell2mat(get(hObject,'Data'));
handles.peakless_points=data;
[~,~, ~,handles.e_baseline]=baseline_echelle(handles.xvalues,handles.yvalues, handles.leftbound, handles.rightbound,handles.peakless_points);
try
    delete(handles.e_baselineplot);
end
hold on
handles.e_baselineplot=plot(handles.subsetx,handles.e_baseline,'r');
guidata(gcf,handles);

% hObject    handle to uitable2 (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)


% --- Executes when selected cell(s) is changed in uitable2.
function uitable2_CellSelectionCallback(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot
handles.selectedcells_now=eventdata.Indices;
if not(isempty(handles.selectedcells_now))
    handles.selectedcells=handles.selectedcells_now;
    handles.editabledata=get(hObject,'Data');
    handles.currentdata=handles.editabledata(handles.selectedcells(1),handles.selectedcells(2));
    set(handles.slider1,'Value',handles.currentdata);
    [vertlinesx,vertlinesy]=vertlines(unique(handles.editabledata),max(handles.subsety),min(handles.subsety));
    try
        delete(handles.vertplot);
    end
    try
        delete(handles.vertplotcurrent);
    end
    hold on
    handles.vertplot=plot(vertlinesx,vertlinesy,'Color',[0.5 0.5 0.5]);
    [vertlinesx,vertlinesy]=vertlines(handles.currentdata,max(handles.subsety),min(handles.subsety));
    handles.vertplotcurrent=plot(vertlinesx,vertlinesy,'k');
end
guidata(gcf,handles);

% hObject    handle to uitable2 (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)


% --- Executes when selected cell(s) is changed in uitable1.
function uitable1_CellSelectionCallback(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders
handles.selectedcells_now=eventdata.Indices;
if not(isempty(handles.selectedcells_now))
    handles.selectedcells=handles.selectedcells_now;
    handles.editabledata=get(hObject,'Data');
    handles.currentdata=handles.editabledata(handles.selectedcells(1),handles.selectedcells(2));
    set(handles.slider1,'Value',handles.currentdata);
    try
        delete(handles.vertplot);
    end
    try
        delete(handles.vertplotcurrent);
    end
    hold on
    handles.vertplot=multiarea(handles.editabledata,min(handles.subsety),max(handles.subsety));
    [vertlinesx,vertlinesy]=vertlines(handles.currentdata,max(handles.subsety),min(handles.subsety));
    handles.vertplotcurrent=plot(vertlinesx,vertlinesy,'k');
end
guidata(gcf,handles);
% hObject    handle to uitable1 (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot
a=(100-get(handles.slider3,'Value'))/100;
difference=(max(handles.subsety)-min(handles.subsety)).*a;
peakline=handles.e_baseline+difference;
peakline=handles.subsety-peakline;
peakline=checkzerocross(simplify2(peakline));
peaklimits=handles.subsetx(logical(peakline));
handles.lb=zeros((length(peaklimits)/2),1);
rb=lb;
for i=1:(length(peaklimits)/2)
    lb(i)=peaklimits(i*2-1);
    rb(i)=peaklimits(i*2);
end
handles.editabledata=[handles.lb rb];
set(handles.uitable1,'Data',handles.editabledata);
[vertlinesx,vertlinesy]=vertlines(unique(handles.editabledata),max(handles.subsety),min(handles.subsety));
try
    delete(handles.vertplot);
end
try 
    delete(handles.vertplotcurrent);
end
hold on
handles.vertplot=plot(vertlinesx,vertlinesy,'Color',[0.5 0.5 0.5]);
[vertlinesx,vertlinesy]=vertlines(handles.currentdata,max(handles.subsety),min(handles.subsety));
handles.vertplotcurrent=plot(vertlinesx,vertlinesy,'k');
guidata(gcf,handles);

% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in togglebutton2.
function togglebutton2_Callback(hObject, eventdata, handles)
if get(hObject,'Value')
    set(handles.slider3,'Visible','on');
    set(handles.edit4,'Visible','on');
    slider3_Callback(handles.slider3,eventdata,handles)
else
    set(handles.slider3,'Visible','off');
    set(handles.edit4,'Visible','off');
end
guidata(gcf,handles);
% hObject    handle to togglebutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton2


% --- Executes during object creation, after setting all properties.
function uipanel5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes when entered data in editable cell(s) in uitable3.
function uitable3_CellEditCallback(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders
selection=eventdata.Indices;
if not(isempty(selection))
    handles.selectedcells=selection;
end
handles.corrections=get(hObject,'Data');
handles.currentdata=handles.corrections(handles.selectedcells(1),handles.selectedcells(2));
set(handles.slider2,'Value',handles.currentdata);
handles.corrections2=handles.corrections/100;
try
    delete(handles.e_baselineplot)
catch
    'could not delete in CellEdit'
end
[~,~, ~,handles.e_baseline]=baseline_echelle(handles.xvalues,handles.yvalues, handles.leftbound, handles.rightbound,handles.peakless_points, handles.corrections2);
handles.e_baselineplot=plot(handles.subsetx,handles.e_baseline,'r');
guidata(gcf,handles);

% hObject    handle to uitable3 (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)


% --- Executes when selected cell(s) is changed in uitable3.
function uitable3_CellSelectionCallback(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders
uitable3_CellEditCallback(hObject, eventdata, handles);
% hObject    handle to uitable3 (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function uitable3_CreateFcn(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders
% hObject    handle to uitable3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot
%global lowbpeaks upbpeaks nrpeaks subx suby subx2
y=handles.subsety-handles.e_baseline;
try
    [lowbpeaks,upbpeaks,nrpeaks,subx,suby,subx2]=split_parameters(handles.subsetx,y,handles.npeaks,handles.leftbound,handles.rightbound,handles.lb,handles.ub);
    [~,tempoutput]=splitlorentzfit(lowbpeaks,upbpeaks,nrpeaks,subx,suby);
    fittedresults=multilorentz(tempoutput,handles.subsetx);
    baselineadded=fittedresults+handles.e_baseline;
    try
        delete(fitplot);
    end
    fitplot=plot(handles.subsetx, baselineadded,'g','LineWidth',1);
    set(handles.text5,'String','Fit worked');
catch ME
    b={'Errors:'};
    for k=1:size(ME.stack)-2
        a=struct2cell(ME.stack(k));
        a{3}=num2str(a{3});
        a=[a{2} ':' a{3}];
        b=[b;a];
    end
    string=[{'Fit didn''t work';ME.identifier;ME.message};{''};b];
    set(handles.text5,'String',string);
end
guidata(gcf,handles);
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
%global handles.selectedcells handles.editabledata handles.leftbound handles.rightbound handles.subsetplot handles.subsetx handles.peakless_points handles.e_baseline handles.e_baselineplot handles.subsety handles.vertplot handles.vertplotcurrent handles.echelle_orders handles.corrections handles.currentdata handles.npeaks handles.lb handles.ub n_orders fitplot
%global lowbpeaks upbpeaks nrpeaks subx suby subx2
s0='%global handles.leftbound handles.rightbound handles.peakless_points handles.corrections handles.npeaks handles.lb handles.ub n_orders lowbpeaks upbpeaks nrpeaks subx suby';
s1=['handles.leftbound=' mat2str(handles.leftbound) ';' ];
s2=['handles.rightbound=' mat2str(handles.rightbound) ';' ];
s3=['handles.peakless_points=' mat2str(handles.peakless_points) ';' ];
s4=['handles.corrections=' mat2str(handles.corrections) ';' ];
s5=['handles.npeaks=' mat2str(handles.npeaks) ';' ];
s6=['handles.lb=' mat2str(handles.lb) ';' ];
s7=['handles.ub=' mat2str(handles.ub) ';' ];
s8=['n_orders=' mat2str(n_orders) ';' ];
s9=['lowbpeaks=' cell2str(lowbpeaks) ';' ];
s10=['upbpeaks=' cell2str(upbpeaks) ';' ];
s11=['nrpeaks=' cell2str(nrpeaks) ';' ];
s12=['subx2=' cell2str(subx2) ';' ];
string=char({s0;s1;s2;s3;s4;s5;s6;s7;s8;s9;s10;s11;s12});
dlmwrite('parameter_input_2.m',string,'');
guidata(gcf,handles);
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
parameter_input;
parameter_input_2;
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
delete(hObject);
