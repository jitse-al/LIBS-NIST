global workingpath exportname exportfolder
[filename, workingpath]=uigetfile('*.*');
filenamelength=length(filename);
filenamestart=filename(1:filenamelength-6);
filenameend=filename(filenamelength-3:filenamelength);
inputdata=inputdlg({'start of filename','maximum number changing part','filetype'},'Define the data/importfile',1,{filenamestart,'',filenameend});
i1=inputdata{1};
i2=inputdata{2};
i3=inputdata{3};
outputdata=inputdlg({'export filename','foldername'},'Define outpute data',1,{[i1 'average_'],[i1 'average_']});    %open folders, define the filenames before averaging
exportname=outputdata{1};
exportfolder=outputdata{2};     %datatype wrong --> resets cells to string
mkdir(workingpath,exportfolder);                      %create new folder for averaged data

g=0;
f=0;
averagecounts=[];
averageover=3; %set how many measurements each average needs to be taken over
for d=1:str2num(i2);
    e=d-1;
    c=num2str(e);
if e<10
    c=['0' c];
end

b=[workingpath '/' i1 c i3];
importedtempdata=importdata(b);
if f==0;
    f=importedtempdata(:,2);
else
    f=f+importedtempdata(:,2);
end
if rem(d,averageover)==0;                 %number indicates average taken over 3 samples. 
    averagecounts=f./averageover;
    g=g+1;
    dlmwrite([workingpath '/' exportfolder '/' exportname num2str(g)], averagecounts,'newline', 'pc');
    f=0;
    averagecounts=[];
end
end

dlmwrite([workingpath '/' exportfolder '/xdata'], importedtempdata(:,1),'newline', 'pc','precision',9);

