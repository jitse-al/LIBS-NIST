function [subsetx,subsety, intervalsize,modeloutput,subsety_real,n_orders]=baseline_echelle(datax,datay, limit1, limit2,peakless_points, corrections)
[x1,x2]=findxpositions(datax,limit1,limit2);
[echelleorders2,n_orders]=find_echelle_orders(limit1,limit2);
try
    peakless_points(:,2);
catch
    peakless_points=[peakless_points echelleorders2(1:n_orders)];
end
try
    peakless_points(:,3);
catch
    peakless_points=[peakless_points echelleorders2(2:(n_orders+1))];
end
if not(exist('corrections','var'))
    corrections=zeros(size(peakless_points));
end
subsetx=datax(x1:x2); %setting all values
subsety_real=datay(x1:x2);
modeloutput=zeros(size(subsetx));
downrange=1;
[sizeppx,~]=size(peakless_points);
x=zeros(3,1);
y=x;
z=x;
for i=1:sizeppx;
    [~,tempsuby]=subset(datax,datay,echelleorders2(i),echelleorders2(i+1));
    tempsuby=sort(tempsuby);
    cor_ref=tempsuby(floor(length(tempsuby)/4));
    intervalsize(i)=2*pi/(1/echelleorders2(i)-1/(echelleorders2(i+1)));
    substractionfactor(i)=mod(intervalsize(i)/echelleorders2(i),2*pi);
    for j=1:3;
        cp=findxposition(datax,peakless_points(i,j));
        x(j,1)=datax(cp);
        y(j,1)=sqrt(abs(sin(intervalsize(i)./datax(cp)-substractionfactor(i)-0.5*pi)+1)/2);
        z(j,1)=mean(datay((cp-downrange):(cp+downrange)))+cor_ref.*corrections(i,j);
    end
    xyzmatrix=[x y ones(3,1)];
    factors=xyzmatrix\z;
    a(i)=factors(1);
    b(i)=factors(2);
    c(i)=factors(3);
end
for i=1:sizeppx
    baseline=a(i).*subsetx+c(i)+b(i).*(sqrt(abs(sin(intervalsize(i)./subsetx-substractionfactor(i)-0.5*pi)+1)/2));
    if subsetx(1)>echelleorders2(i)
        y1=1;
    else
        y1=findxposition(subsetx,echelleorders2(i));
    end
    if max(subsetx)<echelleorders2(i+1)
        y2=length(subsetx);
        endpoint=1;
    else
        y2=findxposition(subsetx,echelleorders2(i+1))+1;
        endpoint=0;
    end
    for j=y1:(y2-1+endpoint);
        modeloutput(j)=baseline(j);
    end
end
subsety=subsety_real-modeloutput;
% if plot is needed, uncomment the following:

%plot(subsetx,[subsety_real, modeloutput, subsety, zeros(size(subsetx))]);
% ylim([-500 max(subsety_real)+300]);
end




