function dataincells=putintocells(data,rows)
d=sortrows(data,rows);
try
    u=unique(d(:,rows));
catch
    u=unique(cell2mat(d(:,rows)));
end
outputcell=zeros(length(u),2);
k=2;
outputcell(1,1)=1;
[lengthd,~]=size(d);
outputcell(length(u),2)=lengthd;
for i=2:lengthd;
    if d{i,rows}~=d{i-1,rows}
        outputcell(k,1)=i;
        outputcell(k-1,2)=i-1;
        k=k+1;
    end
end
dataincells=cell(length(u),1);
for i=1:length(u)
    dataincells{i}=d(outputcell(i,1):outputcell(i,2),:);
end
end
    