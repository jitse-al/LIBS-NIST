function  [basex,basey]=extractbase1(x,y,checkrange,range,slope_to_error_ratio)
errors=zeros(size(y));
slopemodel=errors;
for i=1:(size(y)-range);
    yrange=y(i:(i+range));
    xrange=x(i:(i+range));
    dxdy=0;
    for j=1:range;
        dxdy=dxdy+(yrange(j+1)-yrange(j))/(xrange(j+1)-xrange(j));
    end
    slope=dxdy./range;
    intercept=mean(yrange)-mean(xrange).*slope;
    %slope=polyfit(xrange,yrange,1);
    %intercept=slope(2);
    %slope=slope(1);
    model=xrange*slope+intercept;
    error=sqrt(mean((yrange-model).^2));
    errors(i+floor(range/2))=error;
    slopemodel(i+floor(range/2))=slope;
end
%plot(x,slopemodel)
signslope=sign(slopemodel);
signslope2=zeros(size(signslope));
signslope3=signslope2;
meanerror=sqrt(mean(error.^2));
for i=1:(size(y)-range);
    yrange=signslope(i:(i+range));
    meanslope=mean(slopemodel(i:(i+range)));
    check1=yrange-1;
    check2=yrange+1;
    if abs(meanslope)>slope_to_error_ratio*meanerror;
        if sum(abs(check1))==0
            signslope2(i:(i+range))=ones(size(yrange));
        elseif sum(abs(check2))==0;
            signslope3(i:(i+range))=ones(size(yrange));
        end
    end
end
[rangelength1,rangelength11]=findrangesofone(signslope2);
[rangelength2,rangelength22]=findrangesofone(signslope3);


a=zeros(size(rangelength1));
a=[a a a];
% b=zeros(size(a));
a4=0;
% b4=0;
% interpolate positive slope; remove stuff where no slope has been measured
% remove: a=1
for i=1:(length(rangelength1)-1);
    % if the distance between two positive slopes is too little --> remove
    a1=rangelength1(i)+rangelength11(i).*(checkrange+1);
    a2=rangelength1(i+1);
    if a2<a1
        a(i,1)=1;
    end
    a3=rangelength1(i)+rangelength11(i);
    for j=1:length(rangelength2)
        if (rangelength2(j)+0.5*rangelength22(j))>a3
            if (rangelength2(j)+0.5*rangelength22(j))<a2
                a4=1;
                a(i,3)=rangelength2(j)+rangelength22(j);
            end
        end
    end
    
    if a4~=1
        a(i,2)=1;
    else
        a(i,4)=rangelength1(i);
    end
    a4=0;
end
i=i+1;
a3=rangelength1(i)+rangelength11(i);
    for j=1:length(rangelength2)
        if (rangelength2(j)+0.5*rangelength22(j))>a3
                a4=1;
                a(i,3)=rangelength2(j)+rangelength22(j);
        end
    end
if a4~=1
    a(i,2)=1;
else
    a(i,4)=rangelength1(i);
end

for i=1:(length(rangelength1)-1)
    if a(i,1)
        if a(i,2)
            if a(i+1,4)>0
                a(i+1,4)=rangelength1(i);
            end
        end
    end
end


% for i=2:length(rangelength2);
%     b1=rangelength2(i)-rangelength22(i).*(checkrange+1);
%     b2=rangelength2(i-1);
%     if b2>b1
%         b(i,1)=1;
%     end
%     b3=rangelength2(i);
%     for j=1:length(rangelength1)
%         if (rangelength1(j)+0.5*rangelength11(j))>b2
%             if (rangelength1(j)+0.5*rangelength11(j))<b3
%                 b4=1;
%                 b(i,3)=rangelength1(j);
%             end
%         end
%     end
%     
%     if b4~=1
%         b(i,2)=1;
%     else
%     b(i,4)=rangelength2(i)+rangelength22(i);        
%     end
%     b4=0;
% 
% end
% i=1;
% if b2>b1
%     b(i,1)=1;
% end
% b3=rangelength2(i);
% for j=1:length(rangelength1)
%     if (rangelength1(j)+0.5*rangelength11(j))<b3
%         b4=1;
%         b(i,3)=rangelength1(j);
%     end
% end
% if b4~=1
%     b(i,2)=1;
% else
%     b(i,4)=rangelength2(i)+rangelength22(i);
% end
% 
% for i=1:(length(rangelength2)-1)
%     if b(i+1,1)
%         if b(i+1,2)
%             if b(i,4)>0
%                 b(i,4)=rangelength2(i+1)+rangelength22(i+1);
%             end
%         end
%     end
% end

% give some possible peaks. Not useful
% possiblepeaks=[rangelength1+rangelength11;rangelength2];
% possiblepeaks=unique(possiblepeaks);

endcheck=correlaterangesofone(a,x);
basex=x(not(endcheck));
basey=y(not(endcheck));
if max(basex)<max(x);
    basex=[basex;max(x)];
    basey=[basey;0];
end
% plot(x,y,basex,basey);
% pause(1)
