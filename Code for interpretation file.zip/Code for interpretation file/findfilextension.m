function extension=findfilextension(filename)
a=filename=='.';
for i=2:length(a);
    if a(i-1)==1
        a(i)=1;
    end
end
extension=filename(a);
end