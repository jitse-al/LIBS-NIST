filename='test.gif';
p=30;
lambda=9.68082654413331e-07;
L=150/100;
density=3/1000;
erosionrate=3/1000;

t_end=1e6;
delta_t=5e3;
time=0:delta_t:t_end;
d_0=t_end.*erosionrate;
depthstart=0:0.01:2*d_0;
height=(-depthstart+2.*d_0)/1000;
d_top=d_0;
n_graphs=4;
nstart=zeros(size(depthstart));


suddenerosion=zeros(round(t_end/delta_t+1),1);
d=cell(n_graphs,1);
n=d;
maxvalues=d;
zerovalue=d;
dndt=d;
loss=d;
production=d;
erosionrates=d;
for i=1:n_graphs
    d{i}=depthstart;
    n{i}=nstart;
    maxvalues{i}=suddenerosion;
end
events=5;
suddenerosionrate=erosionrate*t_end/events;
lengthsuddenerosion=floor(length(suddenerosion)/(events+1));
point=0;
for i=1:events;
    point=point+lengthsuddenerosion;
    suddenerosion(point)=suddenerosionrate;
end
suddenerosion2=zeros(size(suddenerosion));
point=rand(events,1);
point2=floor(length(suddenerosion)./sum(point).*point);
for i=1:events;
    point(i)=sum(point2(1:i));
end
suddenerosionrate2=rand(events,1);
suddenerosionrate2=suddenerosionrate./mean(suddenerosionrate2).*suddenerosionrate2;
for i=1:events;
    suddenerosion2(point(i))=suddenerosionrate2(i);
end

lambda=lambda*delta_t;
erosionrate=erosionrate*delta_t;
p=p*delta_t;
erosionrates{1}=zeros(size(suddenerosion));
erosionrates{2}=ones(size(suddenerosion)).*erosionrate;
erosionrates{3}=suddenerosion;
erosionrates{4}=suddenerosion2;
d{1}=d{1}-3000
titlestrings={'No erosion' 'Continues erosion' 'Regular events (5)' 'Irregular events (5)'};
point=0;
figure('Position',[0 0 2000 1000]);
upperlimit=2.*10.^[7 7 7 7];
for i=0:delta_t:t_end;
    point=point+1;
    for j=1:n_graphs
        production{j}=p.*exp(-d{j}*density/L);
        loss{j}=lambda.*n{j};
        dndt{j}=production{j}-loss{j};
        n{j}=n{j}+dndt{j};
        zerovalue{j}=d{j}>0;
        n{j}=n{j}.*zerovalue{j};
        maxvalues{j}(point)=max(n{j});
        subplot(1,n_graphs,j);
        area([0 2e7],[2*d_top+min(d{j}) 2*d_top+min(d{j})]/1000,'FaceColor',[222,184,135]/222)
        hold on
        plot(n{j},height);
        hold off
        title(titlestrings{j},'FontSize',18);
        ylabel('Height (m)','FontSize',14)
        ylim([0 6]);
        xlim([0 upperlimit(j)]);
        xlabel('Produced nuclides','FontSize',13);
        d{j}=d{j}-erosionrates{j}(point);
    end
    drawnow
    frame=getframe(1);
    image=frame2im(frame);
    [imind,cm]=rgb2ind(image,256);
    if point==1;
        imwrite(imind,cm,filename,'gif', 'Loopcount',inf);
    else
        imwrite(imind,cm,filename,'gif','WriteMode','append','DelayTime',0.04);
    end
end
figure
plot(time,maxvalues{1},time,maxvalues{2},time,maxvalues{3},time,maxvalues{4});
xlabel('Time (years)')
ylabel('Number of produced nuclides at surface')
legend('No erosion', 'Continues erosion', 'Regular events (5)', 'Irregular events (5)')
    
    
    