function finaloutput=putintocells2(data, rows)
output=putintocells(data,rows(1));
[a,~]=size(output);
finaloutput=cell(size(output));
if length(rows)>1
    for i=1:a
        finaloutput{i}=putintocells2(output{i},rows(2:length(rows)));
    end
else
    finaloutput=output;
end

