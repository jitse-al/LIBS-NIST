function varargout = Averagespectra_figure(varargin)
% AVERAGESPECTRA_FIGURE MATLAB code for Averagespectra_figure.fig
%      AVERAGESPECTRA_FIGURE, by itself, creates a new AVERAGESPECTRA_FIGURE or raises the existing
%      singleton*.
%
%      H = AVERAGESPECTRA_FIGURE returns the handle to a new AVERAGESPECTRA_FIGURE or the handle to
%      the existing singleton*.
%
%      AVERAGESPECTRA_FIGURE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in AVERAGESPECTRA_FIGURE.M with the given input arguments.
%
%      AVERAGESPECTRA_FIGURE('Property','Value',...) creates a new AVERAGESPECTRA_FIGURE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Averagespectra_figure_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Averagespectra_figure_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Averagespectra_figure

% Last Modified by GUIDE v2.5 07-Mar-2016 11:29:40

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @Averagespectra_figure_OpeningFcn, ...
    'gui_OutputFcn',  @Averagespectra_figure_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Averagespectra_figure is made visible.
function Averagespectra_figure_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Averagespectra_figure (see VARARGIN)

% Choose default command line output for Averagespectra_figure
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Averagespectra_figure wait for user response (see UIRESUME)
% uiwait(handles.Averagespectra_figure);


% --- Outputs from this function are returned to the command line.
function varargout = Averagespectra_figure_OutputFcn(hObject, eventdata, handles)
h=findobj('Tag','Libsfigure');
handles_main=guidata(h);
handles.xvalues=handles_main.xvalues;
handles.yvalues=handles_main.yvalues;
handles.xvaluesall=handles_main.xvaluesall;
handles.yvaluesall=handles_main.yvaluesall;
handles.path=handles_main.path;
handles.filenamesall=get(handles_main.popupmenu2,'String');
handles.currentfilename=get(handles_main.popupmenu2,'Value');
handles.filext=findfilextension(handles.filenamesall{handles.currentfilename});
[sizex,~]=size(handles.xvalues);
k=ones(length(handles.xvaluesall),1);
currents=k-1;
currents(handles.currentfilename)=1;
handles.currentfilename=1:length(handles.xvaluesall);
for i=1:length(handles.xvaluesall);
    [sizex2,~]=size(handles.xvaluesall{i});
    if not(sizex2==sizex)
        k(i)=0;
    end
end
k=logical(k);
handles.xvaluesall=handles.xvaluesall(k,:);
handles.yvaluesall=handles.yvaluesall(k,:);
handles.filenamesall=handles.filenamesall(k,:);
currents=currents(k,:);
currents=logical(currents);
handles.currentfilename=handles.currentfilename(k);
handles.currentfilename=handles.currentfilename(currents);

handles.includes=1:length(handles.filenamesall);
handles.excludes=[];
handles.filenamesin=handles.filenamesall(handles.includes);
handles.filenamesout=handles.filenamesall(handles.excludes);

set(handles.listbox1,'String',handles.filenamesall)
set(handles.listbox1,'Value',handles.currentfilename)
guidata(gcf,handles)
edit1_Callback(handles.edit1,eventdata,handles);
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1_Callback(hObject, eventdata, handles)
n=get(hObject,'String');
if iscell(n);
    n=n{1};
end
try
    n=str2num(n);
catch
    'no number';
end
string=handles.filenamesall{handles.currentfilename};
[commonstring,beginstring,endstring]=comparesetofstrings(string,handles.filenamesall(handles.includes),'exclude_numbers_end');
set(handles.text1,'String',commonstring);
set(handles.edit3,'String',[handles.path commonstring 'average' '\']);
set(handles.edit4,'String',[commonstring 'average']);
for i=1:length(beginstring);
    if not(isempty(beginstring{i}));
        endstring{i}=[beginstring{i} '...' endstring{i}];
    end
end
ls=length(endstring);
ls2=floor(ls/n+0.999);
ordering=cell(ls2,n);
for i=1:ls2;
    for j=1:n;
        ordering{i,j}=0;
    end
end
a=0;
b=1;
for i=1:ls;
    a=a+1;
    ordering{b,a}=i;
    if a==n;
        b=b+1;
        a=0;
    end
end
data=cell2mat(ordering);
try
    dataout=endstring(data);
catch
    dataout=endstring(data(1:(ls2-1),:));
    for i=1:n;
        try
            dataout(ls2,i)=endstring(data(ls2,i));
        end
    end
end
set(handles.uitable1,'Data',dataout)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox2.
function listbox2_Callback(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox2


% --- Executes during object creation, after setting all properties.
function listbox2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
if not(isempty(handles.includes))
    n=get(handles.listbox1,'Value');
    excludemove=handles.includes(n);
    handles.excludes=[handles.excludes excludemove];
    handles.excludes=sort(handles.excludes);
    handles.includes(n)=0;
    handles.includes=sort(handles.includes);
    handles.includes=handles.includes(2:length(handles.includes));
    handles.filenamesin=handles.filenamesall(handles.includes);
    handles.filenamesout=handles.filenamesall(handles.excludes);
    set(handles.listbox2,'String',handles.filenamesout)
    if isempty(handles.includes)
        set(handles.listbox1,'String',' - Empty - ');
    else
        set(handles.listbox1,'String',handles.filenamesin);
        if n>1
            set(handles.listbox1,'Value',n-1);
        end
    end
    
    data=get(handles.uitable1,'Data');
    if not(isempty(data))
        string1=handles.filenamesall{excludemove};
        string2=get(handles.text1,'String');
        pattern=strfind(string1,string2);
        check=ones(size(string1));
        check(pattern(1):(pattern(1)+length(string2)-1))=zeros(1,length(string2));
        if pattern(1)>1
            check2=check;
            check2(1:pattern(1))=zeros(1,pattern(1));
            check3=check;
            check3((pattern(1)+length(string2)-1):length(check3))=zeros(1,(length(check3)-length(string2)+pattern(1)));
            string3=[string1(logical(check3)) '...' string1(logical(check2))];
        else
            string3=string1(logical(check));
        end
        [a,b]=size(data);
        for i=1:a
            for j=1:b
                if strcmp(data{i,j},string3)
                    data(i,j)=cell(1);
                end
            end
        end
        set(handles.uitable1,'Data',data);
    end
    
    guidata(gcf,handles);
end
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
if not(isempty(handles.excludes))
    n=get(handles.listbox2,'Value');
    includemove=handles.excludes(n);
    handles.includes=[handles.includes includemove];
    handles.includes=sort(handles.includes);
    handles.excludes(n)=0;
    handles.excludes=sort(handles.excludes);
    handles.excludes=handles.excludes(2:length(handles.excludes));
    handles.filenamesout=handles.filenamesall(handles.excludes);
    handles.filenamesin=handles.filenamesall(handles.includes);
    set(handles.listbox1,'String',handles.filenamesin)
    if isempty(handles.excludes)
        set(handles.listbox2,'String',' - Empty - ')
    else
        set(handles.listbox2,'String',handles.filenamesout)
        if n>1
            set(handles.listbox2,'Value',n-1)
        end
    end
    data=get(handles.uitable1,'Data');
    if not(isempty(data))
        string1=handles.filenamesall{includemove};
        string2=get(handles.text1,'String');
        pattern=strfind(string1,string2);
        check=ones(size(string1));
        check(pattern(1):(pattern(1)+length(string2)-1))=zeros(1,length(string2));
        if pattern(1)>1
            check2=check;
            check2(1:pattern(1))=zeros(1,pattern(1));
            check3=check;
            check3((pattern(1)+length(string2)-1):length(check3))=zeros(1,(length(check3)-length(string2)+pattern(1)));
            string3=[string1(logical(check3)) '...' string1(logical(check2))];
        else
            string3=string1(logical(check));
        end
        data{handles.indices(1),handles.indices(2)}=string3;
        %         [a,b]=size(data);
        %         data2=cell(a.*b,1);
        %         for i=1:b;
        %             data2(((i-1)*a+1):i*a)=data(:,i);
        %         end
        %         data2=sortrows([data2;string3]);
        %         for i=1:length(data2);
        %             if strcmp(data2{i},string3)
        %                 k=i;
        %             end
        %         end
        %         if k==1;
        %             string4=data2{2};
        %         else
        %             string4=data2{k-1};
        %         end
        
        set(handles.uitable1,'Data',data);
    end
    
    
    guidata(gcf,handles);
end
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes when selected cell(s) is changed in uitable1.
function uitable1_CellSelectionCallback(hObject, eventdata, handles)
handles.indices=eventdata.Indices;
if not(isempty(handles.indices))
    data=get(handles.uitable1,'Data');
    currentstring=data{handles.indices(1),handles.indices(2)};
    if not(isempty(currentstring));
        pattern=strfind(currentstring,'...');
        if not(isempty(pattern));
            currentstring=[currentstring(1:(pattern(1)-1)) get(handles.text1,'String') currentstring((pattern(1)+3):length(currentstring))];
        else
            currentstring=[get(handles.text1,'String') currentstring]
        end
        for i=1:length(handles.filenamesall);
            if strcmp(currentstring,handles.filenamesall{i});
                k=i;
            end
        end
        for i=1:length(handles.includes)
            if k==handles.includes(i)
                set(handles.listbox1,'Value',i)
            end
        end
        for i=1:length(handles.excludes)
            if k==handles.excludes(i)
                set(handles.listbox2,'Value',i)
            end
        end
    end
    guidata(gcf,handles);
end
% hObject    handle to uitable1 (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
data=get(handles.uitable1,'Data');
[a,~]=size(data);
data=[data cell(a,1)];
set(handles.uitable1,'Data',data);
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
data=get(handles.uitable1,'Data');
[~,b]=size(data);
data=data(:,1:b-1);
set(handles.uitable1,'Data',data);
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
data=get(handles.uitable1,'Data');
[~,b]=size(data);
data=[data; cell(1,b)];
set(handles.uitable1,'Data',data);
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
data=get(handles.uitable1,'Data');
[a,~]=size(data);
data=data(1:(a-1),:);
set(handles.uitable1,'Data',data);
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
data=get(handles.uitable1,'Data');
[a,b]=size(data);
averages=cell(a,1);
commonstring=get(handles.text1,'String');
allstrings=cell(a,1);
for i=1:a;
    k=0;
    yvalues=zeros(size(handles.yvalues));
    for j=1:b;
        if not(isempty(data{i,j}));
            k=k+1;
            string=data{i,j};
            pattern=strfind(string,'...');
            if isempty(pattern);
                string2=[commonstring string];
            else
                string2=[string(1:(pattern(1)-1)) commonstring string((pattern(1)+3):length(string))];
            end
            for h=1:length(handles.filenamesall);
                if strcmp(handles.filenamesall{h},string2);
                    currentyvalues=handles.yvaluesall{h};
                    if isempty(allstrings{i})
                        allstrings{i}=string2;
                    else
                        allstrings{i}=[allstrings{i} ' + ' string2];
                    end
                end
            end
            yvalues=yvalues+currentyvalues;
        end
    end
    yvalues=yvalues./k;
    averages{i}=yvalues;
end
k=1:length(averages);
check=ones(length(averages),1);
for i=1:length(averages);
    if isempty(averages{i});
        check(i)=0;
    end
end
check=logical(check);
averages=averages(check);
k=k(check);
allstrings=allstrings(check);
allstrings2=cell(size(allstrings));
for i=1:length(k);
    string=['average ' num2str(k(i))];
    allstrings2{i}=string;
    allstrings{i}=[string ' = ' allstrings{i}];
end
h=findobj('Tag','Libsfigure');
handles_main=guidata(h);
set(handles_main.popupmenu2,'String',allstrings2);
set(handles_main.popupmenu2,'Value',1);
handles_main.xvaluesall=handles_main.xvaluesall(k);
handles_main.yvaluesall=averages;
handles_main.yvalues=averages{1};
guidata(h,handles_main)

if get(handles.checkbox1,'Value')
    pathname=get(handles.edit3,'String');
    mkdir(pathname);
   beginstring=get(handles.edit4,'String');
   extension=findfilextension(handles.filenamesall{1});
   if isempty(extension);
       extension='.txt';
   end
   dlmwrite([pathname 'averages_metadata.txt'],'')
   fileid=fopen([pathname 'averages_metadata.txt'],'w');
    for i=1:length(k);
        string=[beginstring num2str(k(i)) extension];
        dlmwrite([pathname string],[handles.xvalues averages{i}],'newline', 'pc','precision',9)
        fprintf(fileid,'%s\r\n',allstrings{i});
    end
end



% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
switch get(hObject,'Value')
    case 0
        set(handles.edit3,'Enable','off')
        set(handles.edit4,'Enable','off')
        set(handles.text7,'Enable','off')
    case 1
        set(handles.edit3,'Enable','on')
        set(handles.edit4,'Enable','on')
        set(handles.text7,'Enable','on')
end
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
