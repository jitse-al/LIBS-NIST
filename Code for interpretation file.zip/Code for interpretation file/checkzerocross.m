function crossedzero=checkzerocross(x)
crossedzero=zeros(size(x));
for i=2:length(x)
    if x(i)>0
        if x(i-1)<0
            crossedzero(i)=1;
        end
    elseif x(i)==0
        crossedzero(i)=1;
    else
        if x(i-1)>0
            crossedzero(i)=1;
        end
    end
end
end
    
