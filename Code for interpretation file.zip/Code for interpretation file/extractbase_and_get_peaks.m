function [fittedresults,parameters,stoppingreasons,peakbounds,peakbounds2,parametersall,basemodel]=extractbase_and_get_peaks(x,y)
tic
[basemodel,~,stoppingreasons,peakbounds,peakbounds2]=extractbase(x,y);
'extractbase'
toc
nriterations=3;
parameters=cell(nriterations,1);
fittedresults=parameters;
[parameters{1},fittedresults{1}]=fitallpeaks(x,y,basemodel,peakbounds2); %parameters: x0, height, FWHM;
parameterstemp=parameters{1};
upperpart=0.35;
parameterstemp=evaluate_wellness_peakfit(x,y,basemodel,parameterstemp,upperpart);
% parameterscheck=parameterstemp(:,2)>quantile(parameterstemp(:,2),0.80);
% parameterstemp=parameterstemp(parameterscheck);
% y2=abs(y-multilorentz(parameterstemp,x));
[xout,yout]=excludepeaks2(x,y,parameterstemp,1.5);
'1xfitallpeaks'
toc
[basemodel2,~,~,~,peakbounds3]=extractbase(xout,yout);
'2x extractbase'
toc
[parameters{2},fittedresults{2}]=fitallpeaks(xout,yout,basemodel2,peakbounds3);
upperpart=0.25;
parameterstemp2=evaluate_wellness_peakfit(x,y,basemodel,parameters{2},upperpart);
plot(x,y-basemodel,x,multilorentz(parameterstemp,x),x,multilorentz(parameterstemp2,x))
% [parameters{2},fittedresults{2}]=fitallpeaks(x,y,basemodel,peakbounds);
'2xfitallpeaks'
toc
parametersall=[parameterstemp;parameterstemp2];
% extrapeaks1=extractbase2(x,y-fittedresults{1},x,basemodel,100,0.10,2);
% extrapeaks2=extractbase2(x,y-fittedresults{2},x,basemodel,100,0.10,2);
% peakboundsall=sortrows([peakbounds;peakbounds2;extrapeaks1;extrapeaks2],1);
% k=1;
% for i=2:length(peakboundsall);
%     if peakboundsall(i,1)~=peakboundsall(i-1,1);
%         if peakboundsall(i,2)~=peakboundsall(i-1,2);
%             k=[k;i];
%         end
%     end
% end
% 'peakboundsall'
% toc
% peakboundsall=peakboundsall(k,:);
% [parameters{3},fittedresults{3}]=fitallpeaks(x,y,basemodel,peakboundsall);
% 'fit peakboundsall'
% toc
% testedresults=cell(nriterations,1);
% parametersize=zeros(nriterations,1);
% for i=1:nriterations
%     testedresults{i}=simplify2((y-fittedresults{i}).^2,20);
%     parametersize(i)=length(parameters{i});
% end
% minimumerrors=zeros(size(x));
% for i=1:length(x);
%     test=[];
%     for j=1:nriterations;
%         test=[test;testedresults{j}(i)];
%     end
%     [~,minimumerrors(i)]=min(test);
% end
% minimumpeakwidth=2;
% parametersall=[];
% for i=(minimumpeakwidth+1):(length(x)-minimumpeakwidth);
%     testnr=minimumerrors(i);
%     for j=1:parametersize(testnr);
%         if parameters{testnr}(j,1)>x(i-minimumpeakwidth);
%             if parameters{testnr}(j,1)<x(i+minimumpeakwidth);
%                 parametersall=[parametersall;parameters{testnr}(j,:)];
%             end
%         end
%     end
% end
% k=1;
% for i=2:length(parametersall);
%     if and(parametersall(i,2)>parametersall(i-1,2)*0.90,parametersall(i,2)<parametersall(i-1,2)/0.90);
%         if and(parametersall(i,3)>parametersall(i-1,3)*0.90,parametersall(i,3)<parametersall(i-1,3)/0.90);
%         k=[k;i];
%         end
%     end;
% end
% parametersall=parametersall(k,:);
% plot(x,y-basemodel,x,fittedresults{1},'--',x,fittedresults{2},'--',x,fittedresults{3},'--',x,basemodel+multilorentz(parametersall,x));
'function close'
toc