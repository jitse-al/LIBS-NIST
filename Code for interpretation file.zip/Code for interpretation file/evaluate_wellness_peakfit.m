function parameters=evaluate_wellness_peakfit(x,y,baseline,parameters,upperpart)
if not(exist('upperpart','var'))
    upperpart=1;
end
dx=zeros(size(x));
for i=2:length(x);
    dx(i)=y(i)-y(i-1);
end
dx=sort(abs(dx));
dx=quantile(dx,0.25);
check=parameters(:,2)>dx;
parameters=parameters(check,:);
ymodel=multilorentz(parameters,x);
ymodel=y-baseline-ymodel;
ymodel=ymodel.^2;
for i=1:size(parameters)
    x1=findxposition(x,parameters(i,1));
    x2=x1-5;
    x3=x1+6;
    parameters(i,4)=sqrt(sum(ymodel(x2:x3)/12))/parameters(i,2);
end
parameters=sortrows(parameters,4);
check=size(parameters);
check=round(check*upperpart);
parameters=parameters(1:check,1:4);