function [crossedzero_positive,crossedzero_negative, error]=checkzerocross2(x)
error=0;
crossedzero_positive=zeros(size(x));
crossedzero_negative=crossedzero_positive;
crossedzero_neutral=crossedzero_positive;
for i=2:length(x)
    if x(i)>0
        if x(i-1)<0
            crossedzero_positive(i)=1;
        end
    elseif x(i)==0
        crossedzero_neutral(i)=1;
    else
        if x(i-1)>0
            crossedzero_negative(i)=1;
        end
    end
end
if sum(crossedzero_neutral)>0;
    if sum(crossedzero_positive)>sum(crossedzero_negative);
        crossedzero_negative=crossedzero_negative+crossedzero_neutral;
    else
        crossedzero_positive=crossedzero_positive+crossedzero_neutral;
    end
    if sum(crossedzero_positive)~=sum(crossedzero_negative)
        error=1;
    end
end
end