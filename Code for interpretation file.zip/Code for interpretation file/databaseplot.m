function databaseplotout=databaseplot(varargin)
global legend_database_string legend_string
n=nargin;
c=0;
plotvalue=[];
speciesfrequency=zeros(n*3,2);
speciesfrequency(1,1)=1;
speciessizetotal=0;
unique_species_total=[];
counter=0;
for j=1:n
    element=varargin{j};
    wavelength=element{1};
    intensity=element{2};
    species=element{3};
    unique_species=unique(species);
    speciessize=length(unique_species);
    unique_species_total=[unique_species_total;unique_species]; %#ok<AGROW>
    for i=1:speciessize;
        compare=strcmp(unique_species(i),species);
        c=c+length(wavelength(compare));
        plotvaluetemp=[wavelength(compare),zeros(size(wavelength(compare)));wavelength(compare),intensity(compare);wavelength(compare),NaN(size(wavelength(compare)))];
        plotvaluetemp=sortrows(plotvaluetemp,1);
        plotvalue=[plotvalue;plotvaluetemp]; %#ok<AGROW>
        counter=counter+1;
        speciesfrequency(counter,2)=c*3;
        speciesfrequency(counter+1,1)=c*3+1;
    end
    speciessizetotal=speciessizetotal+speciessize;
end
colors=contrasting_colors(speciessizetotal);
hold on
for i=1:speciessizetotal;
    up=speciesfrequency(i,1);
    down=speciesfrequency(i,2);
    databaseplotout(i)=plot(plotvalue(up:down,1),plotvalue(up:down,2)/max(plotvalue(up:down,2)),'Color',colors(i,:)); %#ok<AGROW>
end
for i=1:length(unique_species_total)
    a=unique_species_total{i};
    b=isletter(a);
    for j=2:length(b)-1;
        if and(b(j-1)==1,b(j+1)==1)
            b(j)=1;
        end
    end
    a=cellstr(a(b));
    unique_species_total(i)=a; %#ok<AGROW>
end
legend_database_string=unique_species_total;
legend_string=define_legend_string;
legend(legend_string)
end