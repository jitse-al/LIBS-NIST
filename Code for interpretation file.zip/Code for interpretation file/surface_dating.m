erosion_rate=[0 0.001 0.003 0.01]; %mm/yr
production_rate=[119 6 15 196 30 300]; %(atoms/g/yr)
lambda=[0 4.59037867920494e-07 0.000120968094338559 0 9.68082654413331e-07 2.3028145533553e-06]; %yr-1
density=0.0030; %g/mm3
atenuation_length=1.6; %g/mm2
tlog=2:0.01:7.5;
t=10.^tlog;
colors=contrasting_colors(6);
epl=erosion_rate*density/atenuation_length;
hold on
n=cell(4,6);
for i=1:4;
    for j=1:6;
        n{i,j}=production_rate(j)/(lambda(j)+epl(i)).*(1-exp(-(lambda(j)+epl(i)).*t));
        plot(tlog,(log(n{i,j})/log(10)),'Color',colors(j,:))
        legend('He','Be','C','Ne','Al','Cl');
    end
end
figure
hold on
for i=1:4;
    plot(log(n{i,2})/log(10),n{i,5}./n{i,2},'Color',colors(i,:));
end
legend('0', '1', '3', '10')
        
