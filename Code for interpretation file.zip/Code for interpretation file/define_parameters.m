global leftbound rightbound ub lb npeaks xvalues yvalues peakless_points cancelvalue

plot(xvalues,yvalues);

a=0; 
% first loop asks the questions. Important: split is set at a standard, but
% it can be redefined
x=inputdlg({'left boundary' 'right boundary'},'choose window');
if isempty(x)
    cancelvalue=1;
    return
end
leftbound=str2num(x{1});
rightbound=str2num(x{2});
% [subsetx,subsety]=baselinesubstraction(xvalues,yvalues,leftbound,rightbound);
% plot(subsetx,subsety)
[echelle_orders,n_orders]=find_echelle_orders(leftbound,rightbound);
peakless_points=ones(1,n_orders).*leftbound;
a=0;
while a==0;
    for i=1:n_orders
        [subsetx,subsety, ~,modeloutput,subsety_real]=baseline_echelle(xvalues,yvalues, leftbound, rightbound,peakless_points);
        plot(subsetx,[subsety_real, modeloutput, subsety, zeros(size(subsetx))]);
        ylim([-500 max(subsety_real)+300]);
        texttotal='Select minimum for baseline between %g and %g';
        texttotal=sprintf(texttotal,echelle_orders(i),echelle_orders(i+1));
        peakchoice=inputdlg(texttotal,'Input for baseline',1,{num2str(peakless_points(i))});
        peakless_points(i)=str2num(peakchoice{1});
    end
    [subsetx,subsety, slopevalue,modeloutput,subsety_real,n_orders]=baseline_echelle(xvalues,yvalues, leftbound, rightbound,peakless_points);
    plot(subsetx,[subsety_real, modeloutput, subsety, zeros(size(subsetx))]);
    ylim([-500 max(subsety_real)+300]);
    legend('data','baseline','baseline subtracted', '0')
    choice=questdlg('baseline ok?','check','yes','no','yes');
    switch choice
        case 'yes'
            a=1;
        case 'no'
            choice=questdlg('Redefine','Question','new boundaries','redefine minima','redefine minima');
            switch choice
                case 'new boundaries'
                    split2=inputdlg({'left bound','right bound'},'New boundaries');
                    if isempty(split2)
                        cancelvalue=1;
                        return
                    end
                    leftbound=str2num(split2{1});
                    rightbound=str2num(split2{2});
            end
    end
end

x=inputdlg({'number of peaks'},'choose window');
if isempty(x)
    cancelvalue=1;
    return
end
npeaks=str2num(x{1});

a=0;
while a==0;
    lb=zeros(npeaks,1);
    ub=zeros(npeaks,1);
    for i=1:npeaks;  %redefining parameters
        x=inputdlg({'lower limit peak' 'upper limit peak'},'choose window');
        if isempty(x)
            cancelvalue=1;
            return
        end
        lb(i)=str2num(x{1});
        ub(i)=str2num(x{2});
    end
    [subsetx,subsety, ~,baseline,subsety_real,~]=baseline_echelle(xvalues,yvalues,leftbound,rightbound,peakless_points);
    [~,tempoutput]=fitmultilorentz(subsetx,subsety,npeaks,lb,ub);
    plot(subsetx,subsety_real, subsetx,(multilorentz(tempoutput,subsetx)+baseline))
    
    choice=questdlg('subset ok?','check','yes','no','yes');
    switch choice
        case 'yes'
            a=1;
        case 'no'
            choice=questdlg('Redefine','Question','new peak limits','new boundaries','other number of peaks','new peak limits');
            switch choice
                case 'split'
                    split1=inputdlg('number of peaks');
                    if isempty(split1)
                        cancelvalue=1;
                        return
                    end
                    npeaks=str2num(split1{1});
                case 'new boundaries'
                    split2=inputdlg({'left bound','right bound'},'New boundaries');
                    if isempty(split2)
                        cancelvalue=1;
                        return
                    end
                    leftbound=str2num(split2{1});
                    rightbound=str2num(split2{2});
            end
    end
end


npeaksstring=['npeaks=' mat2str(npeaks) ';'];
leftboundstring=['leftbound=' mat2str(leftbound) ';'];
rightboundstring=['rightbound=' mat2str(rightbound) ';'];
lbstring=['lb=' mat2str(lb) ';'];
ubstring=['ub=' mat2str(ub) ';'];
ppstring=['peakless_points=' mat2str(peakless_points) ';']
totalstring=char(npeaksstring, leftboundstring, rightboundstring, lbstring, ubstring,ppstring);
mat2clip(totalstring);
message=msgbox(char('Data copied to clipboard:', totalstring, '', 'copy into parameter_input.m'));
uiwait(message);