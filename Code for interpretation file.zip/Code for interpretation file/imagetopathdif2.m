function [pathout,image1]=imagetopathdif2(image_start,max_order)
increment_pathrange=25;
[~,~,~,rgb,pathrange_orders]=create_michel_levy_chart(2500,increment_pathrange);
orderlength=length(rgb);
if orderlength>max_order;
    orderlength=max_order;
end
pathout=cell(orderlength,1);
[a,b,~]=size(image_start);

image_start=im2double(image_start);
image_start=permute(image_start,[1 3 2]);
image1=image_start;
for i=1:a;
    for j=1:b
        maximum=sqrt(sum(image1(i,:,j).^2));
        image1(i,:,j)=image_start(i,:,j)./maximum;
    end
end

for t=1:orderlength;
    for i=1:length(rgb{t});
        rgb{t}(i,:)=rgb{t}(i,:)./sqrt(sum(rgb{t}(i,:).^2));
    end
end

for t=1:orderlength;
    for i=1:a;
        for j=1:b;
            ll=1;
            ul=length(pathrange_orders{t});
            checkrange=ll:ul;
            endvalues=zeros(size(checkrange));
            for k=1:length(checkrange);
                differencevalue=rgb{t}(checkrange(k),:)-image1(i,:,j);
                differencevalue=differencevalue.^2;
                endvalues(k)=sum(differencevalue);
            end
            [~,index]=min(endvalues);
            pathout{t}(i,j)=pathrange_orders{t}(checkrange(index));
            if i==300;
                area([1 3],[1 1],'FaceColor',rgb{t}(checkrange(index),:))
                hold on
                area([2 3],[1 1],'FaceColor',image1(i,:,j))
                hold off
                pause(0.1)
            end
        end

    end
end
image1=permute(image1,[1,3,2]);