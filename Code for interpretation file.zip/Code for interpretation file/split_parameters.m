function [lb,ub,npeaks,subx,suby,subx2]=split_parameters(x,y,numberofpeaks,leftbound,rightbound,lower_peak_limits,upper_peak_limits)
minx=min(x);
splitvalue=floor(minx/120);
nsplits=floor((rightbound-leftbound)/splitvalue)+2;
beginvalues=zeros(nsplits,1);
beginvalues(1)=leftbound;
splitvalue=(rightbound-leftbound)/(nsplits-1);
for i=2:nsplits;
    beginvalues(i)=beginvalues(i-1)+splitvalue;
end
checklogical=logical(checkzerocross(simplify2(y,6)));
possiblevalues=x(checklogical);%reminder; build in check possiblevalues<beginvalues: line 16-21
dependence=0;
checklogical=logical(closetozero(x,dependence));
closetozeros=x(checklogical);
while length(possiblevalues)+length(closetozeros)<length(beginvalues)
    checklogical=logical(closetozero(x,dependence));
    closetozeros=x(checklogical);
    dependence=dependence+1;
end
possiblevalues2=sort([possiblevalues;closetozeros]) ;   
positions=ones(size(beginvalues));
a=0;
while a==0
    try
        for i=2:(nsplits-1)
            positions(i)=findxposition(possiblevalues2,beginvalues(i));
            if positions(i)==positions(i-1)
                positions(i)=findxposition(possiblevalues2,beginvalues(i),'up');
            end
        end
        a=1;
    catch
        dependence=dependence+1;
        checklogical=logical(closetozero(x,dependence));
        closetozeros=x(checklogical);
        possiblevalues2=sort([possiblevalues;closetozeros]);
    end
end
finalvalues=possiblevalues2(positions);
finalvalues(1)=leftbound;
finalvalues(nsplits)=rightbound;
subx=cell((nsplits-1),1);
suby=subx;
npeaks=zeros((nsplits-1),1);
lb=subx;
ub=subx;
for i=1:(nsplits-1);
    [x1,x2]=findxpositions(x,finalvalues(i),finalvalues(i+1));
    subx2{i}=[x1 x2];
    [subx{i}, suby{i}]=subset(x,y,finalvalues(i),finalvalues(i+1));
    for j=1:numberofpeaks;
        if and(lower_peak_limits(j)>=min(subx{i}),upper_peak_limits(j)<=max(subx{i}))
            lb{i}=[lb{i};lower_peak_limits(j)];
            ub{i}=[ub{i};upper_peak_limits(j)];
            npeaks(i)=npeaks(i)+1;
        end
    end
end
logicalcheck=logical(npeaks);
npeaks=npeaks(logicalcheck);
lb=lb(logicalcheck);
ub=ub(logicalcheck);
subx=subx(logicalcheck);
suby=suby(logicalcheck);
subx2=subx2(logicalcheck);
end