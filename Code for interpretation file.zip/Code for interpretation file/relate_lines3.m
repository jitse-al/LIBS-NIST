function [likelyinfo,totalfactor3,mostlikelyspecies]=relate_lines3(info,parameters,mode,species)
switch mode
    case 'Ritz'
        w=4;
    case 'Observed'
        w=5;
end
preferencefactor=[4 3 2];
weight1=4;
weight2=0.1;
weight3=1;
maxdev=0.03;

errorinput=cell(1,24);
for i=1:24
    errorinput{i}=NaN;
end

[~,b]=size(info);
mostlikelyspecies=cell(b,2);
for l=1:b;
    likelyinfo=cell(length(info),24);
    totalfactor3=zeros(length(info),1);
    for i=1:length(info);
        [a,~]=size(info{i,l});
        factortotal=zeros(a,3);
        for j=1:a
            factortotal(j,1)=info{i,l}{j,6};
            factortotal(j,2)=parameters(i)-info{i,l}{j,w};
            if strcmp(info{i,l}{j,1},species(1));
                factortotal(j,3)=preferencefactor(1);
            elseif strcmp(info{i,l}{j,1},species(2));
                factortotal(j,3)=preferencefactor(2);
            elseif strcmp(info{i,l}{j,1},species(3));
                factortotal(j,3)=preferencefactor(3);
            else
                factortotal(j,3)=1;
            end
        end
        factortotal2=zeros(a,1);
        for j=1:a
            if isnan(factortotal(j,1));
                factortotal(j,1)=mean(factortotal(:,1));
            end
            factortotal2(j)=(factortotal(j,1))^weight1/((abs(factortotal(j,2))/max(factortotal(:,2)))+weight2).*factortotal(j,3)^weight3;
            if factortotal(j,2)>maxdev;
                factortotal2(j)=0;
            end
        end
        [totalfactor3(i),index]=max(abs(factortotal2));
        if totalfactor3(i)==0
            likelyinfo(i,:)=errorinput;
        else
            likelyinfo(i,:)=info{i,l}(index,:);
        end
    end
    mostlikelyspecies{l,1}=likelyinfo;
    mostlikelyspecies{l,2}=totalfactor3;
end
mostlikelyspecies=[mostlikelyspecies cell(b,3)];
for l=1:b;
    mostlikelyspecies{l,1}=mostlikelyspecies{l,1};
    mostlikelyspecies{l,3}=parameters;
    
    [factorpossible,index]=sort(cell2mat(mostlikelyspecies{l,1}(:,6)),'descend');
    factorfound=cell2mat(mostlikelyspecies(l,3));
    factorfound=factorfound(index);
    fcheck=factorpossible>0;
    factorfound2=factorfound(fcheck);
    factorpossible2=factorpossible(fcheck);
    %     max(factorfound)
    %     figure
    %     plot(factorpossible2(1:10),factorfound2(1:10));
    if size(factorpossible2)>0
        factor=[];
        for i=1:10
            factor=[factor;factorpossible2(i)/factorfound2(i)];
        end
        factor=sort(factor);
        factor=quantile(factor,0.80);
        mostlikelyspecies{l,5}=mostlikelyspecies{l,1};
        k=[];
        for i=1:length(factorfound)
            if (2*mostlikelyspecies{l,5}{i,6})<mostlikelyspecies{l,3}(i)*factor;
                mostlikelyspecies{l,5}(i,:)=errorinput;
            elseif isnan(2*mostlikelyspecies{l,5}{i,6})
                mostlikelyspecies{l,5}(i,:)=errorinput;
            else
                k=[k;i];
            end
        end
    else
        k=0;
    end
    mostlikelyspecies{l,4}=unique(k);
    
    
end


