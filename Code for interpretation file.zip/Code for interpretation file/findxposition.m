function [x1]=findxposition(data,point,rounding)
if not(exist('rounding','var'))
    rounding='down';
end
a1=sign(sign(data-point)-0.5);
switch rounding
    case 'down'
        for i=1:(length(data)-1);
            g=i+1;
            if a1(i)<a1(g)
                x1=i;
            end
        end
    case 'up'
        for i=1:(length(data)-1);
            g=i+1;
            if a1(i)<a1(g)
                x1=g;
            end
        end
end

% always rounds down to nearest point