function cellwitheverything=nisttransform(wavelength,intensity,species)
a=not(isnan(wavelength));
wavelength2=wavelength(a)/10;
intensity2=intensity(a);
species2=species(a);
cellwitheverything={wavelength2,intensity2,species2};
end

    