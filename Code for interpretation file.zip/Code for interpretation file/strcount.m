function [names,numbers]=strcount(listofcells)
names=unique(listofcells);
numbers=zeros(size(names));
for i=1:length(listofcells);
    for j=1:length(names);
        if strcmp(names(j),listofcells(i));
            numbers(j)=numbers(j)+1;
        end
    end
end
[numbers,index]=sort(numbers,'descend');
names=names(index);