function [subsetx,subsety]=subset(datax,datay, limit1, limit2)
[x1,x2]=findxpositions(datax,limit1,limit2);
subsetx=datax(x1:x2);
subsety=datay(x1:x2);
end