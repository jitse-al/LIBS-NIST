function peakbounds=extractbase2(x,y,basex,basey,steps,quantilenumber,simplifynr)
if not(exist('simplifynr','var'));
    simplifynr=5;
end
y2=interp1(basex,basey,x);
ymodel=y-y2;
ymodelsimp=simplify2(ymodel,simplifynr);
ymax=max(ymodelsimp);
stoppingpoint=quantile(sort(abs(y2)),quantilenumber);
if stoppingpoint==0;
    stoppingpoint=(ymax./steps)/1000;
end
ymin=(3/(steps+2))*ymax-stoppingpoint-min(ymodelsimp);
peakbounds2=[];
xnumber=1:length(x);
% figure
for i=1:steps;
    steprev=3/(i+2);
    height=steprev*ymax-ymin;
    if height>ymax;
        height=ymax-1;
    end
%     plot(x,ymodelsimp,x,height.*ones(size(y)))
%     hold on
    [checkp,checkn,error]=checkzerocross2(ymodelsimp-height);
    if not(error)
        peakboundsp=xnumber(logical(checkp))';
        peakboundsn=xnumber(logical(checkn))';
        while peakboundsp(1)>peakboundsn(1);
            peakboundsn=peakboundsn(2:length(peakboundsn));
        end
        while length(peakboundsp)~=length(peakboundsn)
            peakboundsp=peakboundsp(1:(length(peakboundsp)-1));
        end
        peakbounds=[peakboundsp peakboundsn];
        peakbounds=[peakbounds zeros(size(peakbounds))];
        if i==1;
            peakbounds(:,3)=height.*ones(size(peakbounds(:,3)));
            peakbounds2=peakbounds;
        else
            peakbounds2=combine_peakbounds(peakbounds,peakbounds2,height);
        end
    end
end
peakbounds=peakbounds2;
% % FOLLOWING CREATES FIGURE to CHECK PEAKBOUNDS: UNCOMMENT IF NECESSARY
% figure
% multiarea(peakbounds(:,1:2),0,max(ymodel));
% hold on
% plot(ymodel)

%plot(x,y,x(peakbounds2(:,1:2)),y(peakbounds2(:,1:2)),'o')