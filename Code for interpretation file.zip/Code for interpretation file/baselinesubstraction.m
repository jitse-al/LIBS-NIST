function [subsetx,subsety, slopevalue, intersectvalue]=baselinesubstraction(datax,datay, limit1, limit2)
[x1,x2]=findxpositions(datax,limit1,limit2);
mean1=mean(datay((x1-5):(x1+5)));
mean2=mean(datay((x2-5):(x2+5)));
slopevalue=(mean2-mean1)/(datax(x2)-datax(x1));
intersectvalue=mean1-slopevalue*(datax(x1));
subsetx=datax(x1:x2);
subsety1=datay(x1:x2);
subsety=subsety1-(subsetx*slopevalue+intersectvalue);
end