function new=simplify2(x,averageover)
if not(exist('averageover','var'))
    averageover=1;
end
new=x;
lengthx=length(x);
if lengthx>(2*averageover);
    
    for i=(1+averageover):(lengthx-averageover);
        new(i)=mean(x((i-averageover):(i+averageover)));
    end
    for i=2:averageover
        new(i)=mean(x(1:(i+averageover)));
        new(lengthx-i+1)=mean(x((length(x)-i-averageover+1):lengthx));
    end
end
    