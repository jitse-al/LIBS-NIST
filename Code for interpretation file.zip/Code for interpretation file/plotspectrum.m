function [xvalues,yvalues]=plotspectrum
[filename,pathname,filterindex]=uigetfile('*.*');
xvalues=importdata([pathname 'xdata']);
yvalues=importdata([pathname filename]);
plot(xvalues,yvalues/max(yvalues))
xlabel('Wavelength (nm)')
ylabel('Intensity (normalized)')
end