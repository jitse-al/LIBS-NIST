function varargout = Multispectral_analysis_figure(varargin)
% MULTISPECTRAL_ANALYSIS_FIGURE MATLAB code for Multispectral_analysis_figure.fig
%      MULTISPECTRAL_ANALYSIS_FIGURE, by itself, creates a new MULTISPECTRAL_ANALYSIS_FIGURE or raises the existing
%      singleton*.
%
%      H = MULTISPECTRAL_ANALYSIS_FIGURE returns the handle to a new MULTISPECTRAL_ANALYSIS_FIGURE or the handle to
%      the existing singleton*.
%
%      MULTISPECTRAL_ANALYSIS_FIGURE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MULTISPECTRAL_ANALYSIS_FIGURE.M with the given input arguments.
%
%      MULTISPECTRAL_ANALYSIS_FIGURE('Property','Value',...) creates a new MULTISPECTRAL_ANALYSIS_FIGURE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Multispectral_analysis_figure_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Multispectral_analysis_figure_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Multispectral_analysis_figure

% Last Modified by GUIDE v2.5 12-Oct-2015 12:10:39

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @Multispectral_analysis_figure_OpeningFcn, ...
    'gui_OutputFcn',  @Multispectral_analysis_figure_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Multispectral_analysis_figure is made visible.
function Multispectral_analysis_figure_OpeningFcn(hObject, eventdata, handles, varargin)

% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Multispectral_analysis_figure (see VARARGIN)

% Choose default command line output for Multispectral_analysis_figure
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
global selected_cells editabledata xvalues yvalues leftbound rightbound subsetplot subsetx peakless_points e_baseline e_baselineplot subsety vertplot vertplotcurrent echelle_orders corrections currentdata npeaks lb ub n_orders fitplot
global lowbpeaks upbpeaks nrpeaks subx suby subx2
global numberoffiles filename x_data pathname x_data_title
parameter_input;
parameter_input_2;
proposedfilename=filename(1:length(filename)-1);
numberoffilesans=inputdlg({'number of files','start of filename'},'define input',1,{num2str(length(x_data)),proposedfilename});
if isempty(numberoffilesans)
    return
end
numberoffiles=str2num(numberoffilesans{1});
filenamestart=numberoffilesans{2};
output=zeros(npeaks.*numberoffiles,5);
parameters=zeros(npeaks.*numberoffiles,3);

yvaluesall=zeros(size(xvalues),numberoffiles);
baselineall=zeros(size(subsetx),numberoffiles);
size(subsetx)
for j=1:length(subx2)
    x1=subx2{j};
    subx{j}=subsetx(x1(1):x1(2));
end
for j=1:numberoffiles;
    filename=[filenamestart num2str(j)];
    yvalues=importdata([pathname filename]);
    yvaluesall(:,j)=yvalues;
    [subsetx,subsety]=subset(xvalues,yvalues,leftbound,rightbound);
    [~,~,~,baseline]=baseline_echelle(xvalues,yvalues,leftbound,rightbound,peakless_points, corrections);
    %    [lowbpeaks,upbpeaks,nrpeaks,subx,suby]=split_parameters(subsetx,subsety,npeaks,leftbound,rightbound,lb,ub);
    %   [subsetx,subsety,slopevalue,intersectvalue]=baselinesubstraction(xvalues,yvalues,leftbound,rightbound);
    subsety=subsety-baseline;
    suby=cell(size(subx));
    for h=1:length(subx2)
        x1=subx2{h};
        suby{h}=subsety(x1(1):x1(2));
    end
    [tempparameters,tempoutput{j}]=splitlorentzfit(lowbpeaks,upbpeaks,nrpeaks,subx,suby);
    %   tempparameters(:,6)=slopevalue;
    %   tempparameters(:,7)=intersectvalue;
    baselineall(:,j)=baseline;
    tempparameters=sortrows(tempparameters,2);
    parameternumber=j*npeaks;
    parameters(parameternumber-npeaks+1:parameternumber,:)=tempoutput{j};
    for h=1:npeaks;
        outputnumber=numberoffiles.*(h-1)+j; %create sorting mechanism
        output(outputnumber,:)=tempparameters(h,:);
    end
end

firstrow=[];
for j=1:npeaks;
    firstrow=[firstrow; ones(numberoffiles,1).*j]; %#ok<AGROW>
end
output(:,1)=firstrow;
%dlmwrite([pathname 'fittedpeakdata_lorentz' outputend], output,'newline', 'pc')
axes(handles.axes1);
hold on
for j=1:numberoffiles;
    [subsetx,subsety]=subset(xvalues,yvaluesall(:,j),leftbound,rightbound);
    fittedresults=multilorentz(tempoutput{j},subsetx);
    baseline=baselineall(:,j);
    baselineadded=fittedresults+baseline;
    plot(subsetx, baselineadded,'b')
    %plot(subsetx,voigty,'b'); %plot of fit
    plot(subsetx,subsety,'r'); %plot of data (turn on/off by %)
end
xlabel('wavelength')
ylabel('Peak height (relative)')
legend('Lorentzian fits by lsqcurvefit','data')
% print('-r400', [pathname filenamestart '_data_vs_fittedpeaks' outputend],'-dpng')
% saveas(1,[pathname filenamestart '_data_vs_fittedpeaks' outputend])


%colour=[0 0 1; 1 0 0; 0 1 0; 1 1 0; 1 0 1; 0 1 1];
colour=contrasting_colors2(npeaks);

% plots of center, height and width
axes(handles.axes2);
hold on
for j=1:npeaks;
    readbegin=1+numberoffiles.*(j-1);
    readend=numberoffiles+numberoffiles.*(j-1);
    plot(x_data, output(readbegin:readend,2),'Color',colour(j,:))
end
xlabel(x_data_title)
ylabel('Wavelength (nm) of peak center')
legend('peak 1', 'peak 2', 'peak 3','peak 4', 'peak 5', 'peak 6', 'peak 7', 'peak 8', 'peak 9', 'peak 10')
axes(handles.axes3);
hold on
for j=1:npeaks;
    readbegin=1+numberoffiles.*(j-1);
    readend=numberoffiles+numberoffiles.*(j-1);
    plot(x_data, output(readbegin:readend,3),'Color',colour(j,:))
end
xlabel(x_data_title)
ylabel('Peak height (relative)')
axes(handles.axes4)
hold on
for j=1:npeaks;
    readbegin=1+numberoffiles.*(j-1);
    readend=numberoffiles+numberoffiles.*(j-1);
    plot(x_data, output(readbegin:readend,4),'Color',colour(j,:))
end
xlabel(x_data_title)
ylabel('Peak width (FWHM, nm)')
% print('-r400', [pathname filenamestart '_peak_parameters' outputend],'-dpng')
% saveas(2,[pathname filenamestart '_peak_parameters' outputend])

% UIWAIT makes Multispectral_analysis_figure wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Multispectral_analysis_figure_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --------------------------------------------------------------------
function Menu_Callback(hObject, eventdata, handles)
% hObject    handle to Menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
