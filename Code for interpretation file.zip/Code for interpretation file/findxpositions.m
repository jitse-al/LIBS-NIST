function [x1,x2]=findxpositions(data,limit1,limit2)
a1=sign(sign(data-limit1)-0.5);
a2=sign(sign(data-limit2)-0.5);
x1=1;
x2=length(data);
for i=1:(length(data)-1);
    g=i+1;
    if a1(i)<a1(g)
        x1=i;
    end
    if a2(i)<a2(g)
        x2=g;
    end
end
end
