function [double2,double3,double4,double5,double6,double7]=relate_lines8(double)
double2=cell(0,6);
double3=cell(0,6);
double4=cell(0,6);
double5=cell(0,6);
double6=cell(0,6);
double7=cell(0,6);
[a,~]=size(double);
b=1;
c=1;
d=1;
e=1;
for i=1:a
    tempspecies=double{i,6};
    names=strcount(tempspecies(:,1));
    if size(names)==1 %sampe species, different ionization state --> base on relative theoretical intensities, calculated for 10.000K
        double2(b,:)=double(i,:);
        double2(b,6)=relate_lines5(double(i,6));
        double2{b,5}=[double2{b,6}{1,1} ' ' num2roman(double2{b,6}{1,2})];
        b=b+1;
    else
        intensities=cell2mat(double{i,6}(:,6));
        noisnan=cell(0,24);
        for j=1:length(intensities);
            if isnan(intensities(j))
                noisnan=[noisnan;double{i,6}(j,:)];
            end
        end
        ilog=log(intensities)./log(10);
        [maxilog,index]=max(ilog);
        check=ilog-maxilog;
        check=and(check<0,check>-1.5);
        check2=check(check);
        if isempty(check2);
            if isempty(noisnan)
                double3(c,:)=double(i,:);
                double3{c,6}=double3{c,6}(index,:);%very high intensity --> likely to be the identified peak (30x bigger than rest of intensities.
                double3{c,5}=[double3{c,6}{1,1} ' ' num2roman(double3{c,6}{1,2})];
                c=c+1;
            else
                double4(d,:)=double(i,:);
                double4{d,6}=[double4{d,6}(index,:);noisnan]; %low intensities thrown out, NaN remains.
                double4{d,5}=[double4{d,6}{1,1} ' ' num2roman(double4{d,6}{1,2}) ', ' double4{d,6}{2,1} ' ' num2roman(double4{d,6}{2,2})];
                double6(d,:)=double4(d,:);
                [double6temp,errors]=relate_lines5(double4(d,6),[300 10000 50000]); %based on bla A, G and Ek values
                if sum(size(errors))<3
                    double6(d,6)=double6temp;
                    double6{d,5}=[double6{d,6}{1,1} ' ' num2roman(double6{d,6}{1,2})];
                end
                d=d+1;
            end
        else
            check(index)=1;
            check=logical(check);
            double5(e,:)=double(i,:);
            if isempty(noisnan)
                double5{e,6}=double5{e,6}(check,:);
            else
                double5{e,6}=[double5{e,6}(check,:);noisnan];
            end
            double7(e,:)=double5(e,:);
            [double7temp,errors]=relate_lines5(double7(e,6),[300 10000 50000]);
            if sum(size(errors))<3
                double7(e,6)=double7temp;
                double7{e,5}=[double7{e,6}{1,1} ' ' num2roman(double7{e,6}{1,2})];%based on bla A, G and Ek values
            else
                l5temp=size(double7{e,6});
                string=[double7{e,6}{1,1} num2roman(double7{e,6}{1,2})];
                for j=2:l5temp;
                    string=[string ', ' double7{e,6}{j,1} ' ' num2roman(double7{e,6}{j,2})];
                    double7{e,5}=string;
                end
            end
            e=e+1;
        end
    end
end
