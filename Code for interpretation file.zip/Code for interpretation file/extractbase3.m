function [basex2,basey2]=extractbase3(x,y,peakbounds,rangefactor)
xlength=length(x);
meandx=(max(x)-min(x))/xlength;
meandx=meandx*rangefactor;
%peakbounds(:,5)=peakbounds(:,4)./peakbounds(:,3);
[lengthp,~]=size(peakbounds);
%row5=peakbounds(:,5);
%mean5=mean(row5(row5>0));
% for i=1:lengthp;
%     if peakbounds(i,5)==0
%         peakbounds(i,5)=mean5;
%     end
% end
endcheck=zeros(size(x));
for i=1:lengthp;
    xmid=(peakbounds(i,1)+peakbounds(i,2))/2;
    %dx=rangefactor*peakbounds(i,3)*peakbounds(i,5);
    dx=meandx*peakbounds(i,3);
    xstart=round(xmid-dx);
    if xstart<1;
        xstart=1;
    end
    xend=round(xmid+dx);
    if x>xlength
        x=xlength;
    end
    endcheck(xstart:xend)=ones((xend-xstart+1),1);
end
basex2=x(not(endcheck));
basey2=y(not(endcheck));
if max(basex2)<max(x);
    basex2=[basex2;max(x)];
    basey2=[basey2;0];
end
% plot(basex2,basey2,x,y);
% pause(1);

    
    