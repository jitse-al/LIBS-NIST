function [out,errorstring]=roman2nummultiple(value)
errorstring='';
value=lower(value);
stops2=value=='-';
stops4=logical(isequaltoanyof(value,'abcdefghijklmnopqrstuvwxyz'));
string='';
stringall=cell(length(value),2);
k=0;
kall=zeros(size(value));
for i=1:length(value);
    if stops4(i)==1;
        string=[string value(i)];
        if i==length(value);
            k=k+1;
            stringall{k,1}=string;
            string='';
        end
    elseif not(isempty(string));
        k=k+1;
        stringall{k,1}=string;
        string='';
    end
    kall(i)=k;
end
stringall=stringall(1:k,:);
kall=kall+1;
for i=1:length(value);
    if stops2(i)==1;
        stringall(kall(i)-1,2)=stringall(kall(i),1);
    end
end
for i=1:length(value);
    if stops2(i)==1;
        stringall=[stringall(1:kall(i)-1,:);stringall(kall(i)+1:length(stringall),:)];
    end
end
numbers=zeros(size(stringall));
[lx,~]=size(stringall);
for i=1:lx;
    for j=1:2;
        try
           numbers(i,j)=roman2num(stringall{i,j});
        catch
            try
            numbers(i,j)=roman2num(stringall{i,1});
            catch
                errorstring='Format not recognized';
            end
        end
    end
end
numbers2=[];
for i=1:lx
    numbers2=[numbers2 min(numbers(i,:)):max(numbers(i,:))];
end
out=unique(numbers2);