function out=simplifydatabaseforplotsfour(nist)
[lx,~]=size(nist);
out=nist;
for i=1:lx
    [lx2,~]=size(nist{i,1});
    for j=1:lx2
        [~,b]=size(nist{i,1}{j,1});
        out{i,1}{j,1}=nist{i,1}{j,1}(:,4:b);
    end
end