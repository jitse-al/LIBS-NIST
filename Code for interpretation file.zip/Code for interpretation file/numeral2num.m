function number=numeral2num(numeral)
c=numeral(isletter(numeral));
    switch c
        case 'I'
            number=1;
        case 'II'
            number=2;
        case 'III'
            number=3;
        case 'IV'
            number=4;
        case 'V'
            number=5;
        case 'VI'
            number=6;
        case 'VII'
            number=7;
        case 'VIII'
            number=8;
        case 'IX'
            number=9;
        case 'X'
            number=10;
        case 'XI'
            number=11;
        case 'XII'
            number=12;
        case 'XIII'
            number=13;
        case 'XIV'
            number=14;
        case 'XV'
            number=15;
        case 'XVI'
            number=16;
        case 'XVII'
            number=17;
        case 'XVIII'
            number=18;
        case 'XIX'
            number=19;
        case 'XX'
            number=20;
        case 'XXI'
            number=21;
        case 'XXII'
            number=22;
        case 'XXIII'
            number=23;
        case 'XXIV'
            number=24;
        case 'XXV'
            number=25;
        case 'XXVI'
            number=26;
        case 'XXVII'
            number=27;
        case 'XXVIII'
            number=28;
        case 'XXIX'
            number=29;
        case 'XXX'
            number=30;
    end
end