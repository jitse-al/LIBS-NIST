function [vertplotvaluesx,vertplotvaluesy]=vertlines(x,scalemax,scalemin)
xsize=size(x);
a=0;
if exist('scalemin')
    a=scalemin;
end
b=1;
if exist('scalemax')
    b=scalemax;
end
vertplotvaluesx=sort([x;x;x]);
vertplotvaluesy=zeros(size(vertplotvaluesx));
for i=1:xsize;
    vertplotvaluesy(i*3-2)=a;
    vertplotvaluesy(i*3-1)=b;
    vertplotvaluesy(i*3)=NaN;
end
end