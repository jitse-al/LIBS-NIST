function [factor1,factor2,T]=boltzmannplot(likelyinfo,likeliness,parameters,mode,species)
[parameters,index]=sortrows(parameters,4);
[lengthp,~]=size(parameters);
lengthp=round(lengthp.*0.5);
parameters=parameters(1:lengthp,:);
likelyinfo=likelyinfo(index,:);
likelyinfo=likelyinfo(1:lengthp,:);
likeliness=likeliness(index,:);
likeliness=likeliness(1:lengthp,:);
[~,index]=sortrows(likeliness);
lengthp=round(lengthp.*0.50);
parameters=parameters(index,:);
parameters=parameters(1:lengthp,:);
likelyinfo=likelyinfo(index,:);
likelyinfo=likelyinfo(1:lengthp,:);


[sizel,~]=size(likelyinfo);
k=[];
for i=1:sizel;
    if strcmp(species,likelyinfo{i,1})
        k=[k;i];
    end
end
likelyinfo=likelyinfo(k,:);
[sizel,~]=size(likelyinfo);

switch mode
    case 'Ritz'
        w=4;
    case 'Observed'
        w=5;
end

k=ones(sizel,1);
for i=1:sizel;
    if isempty(likelyinfo{i,8}),
        k(i)=0;
    end
    if isnan(likelyinfo{i,8})
        k(i)=0;
    end
    if isempty(likelyinfo{i,13})
        k(i)=0;
    end
    if isnan(likelyinfo{i,13})
        k(i)=0;
    end
    if isempty(likelyinfo{i,21})
        k(i)=0;
    end
    if isnan(likelyinfo{i,21})
        k(i)=0;
    end
end

likelyinfo=likelyinfo(logical(k),:);

intensity=parameters(:,2).*parameters(:,3).*pi./2;

intensity=intensity(logical(k),:);
g=cell2mat(likelyinfo(:,21));
lambda=cell2mat(likelyinfo(:,w));
A=cell2mat(likelyinfo(:,8));

Ek=cell2mat(likelyinfo(:,13));
k=8.6173324e-5;
factor1=log(intensity.*lambda./(g.*A));
factor2=Ek;
a=polyfit(factor2,factor1,1);
T=1/(a(1)*(-k));
plot(factor2,polyval(a,factor2),factor2,factor1,'o')