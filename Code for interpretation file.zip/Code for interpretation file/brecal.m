%enter stats separated by ;
function [pok3,pok3total,n1,n2]=brecal(pok1,pok2)
sumpok1=sum(pok1)-pok1(4);
sumpok2=sum(pok2)-pok2(4);
pok3=zeros(6,1);
n=1000000;
pok3total=zeros(6,n);
n1=0;
n2=0;
for i=1:n;
    number1=floor(12*rand())+1;
    number2=number1;
    while mod(number2,6)==mod(number1,6)
        if number1<7
            number2=floor(6*rand())+1;
        else
            number2=floor(6*rand())+7;
        end
    end
    number3=number1;
    while or(mod(number3,6)==mod(number1,6),mod(number3,6)==mod(number2,6));
        number3=floor(12*rand())+1;
    end
    pok12=[pok1;pok2];
    for j=1:6
        if j==mod(number1,6)
            pok3(j)=pok12(number1);
        elseif j==mod(number2,6)
            pok3(j)=pok12(number2);
        elseif j==mod(number3,6)
            pok3(j)=pok12(number3);
        else
            pok3(j)=floor(32*rand());
        end
    end
    pok3total(:,i)=pok3;
    if sum(pok3)-pok3(4)>113
        n1=n1+1;
    end
    if sum(pok3)-pok3(4)>111
        n2=n2+1;
    end
end