function [parameters,inputvalues]=fitmultilorentz(x,y,numberofpeaks,lb,ub)
paramub=inf(numberofpeaks,3); %initial paramaters, all upper bounds set to infinite
paramlb=zeros(numberofpeaks,3); %initial paramaters, all lower bounds set to zero
paramlb(:,1)=lb;
paramub(:,1)=ub;
paramub(:,2)=max(y).*2;
paramub(:,3)=max(x)-min(x);
parameters=lsqcurvefit(@multilorentz,ones(size(paramub)),x,y,paramlb,paramub);
plot(x,y,x,multilorentz(parameters,x));
pause(0.1);
inputvalues=parameters;
parameters(:,4)=parameters(:,2).*parameters(:,3).*pi./2; %parameters=[x0,height, width, area]
parameters=[transpose(1:numberofpeaks) parameters];
end