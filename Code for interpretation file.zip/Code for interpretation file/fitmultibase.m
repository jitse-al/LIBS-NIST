function [baseyout,paramsall,stoppingreasons]=fitmultibase(x,basex,basey,basex2,basey2)
try
    [echelle_orders,n]=find_echelle_orders(basex(1),basex(length(basex)));
catch
    [echelle_orders,n]=find_echelle_orders(basex(4),basex(length(basex))-4);
end
maxy=max(basey);
stoppingreasons=zeros(n,1);
baseyout=zeros(size(x));
paramsall=zeros(3,n);
beginxall=zeros(1,n);
beginxall2=zeros(1,n);
endxall=zeros(1,n);
endxall2=zeros(1,n);
options=optimoptions('lsqcurvefit','Display','off','MaxFunEvals',30,'MaxIter',100);
for i=1:n;
    try
        [beginx,endx]=findxpositions(x,echelle_orders(i),echelle_orders(i+1));
        beginx=beginx+1;
        endx=endx-1;
        [subx,suby]=subset(basex,basey,echelle_orders(i),echelle_orders(i+1));
        
        [params,~,~,exitflag]=lsqcurvefit(@singleorder,[0;0;max(suby)],subx,suby,[-maxy;-maxy;0],[maxy;maxy;maxy],options);
        stoppingreasons(i)=exitflag;
        baseyout(beginx:endx)=singleorder(params,x(beginx:endx));
        beginxall(i)=beginx;
        beginxall2(i)=baseyout(beginx);
        endxall(i)=endx;
        endxall2(i)=baseyout(endx);
        paramsall(:,i)=params;
    catch
        stoppingreasons(i)=8;
    end
end

% plot(basex,basey,basex2,basey2);
% pause

amplitudes=paramsall(3,:);
ordernumber=1:n;
amplifit=polyfit(ordernumber(amplitudes>1),amplitudes(amplitudes>1),4);
amplitudey=polyval(amplifit,ordernumber);

% plot(amplitudey)
% pause
for i=1:n;
    if or(beginxall2(i)<-20,endxall2(i)<-20);
        amplitudes(i)=0;
    end
end
beginxall_1=beginxall(amplitudes>1);
beginxall2_1=beginxall2(amplitudes>1);
endxall_1=endxall(amplitudes>1);
endxall2_1=endxall2(amplitudes>1);


lowest1=interp1(beginxall_1,beginxall2_1,1:length(x));
lowest2=interp1(endxall_1,endxall2_1,1:length(x));

for i=1:length(lowest1);
    if isnan(lowest1(i));
        lowest1(i)=lowest2(i);
    end
    if isnan(lowest2(i))
        lowest2(i)=lowest1(i);
    end
    if isnan(lowest1(i));
        lowest1(i)=0;
    end
    if isnan(lowest2(i))
        lowest2(i)=0;
    end
end
lowest=(lowest1+lowest2)./2;
for i=1:n;
    if paramsall(3,i)<1
        [beginx,endx]=findxpositions(x,echelle_orders(i),echelle_orders(i+1));
        beginx=beginx+1;
        endx=endx-1;
        try
            [subx,suby]=subset(basex2,basey2,echelle_orders(i),echelle_orders(i+1));
            [params,~,~,exitflag]=lsqcurvefit(@singleorder,[0;0;amplitudey(i)],subx,suby,[-maxy;-maxy;0],[maxy;maxy;max(amplitudey),options]);
            stoppingreasons(i)=exitflag.*10;
            baseyout(beginx:endx)=singleorder(params,x(beginx:beginy));
            paramsall(:,i)=params;
            beginxall(i)=beginx;
            beginxall2(i)=baseyout(beginx);
            endxall(i)=endx;
            endxall2(i)=baseyout(endx);
        catch
            startpoint=lowest(beginx);
            endpoint=lowest(endx);
            slope=(endpoint-startpoint)./(x(endx)-x(beginx));
            intersect=lowest(beginx)-x(beginx).*slope;
            baseyout(beginx:endx)=singleorder([slope;intersect;amplitudey(i)],x(beginx:endx));
            stoppingreasons(i)=9;
            paramsall(1,i)=slope;
            paramsall(2,i)=intersect;
            paramsall(3,i)=amplitudey(i);
            beginxall(i)=beginx;
            beginxall2(i)=baseyout(beginx);
            endxall(i)=endx;
            endxall2(i)=baseyout(endx);
        end
    end
end
amplitudes=paramsall(3,:);

% plot(amplitudes)
% pause

checkfactor=quantile(sort(amplitudes),0.80);


checkfactor=amplitudes<checkfactor;
checkfactor(1)=1;
checkfactor(2)=2;

ampmodel=interp1(ordernumber(checkfactor),amplitudes(checkfactor),ordernumber);




for i=1:n
    if  not(checkfactor(i))
        [beginx,endx]=findxpositions(x,echelle_orders(i),echelle_orders(i+1));
        beginx=beginx+1;
        endx=endx-1;
        startpoint=lowest(beginx);
        endpoint=lowest(endx);
        slope=(endpoint-startpoint)./(x(endx)-x(beginx));
        intersect=lowest(beginx)-x(beginx).*slope;
        baseyout(beginx:endx)=singleorder([slope;intersect;ampmodel(i)],x(beginx:endx));
        stoppingreasons(i)=20;
        paramsall(1,i)=slope;
        paramsall(2,i)=intersect;
        paramsall(3,i)=ampmodel(i);
        beginxall(i)=beginx;
        beginxall2(i)=baseyout(beginx);
        endxall(i)=endx;
        endxall2(i)=baseyout(endx);
    end
end

correlationfactor=0.98;
for i=2:n;
    if not(and(beginxall2(i)>endxall2(i).*correlationfactor,beginxall2(i)<endxall2(i)./correlationfactor))
        [beginx,endx]=findxpositions(x,echelle_orders(i),echelle_orders(i+1));
        beginx=beginx+1;
        endx=endx-1;
        startpoint=lowest(beginx);
        endpoint=lowest(endx);
        slope=(endpoint-startpoint)./(x(endx)-x(beginx));
        intersect=lowest(beginx)-x(beginx).*slope;
        baseyout(beginx:endx)=singleorder([slope;intersect;ampmodel(i)],x(beginx:endx));
        stoppingreasons(i)=20;
        paramsall(1,i)=slope;
        paramsall(2,i)=intersect;
        paramsall(3,i)=ampmodel(i);
        beginxall(i)=beginx;
        beginxall2(i)=baseyout(beginx);
        endxall(i)=endx;
        endxall2(i)=baseyout(endx);
    end
end

for i=2;
    [beginx,endx]=findxpositions(x,echelle_orders(i),echelle_orders(i+1));
    beginx=beginx+1;
    endx=endx-1;
    startpoint=lowest(beginx);
    endpoint=lowest(endx);
    slope=(endpoint-startpoint)./(x(endx)-x(beginx));
    intersect=lowest(beginx)-x(beginx).*slope;
    baseyout(beginx:endx)=singleorder([slope;intersect;ampmodel(i)],x(beginx:endx));
    stoppingreasons(i)=20;
    paramsall(1,i)=slope;
    paramsall(2,i)=intersect;
    paramsall(3,i)=ampmodel(i);
    beginxall(i)=beginx;
    beginxall2(i)=baseyout(beginx);
    endxall(i)=endx;
    endxall2(i)=baseyout(endx);
end

for i=1;
    [~,endx]=findxpositions(x,echelle_orders(i),echelle_orders(i+1));
    beginx=1;
    endx=endx-1;
    startpoint=0;
    endpoint=lowest(endx);
    slope=(endpoint-startpoint)./(x(endx)-x(beginx));
    intersect=lowest(endx)-x(endx).*slope;
    baseyout(beginx:endx)=singleorder([slope;intersect;ampmodel(i)],x(beginx:endx));
    stoppingreasons(i)=20;
    paramsall(1,i)=slope;
    paramsall(2,i)=intersect;
    paramsall(3,i)=ampmodel(i);
    beginxall(i)=beginx;
    beginxall2(i)=baseyout(beginx);
    endxall(i)=endx;
    endxall2(i)=baseyout(endx);
end
%plot(basex,basey,x,baseyout)
