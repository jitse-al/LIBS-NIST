function ring_model=ring(maximum,minimum,size_x,size_y,radius,fwhm)
ringimage=zeros(size_x,size_y);
halfx=floor(size_x/2);
halfy=floor(size_y/2);
dx=maximum-minimum;
for i=1:size_x;
    for j=1:size_y;
        tempradius=sqrt((i-halfx)^2+(j-halfy)^2);
        ringimage(i,j)=lorentzian([radius dx fwhm],tempradius);
    end
end
ring_model=ringimage+minimum;