function f=multilorentz2(parameters,x)
f=zeros(size(x));
[a,~]=size(parameters);
numberofpeaks=a;
for i=1:numberofpeaks
    f=f+lorentzian(parameters(i,:),x);
end
%f=f+parameters(a,1).*x+parameters(a,2);
end
    