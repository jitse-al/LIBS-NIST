function [names,numbers,info]=relate_lines2(parameters,maxdeviation,power_of_fit)
[positions,possible_species,info,findinglist]=relate_lines(parameters,'findinglist');
checkp=positions(:,2)<maxdeviation;
% positions=positions(checkp,:);
possible_species=possible_species(checkp,:);
[names,numbers]=strcount(possible_species);
% for i=1:length(names)
%     k=[];
%     for j=1:length(possible_species)
%         if strcmp(possible_species(j),names(i))
%             k=[k;positions(j,2)];
%         end
%     end
%     numbers(i)=numbers(i).^2./(sqrt(mean(k.^2)));
% end
[namesf,numbersf]=strcount(findinglist(:,1));
for i=1:length(namesf)
    for j=1:length(names)
        if strcmp(namesf(i),names(j))
            numbers(j)=numbers(j).^power_of_fit/numbersf(i);
        end
    end
end
[numbers,index]=sort(numbers,'descend');
names=names(index);