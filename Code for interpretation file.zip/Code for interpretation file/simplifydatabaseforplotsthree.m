function out=simplifydatabaseforplotsthree(nist)
[lx,~]=size(nist);
out=nist;
for i=1:lx
    [lx2,~]=size(nist{i,1});
    b=[];
    for j=1:lx2
        a=nist{i,1}{j,1}{1,2};
        b=[b;a];
    end
    out{i,1}=cell(max(b),1);
    k=1;
    for j=1:max(b);
        if j==nist{i,1}{k,1}{1,2}
            out{i,1}{j,1}=nist{i,1}{k,1};
            k=k+1;
        end
    end
end